# lua-local-deleted-tool

Lua/Luau ソースに対して、`local` 系変換、整形、圧縮、簡約、コメント削除、未使用コード削除、lint、依存解析、preset 実行を行う CLI ツールです。

内部構成の詳細は `ARCHITECTURE.md` を参照してください。

## 必要環境

- `lua54` 実行環境
- 入力ファイルは `.lua`

## 基本構文

```bash
lua54 main.lua [--engine=line|ast] [--lint-dynamic=on|off] <mode> [scope] <inputfile> [presetfile]
```

`--engine` / `--lint-dynamic` は `<mode>` の前に指定します。

## 実行方式

このツールは次の **2通り** で実行できます。

- 通常コマンド実行: 1コマンドを直接実行
  - 例: `lua54 main.lua coml test.lua`
- preset 実行: `preset.json` の複数ステップを順番に実行
  - 例: `lua54 main.lua preset test.lua`

## オプション

- `--engine=line|ast`
  - デフォルトは `line`
  - `functionlocal` / `localkw` / `localte` / `localc` / `localcyt` / `localnum` / `localtabke` / `outcode` で有効
  - `fom` / `coml` / `nmbun` / `rename` / `deleteout` / `nocode` / `lint` / `rrequire` / `preset` では無視されます
- `--lint-dynamic=on|off`
  - `lint` 実行時の動的チェック既定値を切り替えます
  - `lint -on|-off` 指定時はそちらが優先されます

## コマンド一覧

| mode | 役割 | scope | 例 |
|---|---|---|---|
| `functionlocal` | 関数宣言の `local` を削除 | 任意 (`function`/`global`) | `lua54 main.lua functionlocal test.lua` |
| `localkw` | `local` キーワード削除 | 任意 | `lua54 main.lua localkw global test.lua` |
| `localte` | ブール代入の `local` を削除 | 必須 | `lua54 main.lua localte function test.lua` |
| `localc` | 文字列代入の `local` を削除 | 必須 | `lua54 main.lua localc global test.lua` |
| `localcyt` | 文字列代入の `local` を削除（`localc` 相当） | 任意 | `lua54 main.lua localcyt test.lua` |
| `localnum` | 数値代入の `local` を削除 | 任意 | `lua54 main.lua localnum test.lua` |
| `localtabke` | テーブル代入の `local` を削除 | 任意 | `lua54 main.lua localtabke function test.lua` |
| `outcode` | コメントアウトされたコード行の除去 | なし | `lua54 main.lua outcode test.lua` |
| `deleteout` | `--` / `--[[...]]` コメント削除 | なし | `lua54 main.lua deleteout test.lua` |
| `nocode` | 未使用ローカルコードの削除 | なし | `lua54 main.lua nocode test.lua` |
| `codefix` | 壊れた構文の自動修正 + 構文/コンパイル検証レポート | なし | `lua54 main.lua codefix test.lua` |
| `deobf` | 難読化コードの動的/静的デコード + VMトレース + devirtualize 前処理 | なし | `lua54 main.lua deobf -trace=off test.lua` |
| `fom` | フォーマット | なし | `lua54 main.lua fom test.lua` |
| `coml` | 圧縮（最小化） | なし | `lua54 main.lua coml test.lua` |
| `nmbun` | 数値/文字列/真偽式の簡約 | なし | `lua54 main.lua nmbun test.lua` |
| `rename` | ローカル変数/引数のリネーム | なし | `lua54 main.lua rename test.lua` |
| `lint` | 静的解析 + 動的解析(任意) | なし | `lua54 main.lua lint -on test.lua` |
| `rrequire` | `require` 依存解析 | なし | `lua54 main.lua rrequire test.lua` |
| `preset` | `preset.json` の手順実行 | なし | `lua54 main.lua preset test.lua` |

補足:
- `localtur` も受け付けます（`localte` 相当、scope 任意）。

## `codefix` の修正対象

`codefix` は **完全AIモード** です。  
`src/codefix_ai.lua` による候補探索のみで、構文解析 + コンパイル検証のスコアが最も高い結果を採用します。

- テーブル要素のカンマ欠落（改行区切り / 同一行フィールド）
- 関数呼び出し引数のカンマ欠落
- `if/elseif` の `then` 欠落、`while/for` の `do` 欠落
- 文字列エスケープ破損、短文字列内の不正改行
- 文区切り不足（`;` 補完）と閉じ括弧/`end`/`until` の補完
- 低メモリ探索（署名キャッシュ + ビーム幅/深さの入力サイズ自動調整）
- 安全フィルタ（過大差分・過剰セミコロン・不正出力を抑止）

出力レポート `output/<file>.codefix.json` には、試行した修正候補と最終採用結果が記録されます。

## `deobf` の解読パイプライン

`deobf` は以下を順に実行します。

- hardening sandbox で実行し、`load/loadstring` やメモリ上チャンクを捕捉
- 静的抽出（文字列デコード、カスタムbase64辞書推定、リテラル再書換え）
- rescue profile（未定義グローバルを proxy 化）で再試行
- devirtualizer 前処理（定数式の畳み込み）
- VM state-machine trace 抽出（状態変数、遷移、閾値）
- unlock パス（`M(<const>)` 参照展開による可読コード生成）

実行例:

```bash
lua54 main.lua deobf -trace=off test.lua
lua54 main.lua deobf -trace=on test.lua
lua54 main.lua deobf -trace=off -unlock-table=on test.lua
lua54 main.lua deobf -trace=off -readable=off test.lua
```

`output/<file>.deobf.json` 主要フィールド:

- `runtime.runtime_obfuscation_hint`
- `runtime.rescue_profile_used`
- `unlock.applied` / `unlock.replacements`
- `devirtualizer.applied` / `devirtualizer.constant_folds`
- `vm_trace.before` / `vm_trace.after`
- `readable.compile_ok` / `readable.devirtualizer.constant_folds`

## lint の動的切替

```bash
lua54 main.lua lint test.lua
lua54 main.lua lint -on test.lua
lua54 main.lua lint -off test.lua
lua54 main.lua --lint-dynamic=off lint test.lua
```

動的lintは実行前にコードをランタイム互換へ正規化してから sandbox 実行します。

`output/<file>.lint.json` の `result.dynamic` には次を記録します。

- `dependencies.globals`
  - `reads` / `resolved_reads` / `unresolved_reads` / `undefined_reads` / `writes`
- `dependencies.metatable`
  - `gets` / `sets` / `metamethod_keys`
- `dependencies.proxies`
  - `roots` / `reads`
- `dependencies.require`
  - `require(...)` 呼び出し
- `history`
  - 動的実行で観測したアクセス経緯（時系列）

## 出力

基本出力:
- `output/<入力ファイル名>`

追加レポート:
- 全コマンド: `output/<入力ファイル名>.safety.json`
- `codefix`: `output/<入力ファイル名>.codefix.json`
- `deobf`: `output/<入力ファイル名>.deobf.json`
- `lint`: `output/<入力ファイル名>.lint.json`
- `rrequire`: `output/<入力ファイル名>.rrequire.json`
- `preset`: `output/<入力ファイル名>.preset.json`

`deobf` のコード出力は `output/<入力ファイル名>.deobfl.ua` です。

可読化補助コードは `output/<入力ファイル名>.deobf.unlocked.lua` に出力されます。

読みやすい整形版は `output/<入力ファイル名>.deobf.readable.lua` に出力されます。

`preset` で `write_step_outputs: true`（または step ごとの `write_output: true`）を使うと、`output/preset_steps/` に各ステップ出力が保存されます。

## preset.json 最小例

```json
{
  "version": 1,
  "name": "default",
  "engine": "line",
  "write_step_outputs": false,
  "stop_on_error": true,
  "steps": [
    { "name": "strip-comments", "mode": "deleteout", "enabled": true },
    { "name": "format", "mode": "fom", "enabled": true },
    { "name": "compress", "mode": "coml", "enabled": true }
  ]
}
```

実行:

```bash
lua54 main.lua preset test.lua
lua54 main.lua preset test.lua preset.json
```
