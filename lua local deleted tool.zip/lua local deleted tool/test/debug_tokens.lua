local mode = arg[2] or 'basic'
local input = arg[1] or 'test.lua'

local function read_file(path)
  local f = io.open(path, 'rb')
  if not f then
    return nil, 'cannot open: ' .. path
  end
  local s = f:read('*a')
  f:close()
  return s
end

local function escape_value(v)
  if type(v) ~= 'string' then
    return tostring(v)
  end
  local s = v
  s = s:gsub('\\', '\\\\')
  s = s:gsub('\r', '\\r')
  s = s:gsub('\n', '\\n')
  s = s:gsub('\t', '\\t')
  if #s > 80 then
    s = s:sub(1, 77) .. '...'
  end
  return '"' .. s .. '"'
end

local source, read_err = read_file(input)
if not source then
  io.stderr:write(read_err .. '\n')
  os.exit(1)
end

local lexer_module = mode == 'full' and 'src.lexer_full' or 'src.lexer'
local Lexer = require(lexer_module)

local ok, tokens_or_err = pcall(function()
  local lexer = Lexer.new(source)
  return lexer:tokenize()
end)

if not ok then
  io.stderr:write('tokenize error: ' .. tostring(tokens_or_err) .. '\n')
  os.exit(1)
end

local tokens = tokens_or_err
print('lexer: ' .. lexer_module)
print('input: ' .. input)
print('token_count: ' .. tostring(#tokens))
print('')
for i, tok in ipairs(tokens) do
  local line = tok.line or 0
  local col = tok.col or 0
  local t = tok.type or 'nil'
  local value = escape_value(tok.value)
  print(string.format('%4d  L%-4d C%-4d %-16s %s', i, line, col, t, value))
end
