local Lexer = require('src.lexer')
local Parser = require('src.parser')

local input = arg[1] or 'test/fixtures/local_modes.lua'
local is_windows = package.config:sub(1, 1) == '\\'

local function read_file(path)
  local f = io.open(path, 'rb')
  if not f then
    return nil, 'cannot open: ' .. path
  end
  local s = f:read('*a')
  f:close()
  return s
end

local function write_file(path, content)
  local f = io.open(path, 'wb')
  if not f then
    return false, 'cannot write: ' .. path
  end
  f:write(content)
  f:close()
  return true
end

local function parse_ok(source)
  return pcall(function()
    local tokens = Lexer.new(source):tokenize()
    Parser.new(tokens):parse()
  end)
end

local function exec_success(a, b, c)
  if type(a) == 'number' then
    return a == 0
  end
  if type(a) == 'boolean' then
    if not a then
      return false
    end
    if type(c) == 'number' then
      return c == 0
    end
    return true
  end
  return false
end

local cases = {
  { mode = 'functionlocal' },
  { mode = 'functionlocal', scope = 'function' },
  { mode = 'functionlocal', scope = 'global' },
  { mode = 'localkw' },
  { mode = 'localkw', scope = 'function' },
  { mode = 'localkw', scope = 'global' },
  { mode = 'localtabke' },
  { mode = 'localtabke', scope = 'function' },
  { mode = 'localtabke', scope = 'global' },
  { mode = 'localcyt' },
  { mode = 'localcyt', scope = 'function' },
  { mode = 'localcyt', scope = 'global' },
  { mode = 'localnum' },
  { mode = 'localnum', scope = 'function' },
  { mode = 'localnum', scope = 'global' },
  { mode = 'localte', scope = 'function' },
  { mode = 'localte', scope = 'global' }
}

local source, read_err = read_file(input)
if not source then
  io.stderr:write(read_err .. '\n')
  os.exit(1)
end

print('input: ' .. input)
print('cases: ' .. tostring(#cases))
print('')

local total_pass = 0
local total_fail = 0

for i, case in ipairs(cases) do
  local tag = case.mode .. (case.scope and (':' .. case.scope) or ':all')
  local tmp_name = string.format('.tmp_debug_local_%02d.lua', i)
  local ok_write = write_file(tmp_name, source)
  if not ok_write then
    total_fail = total_fail + 1
    print(string.format('[FAIL] %-28s write-failed', tag))
  else
    local scope_part = case.scope and (' ' .. case.scope) or ''
    local cmd = string.format('lua54 main.lua %s%s "%s"', case.mode, scope_part, tmp_name)
    if is_windows then
      cmd = cmd .. ' > NUL 2>&1'
    else
      cmd = cmd .. ' >/dev/null 2>&1'
    end
    local a, b, c = os.execute(cmd)
    local ran = exec_success(a, b, c)
    local out_path = 'output/' .. tmp_name
    local out_source = nil
    local out_err = nil
    if ran then
      out_source, out_err = read_file(out_path)
    end
    local parsed = false
    if out_source then
      parsed = parse_ok(out_source)
    end
    local changed = out_source and (out_source ~= source) or false
    if ran and out_source and parsed then
      total_pass = total_pass + 1
      print(string.format('[PASS] %-28s changed=%s', tag, tostring(changed)))
    else
      total_fail = total_fail + 1
      print(string.format('[FAIL] %-28s ran=%s output=%s parsed=%s', tag, tostring(ran), tostring(out_source ~= nil), tostring(parsed)))
      if out_err then
        print('       detail: ' .. tostring(out_err))
      end
    end
    os.remove(tmp_name)
    os.remove(out_path)
    os.remove(out_path .. '.safety.json')
  end
end

print('')
print(string.format('summary: pass=%d fail=%d total=%d', total_pass, total_fail, total_pass + total_fail))
if total_fail > 0 then
  os.exit(1)
end
