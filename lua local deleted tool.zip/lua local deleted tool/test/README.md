# test folder

Debug utilities for parser and command behavior checks.
Run commands from project root.

## parser and lexer

```bash
lua54 test/debug_tokens.lua test.lua
lua54 test/debug_tokens.lua test.lua full
lua54 test/debug_parser.lua test.lua
lua54 test/debug_ast.lua test.lua
lua54 test/debug_parse_suite.lua
```

## command behavior

```bash
lua54 test/debug_local_modes.lua
lua54 test/debug_local_modes.lua test.lua
```

## fixtures

- `test/fixtures/parser_ok.lua`
- `test/fixtures/parser_error.lua`
- `test/fixtures/local_modes.lua`
