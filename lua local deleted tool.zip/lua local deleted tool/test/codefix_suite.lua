local CodeFix = require("src.codefix")

local function assert_no_cr(name, text)
  if text:find("\r", 1, true) then
    error(name .. ": output contains CR (\\r)")
  end
end

local function assert_compiles(name, text)
  local fn, err = load(text)
  if not fn then
    error(name .. ": output does not compile: " .. tostring(err))
  end
end

local function assert_contains(name, text, needle)
  if not text:find(needle, 1, true) then
    error(name .. ": expected output to contain: " .. needle)
  end
end

local function run_case(name, source, checks)
  local out, _, meta = CodeFix.run(source, {
    dialect = "lua54",
    reasoning = "high",
    memory = "low",
    lua_specialized = true
  })

  local report = meta and meta.report_data or {}
  if not report.success then
    local after = report.after or {}
    error(name .. ": codefix failed parse_ok=" .. tostring(after.parse_ok) .. " compile_ok=" .. tostring(after.compile_ok)
      .. " parse_error=" .. tostring(after.parse_error) .. " compile_error=" .. tostring(after.compile_error))
  end

  assert_no_cr(name, out)
  assert_compiles(name, out)

  for _, check in ipairs(checks or {}) do
    if check.kind == "contains" then
      assert_contains(name, out, check.value)
    end
  end

  print("ok " .. name)
end

local function run_case_no_compile(name, source, dialect, checks)
  local out, _, meta = CodeFix.run(source, {
    dialect = dialect,
    reasoning = "high",
    memory = "low",
    lua_specialized = true
  })

  local report = meta and meta.report_data or {}
  if not report.success then
    local after = report.after or {}
    error(name .. ": codefix failed parse_ok=" .. tostring(after.parse_ok) .. " compile_ok=" .. tostring(after.compile_ok)
      .. " parse_error=" .. tostring(after.parse_error) .. " compile_error=" .. tostring(after.compile_error))
  end

  assert_no_cr(name, out)

  for _, check in ipairs(checks or {}) do
    if check.kind == "contains" then
      assert_contains(name, out, check.value)
    end
  end

  print("ok " .. name)
end

run_case(
  "normalize_newlines_and_close_string_and_paren",
  "local v = \"aaa\r\nprint(v\r\n",
  {
    { kind = "contains", value = "local v = \"aaa\"" },
    { kind = "contains", value = "print(v)" }
  }
)

run_case(
  "keyword_typo_function",
  "local fucntion av()\nprint(\"x\")\nend\nav()\n",
  {
    { kind = "contains", value = "local function av()" }
  }
)

run_case(
  "missing_equals_local_assign",
  "local a 1\nprint(a)\n",
  {
    { kind = "contains", value = "local a = 1" }
  }
)

run_case(
  "missing_call_parentheses",
  "print v\n",
  {
    { kind = "contains", value = "print(v)" }
  }
)

run_case(
  "append_missing_repeat_until_true",
  "repeat\n  print(\"x\")\n",
  {
    { kind = "contains", value = "until true" }
  }
)

run_case(
  "dangling_quote_dropped_over_empty_string_call",
  "print (aa\"",
  {
    { kind = "contains", value = "local aa = \"\"" },
    { kind = "contains", value = "print(aa)" }
  }
)

run_case_no_compile(
  "luau_continue_is_not_force_fixed",
  "for i = 1, 3 do\n  if i == 2 then\n    continue\n  end\nend\n",
  "luau",
  {
    { kind = "contains", value = "continue" }
  }
)

do
  local CodeFixAI = require("src.codefix_ai")
  local Lexer = require("src.lexer")
  local Parser = require("src.parser")

  local function analyze(text, dialect)
    local parse_ok, parse_err = pcall(function()
      local tokens = Lexer.new(text, { dialect = dialect }):tokenize()
      local parser = Parser.new(tokens, { dialect = dialect })
      parser:parse()
    end)

    local compile_ok = false
    local compile_err = nil

    return {
      parse_ok = parse_ok,
      compile_ok = compile_ok,
      parse_error = parse_err and tostring(parse_err) or nil,
      compile_error = compile_err and tostring(compile_err) or nil
    }
  end

  local source = "local a = 1\nprint(a)\n"
  local fixers = {
    {
      name = "break-ast",
      fn = function(text)
        return text .. "end\n", 1, nil
      end
    }
  }

  local solved = CodeFixAI.solve(source, fixers, analyze, {
    dialect = "lua54",
    max_depth = 1,
    beam_width = 2,
    attempt_limit = 16,
    max_change_ratio = 0.9,
    max_score_drop = 9999,
    max_semicolon_spike = 9999,
    max_single_fixes = 9999,
    max_quality_drop_depth = 1,
    max_quality_drop_ratio = 0.9
  })

  if solved.best and solved.best.text ~= source then
    error("ai_rollback_ast_regression: expected best to remain the original source")
  end
  if not (solved.stats and solved.stats.pruned_ast and solved.stats.pruned_ast >= 1) then
    error("ai_rollback_ast_regression: expected pruned_ast >= 1")
  end

  print("ok ai_rollback_ast_regression")
end
