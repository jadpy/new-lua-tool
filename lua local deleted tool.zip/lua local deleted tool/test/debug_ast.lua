local input = arg[1] or 'test.lua'
local max_depth = tonumber(arg[2]) or 8
local max_items = tonumber(arg[3]) or 40

local function read_file(path)
  local f = io.open(path, 'rb')
  if not f then
    return nil, 'cannot open: ' .. path
  end
  local s = f:read('*a')
  f:close()
  return s
end

local function quote(s)
  s = s:gsub('\\', '\\\\')
  s = s:gsub('\r', '\\r')
  s = s:gsub('\n', '\\n')
  s = s:gsub('\t', '\\t')
  return '"' .. s .. '"'
end

local function is_array(t)
  local n = #t
  local c = 0
  for k in pairs(t) do
    if type(k) ~= 'number' or k < 1 or k > n or k % 1 ~= 0 then
      return false
    end
    c = c + 1
  end
  return c == n
end

local function sorted_keys(t)
  local ks = {}
  for k in pairs(t) do
    ks[#ks + 1] = k
  end
  table.sort(ks, function(a, b)
    return tostring(a) < tostring(b)
  end)
  return ks
end

local function dump(v, depth, seen)
  local tv = type(v)
  if tv == 'nil' then
    return 'nil'
  elseif tv == 'number' or tv == 'boolean' then
    return tostring(v)
  elseif tv == 'string' then
    return quote(v)
  elseif tv ~= 'table' then
    return quote('<' .. tv .. '>')
  end

  if seen[v] then
    return quote('<cycle>')
  end
  if depth >= max_depth then
    return quote('<max-depth>')
  end
  seen[v] = true

  local out = {}
  if is_array(v) then
    out[#out + 1] = '['
    local n = #v
    local lim = math.min(n, max_items)
    for i = 1, lim do
      out[#out + 1] = string.rep('  ', depth + 1) .. dump(v[i], depth + 1, seen) .. ','
    end
    if n > lim then
      out[#out + 1] = string.rep('  ', depth + 1) .. quote('<...>') .. ','
    end
    out[#out + 1] = string.rep('  ', depth) .. ']'
  else
    out[#out + 1] = '{'
    local keys = sorted_keys(v)
    local lim = math.min(#keys, max_items)
    for i = 1, lim do
      local k = keys[i]
      local key = type(k) == 'string' and k or '[' .. tostring(k) .. ']'
      out[#out + 1] = string.rep('  ', depth + 1) .. key .. ' = ' .. dump(v[k], depth + 1, seen) .. ','
    end
    if #keys > lim then
      out[#out + 1] = string.rep('  ', depth + 1) .. '<...> = ' .. quote('<trimmed>') .. ','
    end
    out[#out + 1] = string.rep('  ', depth) .. '}'
  end
  seen[v] = nil
  return table.concat(out, '\n')
end

local source, read_err = read_file(input)
if not source then
  io.stderr:write(read_err .. '\n')
  os.exit(1)
end

local Lexer = require('src.lexer')
local Parser = require('src.parser')
local ok, ast_or_err = pcall(function()
  local tokens = Lexer.new(source):tokenize()
  return Parser.new(tokens):parse()
end)
if not ok then
  io.stderr:write('parse error: ' .. tostring(ast_or_err) .. '\n')
  os.exit(1)
end

print('input: ' .. input)
print('max_depth: ' .. tostring(max_depth))
print('max_items: ' .. tostring(max_items))
print('')
print(dump(ast_or_err, 0, {}))
