local Lexer = require('src.lexer')
local Parser = require('src.parser')
local Optimizer = require('src.optimizer')
local CodeGen = require('src.codegen')

local Nmbun = {}

function Nmbun.run(source, options)
  options = options or {}
  local dialect = options.dialect
  local ok, output = pcall(function()
    local tokens = Lexer.new(source, { dialect = dialect }):tokenize()
    local parser = Parser.new(tokens, { dialect = dialect })
    local ast = parser:parse()

    for _ = 1, 3 do
      ast = Optimizer.optimize(ast)
    end

    local codegen = CodeGen.new(nil)
    local target = ast.body or ast
    return codegen:generate(target)
  end)

  if not ok or type(output) ~= 'string' or output == '' then
    return source, { all_locals = {} }
  end
  return output, { all_locals = {} }
end

return Nmbun
