local Lexer = require('src.lexer')
local Parser = require('src.parser')
local CodeGen = require('src.codegen')
local Optimizer = require('src.optimizer')

local NoCode = {}

local function new_scope(parent)
  return { parent = parent, locals = {} }
end

local function lookup_symbol(scope, name)
  local cur = scope
  while cur do
    local sym = cur.locals[name]
    if sym then
      return sym
    end
    cur = cur.parent
  end
  return nil
end

local function declare_symbol(scope, name, kind, node)
  local sym = {
    name = name,
    refs = 0,
    kind = kind,
    node = node
  }
  scope.locals[name] = sym
  return sym
end

local function split_identifier_path(path)
  local parts = {}
  if type(path) ~= 'string' then
    return parts
  end
  for name in path:gmatch('([%a_][%w_]*)') do
    parts[#parts + 1] = name
  end
  return parts
end

local function analyze_expr(node, scope)
  if not node or type(node) ~= 'table' then
    return
  end
  local t = node.type

  if t == 'Identifier' then
    local sym = lookup_symbol(scope, node.name)
    if sym then
      sym.refs = sym.refs + 1
    end
    return
  end

  if t == 'BinaryOp' then
    analyze_expr(node.left, scope)
    analyze_expr(node.right, scope)
    return
  end

  if t == 'UnaryOp' then
    analyze_expr(node.operand, scope)
    return
  end

  if t == 'FunctionCall' then
    analyze_expr(node.callee, scope)
    for _, arg in ipairs(node.args or {}) do
      analyze_expr(arg, scope)
    end
    return
  end

  if t == 'MethodCall' then
    analyze_expr(node.object, scope)
    for _, arg in ipairs(node.args or {}) do
      analyze_expr(arg, scope)
    end
    return
  end

  if t == 'IndexExpr' then
    analyze_expr(node.object, scope)
    analyze_expr(node.index, scope)
    return
  end

  if t == 'PropertyExpr' then
    analyze_expr(node.object, scope)
    return
  end

  if t == 'Table' then
    for _, field in ipairs(node.fields or {}) do
      if field.key then
        analyze_expr(field.key, scope)
      end
      analyze_expr(field.value, scope)
    end
    return
  end

  if t == 'Function' then
    local fn_scope = new_scope(scope)
    for _, p in ipairs(node.params or {}) do
      declare_symbol(fn_scope, p, 'param', node)
    end
    if node.body then
      local body_scope = new_scope(fn_scope)
      local stmts = node.body.statements or {}
      for _, stmt in ipairs(stmts) do
        -- forward declaration: handled by local function below
      end
      -- local function declaration to avoid mutual recursion issues in Lua 5.1 style
      local analyze_stmt
      analyze_stmt = function(stmt, stmt_scope)
        if not stmt then return end
        local st = stmt.type
        if st == 'LocalDecl' then
          for _, v in ipairs(stmt.values or {}) do
            analyze_expr(v, stmt_scope)
          end
          for _, n in ipairs(stmt.names or {}) do
            declare_symbol(stmt_scope, n, 'localdecl', stmt)
          end
          return
        end
        if st == 'LocalFunc' then
          declare_symbol(stmt_scope, stmt.name, 'localfunc', stmt)
          local lf_scope = new_scope(stmt_scope)
          for _, p in ipairs((stmt.body and stmt.body.params) or {}) do
            declare_symbol(lf_scope, p, 'param', stmt)
          end
          if stmt.body and stmt.body.body and stmt.body.body.statements then
            local body2 = new_scope(lf_scope)
            for _, s2 in ipairs(stmt.body.body.statements) do
              analyze_stmt(s2, body2)
            end
          end
          return
        end
        if st == 'FunctionDecl' then
          if stmt.name and (stmt.name:find('%.', 1, true) or stmt.name:find(':', 1, true)) then
            local head = split_identifier_path(stmt.name)[1]
            local sym = lookup_symbol(stmt_scope, head)
            if sym then sym.refs = sym.refs + 1 end
          end
          local fd_scope = new_scope(stmt_scope)
          for _, p in ipairs(stmt.params or {}) do
            declare_symbol(fd_scope, p, 'param', stmt)
          end
          if stmt.body and stmt.body.statements then
            local body3 = new_scope(fd_scope)
            for _, s3 in ipairs(stmt.body.statements) do
              analyze_stmt(s3, body3)
            end
          end
          return
        end
        if st == 'If' then
          analyze_expr(stmt.condition, stmt_scope)
          local ts = new_scope(stmt_scope)
          for _, s in ipairs((stmt.then_body and stmt.then_body.statements) or {}) do
            analyze_stmt(s, ts)
          end
          for _, p in ipairs(stmt.elseif_parts or {}) do
            analyze_expr(p.condition, stmt_scope)
            local es = new_scope(stmt_scope)
            for _, s in ipairs((p.body and p.body.statements) or {}) do
              analyze_stmt(s, es)
            end
          end
          if stmt.else_body then
            local es2 = new_scope(stmt_scope)
            for _, s in ipairs(stmt.else_body.statements or {}) do
              analyze_stmt(s, es2)
            end
          end
          return
        end
        if st == 'While' then
          analyze_expr(stmt.condition, stmt_scope)
          local ws = new_scope(stmt_scope)
          for _, s in ipairs((stmt.body and stmt.body.statements) or {}) do
            analyze_stmt(s, ws)
          end
          return
        end
        if st == 'Repeat' then
          local rs = new_scope(stmt_scope)
          for _, s in ipairs((stmt.body and stmt.body.statements) or {}) do
            analyze_stmt(s, rs)
          end
          analyze_expr(stmt.condition, rs)
          return
        end
        if st == 'For' then
          analyze_expr(stmt.start, stmt_scope)
          analyze_expr(stmt.finish, stmt_scope)
          if stmt.step then analyze_expr(stmt.step, stmt_scope) end
          local fs = new_scope(stmt_scope)
          declare_symbol(fs, stmt.var, 'forvar', stmt)
          local body4 = new_scope(fs)
          for _, s in ipairs((stmt.body and stmt.body.statements) or {}) do
            analyze_stmt(s, body4)
          end
          return
        end
        if st == 'ForIn' then
          for _, it in ipairs(stmt.iterators or {}) do
            analyze_expr(it, stmt_scope)
          end
          local fs = new_scope(stmt_scope)
          for _, v in ipairs(stmt.vars or {}) do
            declare_symbol(fs, v, 'forvar', stmt)
          end
          local body4 = new_scope(fs)
          for _, s in ipairs((stmt.body and stmt.body.statements) or {}) do
            analyze_stmt(s, body4)
          end
          return
        end
        if st == 'Do' then
          local ds = new_scope(stmt_scope)
          for _, s in ipairs((stmt.body and stmt.body.statements) or {}) do
            analyze_stmt(s, ds)
          end
          return
        end
        if st == 'Assignment' then
          for _, v in ipairs(stmt.values or {}) do
            analyze_expr(v, stmt_scope)
          end
          for _, target in ipairs(stmt.targets or {}) do
            if target.type == 'IndexExpr' then
              analyze_expr(target.object, stmt_scope)
              analyze_expr(target.index, stmt_scope)
            elseif target.type == 'PropertyExpr' then
              analyze_expr(target.object, stmt_scope)
            end
          end
          return
        end
        if st == 'Return' then
          for _, v in ipairs(stmt.values or {}) do
            analyze_expr(v, stmt_scope)
          end
          return
        end
        analyze_expr(stmt, stmt_scope)
      end
      for _, stmt in ipairs(stmts) do
        analyze_stmt(stmt, body_scope)
      end
    end
    return
  end
end

local function analyze_ast(ast)
  local decl_symbols = {}
  local localfunc_symbol = {}

  local function ensure_decl_list(node)
    local arr = decl_symbols[node]
    if not arr then
      arr = {}
      decl_symbols[node] = arr
    end
    return arr
  end

  local analyze_stmt
  local analyze_block

  analyze_block = function(block, parent_scope, create_scope)
    if not block then return end
    local scope = parent_scope
    if create_scope ~= false then
      scope = new_scope(parent_scope)
    end
    for _, stmt in ipairs(block.statements or {}) do
      analyze_stmt(stmt, scope)
    end
  end

  analyze_stmt = function(node, scope)
    if not node then return end
    local t = node.type

    if t == 'LocalDecl' then
      for _, value in ipairs(node.values or {}) do
        analyze_expr(value, scope)
      end
      local arr = ensure_decl_list(node)
      for _, name in ipairs(node.names or {}) do
        arr[#arr + 1] = declare_symbol(scope, name, 'localdecl', node)
      end
      return
    end

    if t == 'LocalFunc' then
      local sym = declare_symbol(scope, node.name, 'localfunc', node)
      localfunc_symbol[node] = sym
      local fn_scope = new_scope(scope)
      for _, p in ipairs((node.body and node.body.params) or {}) do
        declare_symbol(fn_scope, p, 'param', node)
      end
      if node.body and node.body.body then
        analyze_block(node.body.body, fn_scope, true)
      end
      return
    end

    if t == 'FunctionDecl' then
      if node.name and (node.name:find('%.', 1, true) or node.name:find(':', 1, true)) then
        local head = split_identifier_path(node.name)[1]
        local sym = lookup_symbol(scope, head)
        if sym then
          sym.refs = sym.refs + 1
        end
      end
      local fn_scope = new_scope(scope)
      for _, p in ipairs(node.params or {}) do
        declare_symbol(fn_scope, p, 'param', node)
      end
      analyze_block(node.body, fn_scope, true)
      return
    end

    if t == 'If' then
      analyze_expr(node.condition, scope)
      analyze_block(node.then_body, scope, true)
      for _, p in ipairs(node.elseif_parts or {}) do
        analyze_expr(p.condition, scope)
        analyze_block(p.body, scope, true)
      end
      if node.else_body then
        analyze_block(node.else_body, scope, true)
      end
      return
    end

    if t == 'While' then
      analyze_expr(node.condition, scope)
      analyze_block(node.body, scope, true)
      return
    end

    if t == 'Repeat' then
      local rep_scope = new_scope(scope)
      analyze_block(node.body, rep_scope, true)
      analyze_expr(node.condition, rep_scope)
      return
    end

    if t == 'For' then
      analyze_expr(node.start, scope)
      analyze_expr(node.finish, scope)
      if node.step then analyze_expr(node.step, scope) end
      local for_scope = new_scope(scope)
      declare_symbol(for_scope, node.var, 'forvar', node)
      analyze_block(node.body, for_scope, true)
      return
    end

    if t == 'ForIn' then
      for _, it in ipairs(node.iterators or {}) do
        analyze_expr(it, scope)
      end
      local for_scope = new_scope(scope)
      for _, v in ipairs(node.vars or {}) do
        declare_symbol(for_scope, v, 'forvar', node)
      end
      analyze_block(node.body, for_scope, true)
      return
    end

    if t == 'Do' then
      analyze_block(node.body, scope, true)
      return
    end

    if t == 'Assignment' then
      for _, value in ipairs(node.values or {}) do
        analyze_expr(value, scope)
      end
      for _, target in ipairs(node.targets or {}) do
        if target.type == 'IndexExpr' then
          analyze_expr(target.object, scope)
          analyze_expr(target.index, scope)
        elseif target.type == 'PropertyExpr' then
          analyze_expr(target.object, scope)
        end
      end
      return
    end

    if t == 'Return' then
      for _, value in ipairs(node.values or {}) do
        analyze_expr(value, scope)
      end
      return
    end

    analyze_expr(node, scope)
  end

  local root_scope = new_scope(nil)
  if ast and ast.type == 'Chunk' and ast.body then
    analyze_block(ast.body, root_scope, false)
  end
  return decl_symbols, localfunc_symbol
end

local function is_pure_expr(node)
  if not node or type(node) ~= 'table' then
    return true
  end
  local t = node.type
  if t == 'Number' or t == 'String' or t == 'Boolean' or t == 'Nil' or t == 'Identifier' or t == 'VarArgs' then
    return true
  end
  if t == 'UnaryOp' then
    return is_pure_expr(node.operand)
  end
  if t == 'BinaryOp' then
    return is_pure_expr(node.left) and is_pure_expr(node.right)
  end
  if t == 'Table' then
    for _, f in ipairs(node.fields or {}) do
      if f.key and not is_pure_expr(f.key) then
        return false
      end
      if not is_pure_expr(f.value) then
        return false
      end
    end
    return true
  end
  if t == 'Function' then
    return true
  end
  return false
end

local function prune_once(ast)
  local decl_symbols, localfunc_symbol = analyze_ast(ast)
  local changed = false

  local prune_stmt
  local prune_block

  prune_block = function(block)
    if not block or not block.statements then
      return
    end
    local out = {}
    for _, stmt in ipairs(block.statements) do
      local keep = prune_stmt(stmt)
      if keep then
        out[#out + 1] = keep
      else
        changed = true
      end
    end
    block.statements = out
  end

  prune_stmt = function(stmt)
    if not stmt then return nil end
    local t = stmt.type

    if t == 'If' then
      prune_block(stmt.then_body)
      for _, p in ipairs(stmt.elseif_parts or {}) do
        prune_block(p.body)
      end
      if stmt.else_body then
        prune_block(stmt.else_body)
      end
      return stmt
    end
    if t == 'While' or t == 'Repeat' or t == 'For' or t == 'ForIn' or t == 'Do' then
      prune_block(stmt.body)
      if t == 'Do' and stmt.body and stmt.body.statements and #stmt.body.statements == 0 then
        return nil
      end
      return stmt
    end
    if t == 'FunctionDecl' then
      prune_block(stmt.body)
      return stmt
    end
    if t == 'LocalFunc' then
      if stmt.body and stmt.body.body then
        prune_block(stmt.body.body)
      end
      local sym = localfunc_symbol[stmt]
      if sym and sym.refs == 0 then
        return nil
      end
      return stmt
    end
    if t == 'LocalDecl' then
      local syms = decl_symbols[stmt] or {}
      if #syms == 0 then
        return stmt
      end
      local all_unused = true
      for _, s in ipairs(syms) do
        if s.refs > 0 then
          all_unused = false
          break
        end
      end
      if all_unused then
        local pure = true
        for _, v in ipairs(stmt.values or {}) do
          if not is_pure_expr(v) then
            pure = false
            break
          end
        end
        if pure then
          return nil
        end
      end
      return stmt
    end
    return stmt
  end

  if ast and ast.type == 'Chunk' and ast.body then
    prune_block(ast.body)
  end
  return changed
end

local function can_compile(code)
  if type(load) == 'function' then
    local fn = load(code)
    return fn ~= nil
  end
  if type(loadstring) == 'function' then
    local fn = loadstring(code)
    return fn ~= nil
  end
  return true
end

local function can_parse(code, dialect)
  local ok = pcall(function()
    local tokens = Lexer.new(code, { dialect = dialect }):tokenize()
    local parser = Parser.new(tokens, { dialect = dialect })
    parser:parse()
  end)
  return ok
end

function NoCode.clean(source, options)
  options = options or {}
  local dialect = options.dialect
  local ok, result = pcall(function()
    local tokens = Lexer.new(source, { dialect = dialect }):tokenize()
    local parser = Parser.new(tokens, { dialect = dialect })
    local ast = parser:parse()

    ast = Optimizer.optimize(ast)
    local iter = 0
    while iter < 20 do
      iter = iter + 1
      local changed = prune_once(ast)
      if not changed then
        break
      end
      ast = Optimizer.optimize(ast)
    end

    local codegen = CodeGen.new(nil)
    codegen.preserve_indent_for_line = function(_, line)
      return line
    end
    return codegen:generate(ast.body)
  end)

  if not ok or type(result) ~= 'string' or result == '' then
    return source, { all_locals = {} }
  end

  local src_parse_ok = can_parse(source, dialect)
  local src_compile_ok = can_compile(source)
  local candidate = result

  local candidate_parse_ok = can_parse(candidate, dialect)
  if src_parse_ok and not candidate_parse_ok then
    return source, { all_locals = {} }
  end

  local candidate_compile_ok = can_compile(candidate)
  if src_compile_ok and not candidate_compile_ok then
    return source, { all_locals = {} }
  end

  return candidate, { all_locals = {} }
end

return NoCode
