local LexerFull = require('src.lexer_full')

local DeleteOut = {}

local function is_wordlike(tok)
  return tok.type == 'keyword' or tok.type == 'ident' or tok.type == 'number' or tok.type == 'string' or tok.type == 'long_string'
end

local merge_pairs = {
  ['--'] = true, ['=='] = true, ['~='] = true, ['<='] = true, ['>='] = true,
  ['<<'] = true, ['>>'] = true, ['//'] = true, ['..'] = true, ['...'] = true,
  ['::'] = true, ['+='] = true, ['-='] = true, ['*='] = true, ['/='] = true,
  ['%='] = true, ['^='] = true, ['&='] = true, ['|='] = true, ['..='] = true,
  ['->'] = true, ['=>'] = true, [':='] = true, ['&&'] = true, ['||'] = true
}

local function needs_space(prev, nxt)
  if not prev or not nxt then return false end
  if is_wordlike(prev) and is_wordlike(nxt) then return true end
  if prev.type == 'number' and nxt.type == 'symbol' and nxt.value:sub(1, 1) == '.' then return true end
  if prev.type == 'symbol' and nxt.type == 'symbol' then
    if merge_pairs[prev.value .. nxt.value] then return true end
    if prev.value:sub(-1) == '.' and nxt.value:sub(1, 1) == '.' then return true end
  end
  if prev.type == 'symbol' and prev.value == '[' and (nxt.value == '[' or nxt.value:sub(1, 1) == '=') then return true end
  if prev.type == 'symbol' and prev.value == ']' and nxt.value == ']' then return true end
  if prev.type == 'symbol' and prev.value == ':' and nxt.value == ':' then return true end
  return false
end

local function build_line_starts(source)
  local starts = { 1 }
  for i = 1, #source do
    if source:byte(i) == 10 then
      starts[#starts + 1] = i + 1
    end
  end
  return starts
end

local function token_start_pos(token, line_starts)
  if not token or not token.line or not token.col then
    return nil
  end
  local line_start = line_starts[token.line]
  if not line_start then
    return nil
  end
  return line_start + token.col - 1
end

local function keep_newlines_only(s)
  return (s:gsub('[^\r\n]', ''))
end

local function prev_code_token(tokens, idx)
  for i = idx - 1, 1, -1 do
    local t = tokens[i]
    if t.type ~= 'comment' and t.type ~= 'newline' then
      return t
    end
  end
  return nil
end

local function next_code_token(tokens, idx)
  for i = idx + 1, #tokens do
    local t = tokens[i]
    if t.type ~= 'comment' and t.type ~= 'newline' then
      return t
    end
  end
  return nil
end

function DeleteOut.strip(source, options)
  options = options or {}
  local lexer = LexerFull.new(source, { dialect = options.dialect })
  local tokens = lexer:tokenize()
  local line_starts = build_line_starts(source)
  local ranges = {}

  for i, tok in ipairs(tokens) do
    if tok.type == 'comment' then
      local start_pos = token_start_pos(tok, line_starts)
      if start_pos then
        local end_pos = start_pos + #tok.value - 1
        local replacement = keep_newlines_only(tok.value)

        if replacement == '' then
          local prev = prev_code_token(tokens, i)
          local nxt = next_code_token(tokens, i)
          if needs_space(prev, nxt) then
            replacement = ' '
          end
        end

        ranges[#ranges + 1] = {
          start_pos = start_pos,
          end_pos = end_pos,
          replacement = replacement
        }
      end
    end
  end

  if #ranges == 0 then
    return source
  end

  table.sort(ranges, function(a, b)
    return a.start_pos < b.start_pos
  end)

  local out = {}
  local cursor = 1
  for _, r in ipairs(ranges) do
    if r.start_pos > cursor then
      out[#out + 1] = source:sub(cursor, r.start_pos - 1)
    end
    out[#out + 1] = r.replacement
    cursor = r.end_pos + 1
  end
  if cursor <= #source then
    out[#out + 1] = source:sub(cursor)
  end

  return table.concat(out)
end

return DeleteOut
