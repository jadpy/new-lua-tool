local TraceLint = {}

local LintSandbox = require('src.lint_sandbox')

local TIMEOUT_SENTINEL = '__TRACELINT_TIMEOUT__'

local function summarize_key_counts(map, max_items)
  local out = {}
  for k, v in pairs(map or {}) do
    out[#out + 1] = { name = tostring(k), count = tonumber(v) or 0 }
  end
  table.sort(out, function(a, b)
    if a.count ~= b.count then
      return a.count > b.count
    end
    return a.name < b.name
  end)
  local total_keys = #out
  local omitted = 0
  if max_items and max_items > 0 and #out > max_items then
    omitted = #out - max_items
    for i = #out, max_items + 1, -1 do
      out[i] = nil
    end
  end
  return out, total_keys, omitted
end

local function summarize_events(events, max_items)
  local out = {}
  for _, e in ipairs(events or {}) do
    out[#out + 1] = {
      level = tostring(e.level or 'info'),
      code = tostring(e.code or 'sandbox-event'),
      message = tostring(e.message or ''),
      count = tonumber(e.count) or 0
    }
  end
  table.sort(out, function(a, b)
    if a.count ~= b.count then
      return a.count > b.count
    end
    if a.level ~= b.level then
      return a.level < b.level
    end
    if a.code ~= b.code then
      return a.code < b.code
    end
    return a.message < b.message
  end)
  local total = #out
  local omitted = 0
  if max_items and max_items > 0 and #out > max_items then
    omitted = #out - max_items
    for i = #out, max_items + 1, -1 do
      out[i] = nil
    end
  end
  return out, total, omitted
end

local function summarize_history(history, total, omitted, max_items)
  local src = history or {}
  local out = {}
  local maxn = max_items and max_items > 0 and max_items or #src
  for i = 1, math.min(#src, maxn) do
    local h = src[i]
    out[#out + 1] = {
      seq = tonumber(h.seq) or i,
      kind = tostring(h.kind or 'event'),
      message = tostring(h.message or '')
    }
  end
  local total_count = tonumber(total) or #src
  local omitted_count = tonumber(omitted) or 0
  if #src > #out then
    omitted_count = omitted_count + (#src - #out)
  end
  return out, total_count, omitted_count
end

local function describe_value(v)
  local tv = type(v)
  if tv == 'table' then
    local p = rawget(v, '__path')
    if p then
      return 'proxy:' .. tostring(p)
    end
    return 'table'
  end
  if tv == 'function' then
    return 'function'
  end
  if tv == 'string' then
    local s = v
    if #s > 160 then
      s = s:sub(1, 157) .. '...'
    end
    return 'string:' .. s
  end
  return tv .. ':' .. tostring(v)
end

local function load_chunk(source, chunk_name, env)
  if type(load) == 'function' then
    return load(source, chunk_name, 't', env)
  end
  if type(loadstring) == 'function' then
    local fn, err = loadstring(source, chunk_name)
    if not fn then
      return nil, err
    end
    if type(setfenv) == 'function' then
      setfenv(fn, env)
    end
    return fn
  end
  return nil, 'no load function available'
end

local function set_hook(max_instructions)
  if type(debug) ~= 'table' or type(debug.gethook) ~= 'function' or type(debug.sethook) ~= 'function' then
    return { enabled = false, timeout = false }
  end
  local old_hook, old_mask, old_count = debug.gethook()
  local stride = 1000
  if max_instructions > 2000000 then
    stride = 4000
  elseif max_instructions > 1000000 then
    stride = 2000
  end
  local state = {
    enabled = true,
    timeout = false,
    old_hook = old_hook,
    old_mask = old_mask,
    old_count = old_count,
    stride = stride,
    budget = max_instructions
  }
  debug.sethook(function()
    state.budget = state.budget - state.stride
    if state.budget <= 0 then
      state.timeout = true
      error(TIMEOUT_SENTINEL)
    end
  end, '', stride)
  return state
end

local function clear_hook(state)
  if not state or not state.enabled then
    return
  end
  pcall(debug.sethook, state.old_hook, state.old_mask, state.old_count)
end

local function build_output_log(items, omitted)
  local out = {}
  for _, item in ipairs(items or {}) do
    out[#out + 1] = string.format('[%04d] %s: %s', tonumber(item.seq) or 0, tostring(item.kind), tostring(item.message))
  end
  if (tonumber(omitted) or 0) > 0 then
    out[#out + 1] = string.format('... omitted %d output entries', tonumber(omitted) or 0)
  end
  return table.concat(out, '\n')
end

function TraceLint.run(source, options)
  options = options or {}

  local max_instructions = tonumber(options.max_instructions) or 800000
  if max_instructions < 1000 then
    max_instructions = 1000
  end
  local max_records = tonumber(options.max_records) or 160
  if max_records < 10 then
    max_records = 10
  end

  local max_output_items = tonumber(options.max_output_items) or 400
  if max_output_items < 10 then
    max_output_items = 10
  end
  local max_output_bytes = tonumber(options.max_output_bytes) or 240000
  if max_output_bytes < 1024 then
    max_output_bytes = 1024
  end

  local started = os.clock()
  local env, trace = LintSandbox.build(options)

  local output_items = {}
  local output_omitted = 0
  local output_bytes = 0
  local function record_output(kind, ...)
    local parts = {}
    for i = 1, select('#', ...) do
      parts[#parts + 1] = tostring(select(i, ...))
    end
    local msg = table.concat(parts, ' ')
    if #output_items < max_output_items and (output_bytes + #msg) <= max_output_bytes then
      output_items[#output_items + 1] = {
        seq = #output_items + 1,
        kind = tostring(kind or 'print'),
        message = msg
      }
    else
      output_omitted = output_omitted + 1
    end
    output_bytes = output_bytes + #msg
    return ...
  end

  rawset(env, 'print', function(...) return record_output('print', ...) end)
  rawset(env, 'warn', function(...) return record_output('warn', ...) end)

  local base_io = env.io
  if type(base_io) == 'table' then
    local io_wrap = {}
    for k, v in pairs(base_io) do
      io_wrap[k] = v
    end
    io_wrap.write = function(...)
      return record_output('io.write', ...)
    end
    rawset(env, 'io', io_wrap)
  end

  local compile_source = source
  local normalization = { compile_source = 'original' }

  local chunk, compile_err = load_chunk(compile_source, '@tracelint', env)

  -- Many interactive inputs are expressions (ex: `game:GetService("Players").LocalPlayer.Name`),
  -- which are not valid top-level statements in Lua. If compilation fails, try treating the
  -- whole input as an expression and return it.
  if not chunk and options.expr_fallback ~= false then
    local expr_source = 'return ' .. tostring(source or '')
    local expr_chunk, expr_err = load_chunk(expr_source, '@tracelint', env)
    if expr_chunk then
      chunk = expr_chunk
      compile_err = nil
      compile_source = expr_source
      normalization = { compile_source = 'return-expr' }
    else
      normalization = { compile_source = 'original', expr_fallback_error = tostring(expr_err) }
    end
  end
  if not chunk then
    local elapsed = math.floor((os.clock() - started) * 1000)
    local events, ev_total, ev_omit = summarize_events(trace.events, max_records)
    local history, h_total, h_omit = summarize_history(trace.history, trace._history_total, trace._history_omitted, max_records)
    return {
      ok = false,
      phase = 'compile',
      timeout = false,
      error = tostring(compile_err),
      duration_ms = elapsed,
      output = {
        items = output_items,
        omitted = output_omitted,
        bytes = output_bytes
      },
      returns = {},
      normalization = normalization,
      events = events,
      history = history,
      history_stats = { total = h_total, omitted = h_omit },
      map_stats = {
        events = { total = ev_total, omitted = ev_omit },
        history = { total = h_total, omitted = h_omit }
      },
      limits = {
        max_instructions = max_instructions,
        max_records = max_records,
        max_output_items = max_output_items,
        max_output_bytes = max_output_bytes
      },
      sandbox = { isolated = true }
    }, build_output_log(output_items, output_omitted)
  end

  local timeout = false
  local runtime_err = nil
  local hook_state = set_hook(max_instructions)
  local exec = { pcall(chunk) }
  local ran_ok = exec[1] == true
  local returns = {}
  local raw_returns = {}
  if ran_ok then
    for i = 2, #exec do
      raw_returns[#raw_returns + 1] = exec[i]
      returns[#returns + 1] = describe_value(exec[i])
    end

    -- If we normalized an expression into `return <expr>`, show the computed value in the output log
    -- so callers don't need to open JSON just to see it.
    if normalization and normalization.compile_source == 'return-expr' then
      if #raw_returns == 0 then
        record_output('return', 'no found')
      else
        for i = 1, #raw_returns do
          local v = raw_returns[i]
          if v == nil then
            record_output('return', 'no found')
          elseif type(v) == 'table' and rawget(v, '__kind') == 'instance' then
            record_output('return', 'found', tostring(v))
          else
            record_output('return', v)
          end
        end
      end
    end
  else
    runtime_err = tostring(exec[2])
  end
  clear_hook(hook_state)
  timeout = hook_state.timeout == true

  if timeout then
    if not runtime_err then
      runtime_err = 'tracelint timeout'
    elseif runtime_err:find(TIMEOUT_SENTINEL, 1, true) then
      runtime_err = 'tracelint timeout'
    end
  end

  local all_global_reads, agr_total, agr_omit = summarize_key_counts(trace.all_global_reads, max_records)
  local resolved_global_reads, rgr_total, rgr_omit = summarize_key_counts(trace.resolved_global_reads, max_records)
  local global_reads, gr_total, gr_omit = summarize_key_counts(trace.global_reads, max_records)
  local global_writes, gw_total, gw_omit = summarize_key_counts(trace.global_writes, max_records)
  local undefined_global_reads, ug_total, ug_omit = summarize_key_counts(trace.undefined_global_reads, max_records)
  local proxy_root_reads, sr_total, sr_omit = summarize_key_counts(trace.proxy_root_reads, max_records)
  local proxy_reads, pr_total, pr_omit = summarize_key_counts(trace.proxy_reads, max_records)
  local require_calls, rq_total, rq_omit = summarize_key_counts(trace.require_calls, max_records)
  local metatable_gets, mg_total, mg_omit = summarize_key_counts(trace.metatable_gets, max_records)
  local metatable_sets, ms_total, ms_omit = summarize_key_counts(trace.metatable_sets, max_records)
  local metatable_metamethods, mm_total, mm_omit = summarize_key_counts(trace.metatable_metamethods, max_records)
  local events, ev_total, ev_omit = summarize_events(trace.events, max_records)
  local history, h_total, h_omit = summarize_history(trace.history, trace._history_total, trace._history_omitted, max_records)

  local elapsed = math.floor((os.clock() - started) * 1000)
  local ok = ran_ok and not timeout

  local result = {
    ok = ok,
    phase = 'runtime',
    timeout = timeout,
    error = runtime_err,
    duration_ms = elapsed,
    output = {
      items = output_items,
      omitted = output_omitted,
      bytes = output_bytes
    },
    returns = returns,
    normalization = normalization,
    all_global_reads = all_global_reads,
    resolved_global_reads = resolved_global_reads,
    global_reads = global_reads,
    global_writes = global_writes,
    undefined_global_reads = undefined_global_reads,
    proxy_root_reads = proxy_root_reads,
    proxy_reads = proxy_reads,
    require_calls = require_calls,
    metatable_gets = metatable_gets,
    metatable_sets = metatable_sets,
    metatable_metamethods = metatable_metamethods,
    events = events,
    history = history,
    history_stats = { total = h_total, omitted = h_omit },
    dependencies = {
      globals = {
        reads = all_global_reads,
        resolved_reads = resolved_global_reads,
        unresolved_reads = global_reads,
        undefined_reads = undefined_global_reads,
        writes = global_writes
      },
      metatable = {
        gets = metatable_gets,
        sets = metatable_sets,
        metamethod_keys = metatable_metamethods
      },
      proxies = {
        roots = proxy_root_reads,
        reads = proxy_reads
      },
      require = require_calls
    },
    map_stats = {
      all_global_reads = { total = agr_total, omitted = agr_omit },
      resolved_global_reads = { total = rgr_total, omitted = rgr_omit },
      global_reads = { total = gr_total, omitted = gr_omit },
      global_writes = { total = gw_total, omitted = gw_omit },
      undefined_global_reads = { total = ug_total, omitted = ug_omit },
      proxy_root_reads = { total = sr_total, omitted = sr_omit },
      proxy_reads = { total = pr_total, omitted = pr_omit },
      require_calls = { total = rq_total, omitted = rq_omit },
      metatable_gets = { total = mg_total, omitted = mg_omit },
      metatable_sets = { total = ms_total, omitted = ms_omit },
      metatable_metamethods = { total = mm_total, omitted = mm_omit },
      history = { total = h_total, omitted = h_omit },
      events = { total = ev_total, omitted = ev_omit }
    },
    limits = {
      max_instructions = max_instructions,
      max_records = max_records,
      max_output_items = max_output_items,
      max_output_bytes = max_output_bytes
    },
    sandbox = { isolated = true }
  }

  return result, build_output_log(output_items, output_omitted)
end

return TraceLint
