local Json = {}

local function escape_str(s)
  if type(s) ~= 'string' or s == '' then
    return ''
  end
  local out = {}
  for i = 1, #s do
    local b = s:byte(i)
    if b == 92 then -- backslash
      out[#out + 1] = '\\\\'
    elseif b == 34 then -- quote
      out[#out + 1] = '\\"'
    elseif b == 8 then
      out[#out + 1] = '\\b'
    elseif b == 12 then
      out[#out + 1] = '\\f'
    elseif b == 10 then
      out[#out + 1] = '\\n'
    elseif b == 13 then
      out[#out + 1] = '\\r'
    elseif b == 9 then
      out[#out + 1] = '\\t'
    elseif b < 32 or b > 126 then
      out[#out + 1] = string.format('\\u%04x', b)
    else
      out[#out + 1] = string.char(b)
    end
  end
  return table.concat(out)
end

local function is_array(t)
  local count = 0
  local max = 0
  for k, _ in pairs(t) do
    if type(k) ~= 'number' or k < 1 or k % 1 ~= 0 then
      return false, 0
    end
    if k > max then
      max = k
    end
    count = count + 1
  end
  if count == 0 then
    return true, 0
  end
  if max ~= count then
    return false, 0
  end
  return true, max
end

local function sort_object_keys(t)
  local keys = {}
  for k, _ in pairs(t) do
    keys[#keys + 1] = tostring(k)
  end
  table.sort(keys)
  return keys
end

local function encode_value(v, pretty, indent, level, seen)
  local tv = type(v)
  if tv == 'nil' then
    return 'null'
  end
  if tv == 'boolean' then
    return v and 'true' or 'false'
  end
  if tv == 'number' then
    if v ~= v or v == math.huge or v == -math.huge then
      return 'null'
    end
    return tostring(v)
  end
  if tv == 'string' then
    return '"' .. escape_str(v) .. '"'
  end
  if tv ~= 'table' then
    return '"' .. escape_str(tostring(v)) .. '"'
  end

  if seen[v] then
    return '"<cycle>"'
  end
  seen[v] = true

  local newline = pretty and '\n' or ''
  local space = pretty and ' ' or ''
  local cur_indent = pretty and string.rep(indent, level) or ''
  local next_indent = pretty and string.rep(indent, level + 1) or ''

  local arr, n = is_array(v)
  if arr then
    if n == 0 then
      seen[v] = nil
      return '[]'
    end
    local parts = {}
    for i = 1, n do
      parts[#parts + 1] = encode_value(v[i], pretty, indent, level + 1, seen)
    end
    local out
    if pretty then
      out = '[' .. newline
      for i, p in ipairs(parts) do
        out = out .. next_indent .. p
        if i < #parts then out = out .. ',' end
        out = out .. newline
      end
      out = out .. cur_indent .. ']'
    else
      out = '[' .. table.concat(parts, ',') .. ']'
    end
    seen[v] = nil
    return out
  end

  local keys = sort_object_keys(v)
  if #keys == 0 then
    seen[v] = nil
    return '{}'
  end

  local out
  if pretty then
    out = '{' .. newline
    for i, k in ipairs(keys) do
      local raw = v[k]
      if raw == nil then
        raw = v[tonumber(k)]
      end
      out = out .. next_indent .. '"' .. escape_str(k) .. '":' .. space
        .. encode_value(raw, pretty, indent, level + 1, seen)
      if i < #keys then out = out .. ',' end
      out = out .. newline
    end
    out = out .. cur_indent .. '}'
  else
    local parts = {}
    for _, k in ipairs(keys) do
      local raw = v[k]
      if raw == nil then
        raw = v[tonumber(k)]
      end
      parts[#parts + 1] = '"' .. escape_str(k) .. '":' .. encode_value(raw, pretty, indent, level + 1, seen)
    end
    out = '{' .. table.concat(parts, ',') .. '}'
  end

  seen[v] = nil
  return out
end

function Json.encode(value, pretty)
  local use_pretty = pretty ~= false
  return encode_value(value, use_pretty, '  ', 0, {})
end

local function decode_error(input, pos, msg)
  error(string.format('JSON decode error at %d: %s', pos, msg))
end

local function skip_ws(input, pos)
  while pos <= #input do
    local c = input:sub(pos, pos)
    if c == ' ' or c == '\n' or c == '\r' or c == '\t' then
      pos = pos + 1
    else
      break
    end
  end
  return pos
end

local function parse_string(input, pos)
  if input:sub(pos, pos) ~= '"' then
    decode_error(input, pos, 'expected string')
  end
  pos = pos + 1
  local out = {}
  while pos <= #input do
    local c = input:sub(pos, pos)
    if c == '"' then
      return table.concat(out), pos + 1
    end
    if c == '\\' then
      local esc = input:sub(pos + 1, pos + 1)
      if esc == '"' then out[#out + 1] = '"' ; pos = pos + 2
      elseif esc == '\\' then out[#out + 1] = '\\' ; pos = pos + 2
      elseif esc == '/' then out[#out + 1] = '/' ; pos = pos + 2
      elseif esc == 'b' then out[#out + 1] = '\b' ; pos = pos + 2
      elseif esc == 'f' then out[#out + 1] = '\f' ; pos = pos + 2
      elseif esc == 'n' then out[#out + 1] = '\n' ; pos = pos + 2
      elseif esc == 'r' then out[#out + 1] = '\r' ; pos = pos + 2
      elseif esc == 't' then out[#out + 1] = '\t' ; pos = pos + 2
      elseif esc == 'u' then
        local hex = input:sub(pos + 2, pos + 5)
        if #hex ~= 4 or not hex:match('^[%x][%x][%x][%x]$') then
          decode_error(input, pos, 'invalid unicode escape')
        end
        local code = tonumber(hex, 16)
        if code and code <= 0x7F then
          out[#out + 1] = string.char(code)
        else
          out[#out + 1] = '?'
        end
        pos = pos + 6
      else
        decode_error(input, pos, 'invalid escape sequence')
      end
    else
      out[#out + 1] = c
      pos = pos + 1
    end
  end
  decode_error(input, pos, 'unterminated string')
end

local function parse_number(input, pos)
  local s, e = input:find('^-?%d+%.?%d*[eE][%+%-]?%d+', pos)
  if not s then
    s, e = input:find('^-?%d+%.%d+', pos)
  end
  if not s then
    s, e = input:find('^-?%d+', pos)
  end
  if not s then
    decode_error(input, pos, 'invalid number')
  end
  local n = tonumber(input:sub(s, e))
  if n == nil then
    decode_error(input, pos, 'invalid number')
  end
  return n, e + 1
end

local parse_value

local function parse_array(input, pos)
  local arr = {}
  pos = pos + 1
  pos = skip_ws(input, pos)
  if input:sub(pos, pos) == ']' then
    return arr, pos + 1
  end
  while true do
    local v
    v, pos = parse_value(input, pos)
    arr[#arr + 1] = v
    pos = skip_ws(input, pos)
    local c = input:sub(pos, pos)
    if c == ',' then
      pos = skip_ws(input, pos + 1)
    elseif c == ']' then
      return arr, pos + 1
    else
      decode_error(input, pos, 'expected "," or "]"')
    end
  end
end

local function parse_object(input, pos)
  local obj = {}
  pos = pos + 1
  pos = skip_ws(input, pos)
  if input:sub(pos, pos) == '}' then
    return obj, pos + 1
  end
  while true do
    local key
    if input:sub(pos, pos) ~= '"' then
      decode_error(input, pos, 'expected object key string')
    end
    key, pos = parse_string(input, pos)
    pos = skip_ws(input, pos)
    if input:sub(pos, pos) ~= ':' then
      decode_error(input, pos, 'expected ":" after key')
    end
    pos = skip_ws(input, pos + 1)
    local value
    value, pos = parse_value(input, pos)
    obj[key] = value
    pos = skip_ws(input, pos)
    local c = input:sub(pos, pos)
    if c == ',' then
      pos = skip_ws(input, pos + 1)
    elseif c == '}' then
      return obj, pos + 1
    else
      decode_error(input, pos, 'expected "," or "}"')
    end
  end
end

parse_value = function(input, pos)
  pos = skip_ws(input, pos)
  local c = input:sub(pos, pos)
  if c == '"' then
    return parse_string(input, pos)
  end
  if c == '{' then
    return parse_object(input, pos)
  end
  if c == '[' then
    return parse_array(input, pos)
  end
  if c == '-' or c:match('%d') then
    return parse_number(input, pos)
  end
  if input:sub(pos, pos + 3) == 'true' then
    return true, pos + 4
  end
  if input:sub(pos, pos + 4) == 'false' then
    return false, pos + 5
  end
  if input:sub(pos, pos + 3) == 'null' then
    return nil, pos + 4
  end
  decode_error(input, pos, 'unexpected token')
end

function Json.decode(input)
  if type(input) ~= 'string' then
    error('Json.decode expects a string')
  end
  local value, pos = parse_value(input, 1)
  pos = skip_ws(input, pos)
  if pos <= #input then
    decode_error(input, pos, 'trailing characters')
  end
  return value
end

return Json
