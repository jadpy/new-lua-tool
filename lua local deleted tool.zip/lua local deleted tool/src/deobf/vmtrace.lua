local VMTrace = {}

local function safe_eval_number_expr(expr)
  if type(expr) ~= 'string' or expr == '' then
    return nil
  end
  if not expr:match('^[%d%+%-%*%%%/%^%(%)%s%.]+$') then
    return nil
  end
  if not expr:find('[%+%-%*%%%/%^]') then
    return nil
  end
  local fn = load('return ' .. expr, '@deobf_vmtrace', 't', {})
  if not fn then
    return nil
  end
  local ok, value = pcall(fn)
  if not ok or type(value) ~= 'number' or value ~= value or value == math.huge or value == -math.huge then
    return nil
  end
  if math.abs(value) > 1e12 then
    return nil
  end
  return math.floor(value)
end

local function push_limited(list, value, limit)
  if #list < limit then
    list[#list + 1] = value
  end
end

function VMTrace.extract(source, options)
  options = options or {}
  if type(source) ~= 'string' or source == '' then
    return {
      enabled = true,
      dispatcher_like = false,
      state_var = nil
    }
  end

  local max_sequence = tonumber(options.max_sequence) or 96
  local max_top_states = tonumber(options.max_top_states) or 20
  local max_transitions = tonumber(options.max_transitions) or 20
  local max_compare_values = tonumber(options.max_compare_values) or 24

  local state_var = source:match('while%s+([%a_][%w_]*)%s+do')
  local out = {
    enabled = true,
    dispatcher_like = state_var ~= nil,
    state_var = state_var,
    loop_count = 0,
    assignment_total = 0,
    unique_state_count = 0,
    first_states = {},
    top_states = {},
    transitions = {},
    less_than_thresholds = {},
    equality_values = {}
  }

  if not state_var then
    return out
  end

  for _ in source:gmatch('while%s+' .. state_var .. '%s+do') do
    out.loop_count = out.loop_count + 1
  end

  local state_freq = {}
  local sequence = {}
  local assign_pattern = state_var .. '%s*=%s*([%+%-]?[%d%(][%d%+%-%*%%%/%^%(%)%s%.]+)'
  for expr in source:gmatch(assign_pattern) do
    local value = safe_eval_number_expr(expr)
    if value ~= nil then
      out.assignment_total = out.assignment_total + 1
      state_freq[value] = (state_freq[value] or 0) + 1
      if #sequence < max_sequence then
        sequence[#sequence + 1] = value
      end
    end
  end

  local lt_values = {}
  local lt_seen = {}
  local lt_pattern = 'if%s+' .. state_var .. '%s*<%s*([%+%-]?[%d%(][%d%+%-%*%%%/%^%(%)%s%.]+)%s*then'
  for expr in source:gmatch(lt_pattern) do
    local value = safe_eval_number_expr(expr)
    if value ~= nil and not lt_seen[value] then
      lt_seen[value] = true
      push_limited(lt_values, value, max_compare_values)
    end
  end

  local eq_values = {}
  local eq_seen = {}
  local eq_pattern = state_var .. '%s*==%s*([%+%-]?[%d%(][%d%+%-%*%%%/%^%(%)%s%.]+)'
  for expr in source:gmatch(eq_pattern) do
    local value = safe_eval_number_expr(expr)
    if value ~= nil and not eq_seen[value] then
      eq_seen[value] = true
      push_limited(eq_values, value, max_compare_values)
    end
  end

  local unique_states = {}
  for value in pairs(state_freq) do
    unique_states[#unique_states + 1] = value
  end
  table.sort(unique_states)
  out.unique_state_count = #unique_states
  out.first_states = sequence
  out.less_than_thresholds = lt_values
  out.equality_values = eq_values

  local top_states = {}
  for value, count in pairs(state_freq) do
    top_states[#top_states + 1] = { state = value, hits = count }
  end
  table.sort(top_states, function(a, b)
    if a.hits == b.hits then
      return a.state < b.state
    end
    return a.hits > b.hits
  end)
  if #top_states > max_top_states then
    local trimmed = {}
    for i = 1, max_top_states do
      trimmed[i] = top_states[i]
    end
    top_states = trimmed
  end
  out.top_states = top_states

  local edge_hits = {}
  if #sequence >= 2 then
    for i = 1, #sequence - 1 do
      local a = sequence[i]
      local b = sequence[i + 1]
      local key = tostring(a) .. '->' .. tostring(b)
      edge_hits[key] = (edge_hits[key] or 0) + 1
    end
  end

  local edges = {}
  for key, hits in pairs(edge_hits) do
    local a, b = key:match('^([^%-]+)%-%>(.+)$')
    edges[#edges + 1] = {
      from = tonumber(a),
      to = tonumber(b),
      hits = hits
    }
  end
  table.sort(edges, function(a, b)
    if a.hits == b.hits then
      if a.from == b.from then
        return (a.to or 0) < (b.to or 0)
      end
      return (a.from or 0) < (b.from or 0)
    end
    return a.hits > b.hits
  end)
  if #edges > max_transitions then
    local trimmed = {}
    for i = 1, max_transitions do
      trimmed[i] = edges[i]
    end
    edges = trimmed
  end
  out.transitions = edges

  return out
end

return VMTrace
