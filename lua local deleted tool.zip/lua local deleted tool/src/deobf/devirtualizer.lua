local Devirtualizer = {}

local LexerFull = require('src.lexer_full')

local function eval_constant_expr(expr)
  if type(expr) ~= 'string' then
    return nil
  end
  local trimmed = expr:match('^%s*(.-)%s*$') or ''
  if trimmed == '' then
    return nil
  end
  if not trimmed:find('[%+%-%*%%%/%^]') then
    return nil
  end
  if not trimmed:match('^[%d%+%-%*%%%/%^%(%)%s%.]+$') then
    return nil
  end

  local fn = load('return ' .. trimmed, '@deobf_devirtualize', 't', {})
  if not fn then
    return nil
  end
  local ok, value = pcall(fn)
  if not ok or type(value) ~= 'number' then
    return nil
  end
  if value ~= value or value == math.huge or value == -math.huge then
    return nil
  end
  if math.abs(value) > 1e14 then
    return nil
  end
  return value
end

local function format_number(value)
  local iv = math.floor(value)
  if math.abs(value - iv) < 1e-9 then
    return tostring(iv)
  end
  return string.format('%.17g', value)
end

local function fold_in_brackets(source, report)
  local changed = 0
  local out = source:gsub('%[([%+%-]?[%d%(][%d%+%-%*%%%/%^%(%)%s%.]-)%]', function(expr)
    local value = eval_constant_expr(expr)
    if value == nil then
      return '[' .. expr .. ']'
    end
    changed = changed + 1
    return '[' .. format_number(value) .. ']'
  end)
  report.constant_folds = report.constant_folds + changed
  return out, changed
end

local function fold_parenthesized(source, report)
  local changed = 0
  local out = source:gsub('%(([%+%-]?[%d%(][%d%+%-%*%%%/%^%(%)%s%.]-)%)', function(expr)
    local value = eval_constant_expr(expr)
    if value == nil then
      return '(' .. expr .. ')'
    end
    changed = changed + 1
    return '(' .. format_number(value) .. ')'
  end)
  report.constant_folds = report.constant_folds + changed
  return out, changed
end

local function fold_rhs_like(source, report)
  local changed = 0
  local out = source:gsub('([=,;:]%s*)([%+%-]?[%d%(][%d%+%-%*%%%/%^%(%)%s%.]-)(%s*[%],;\n])', function(prefix, expr, suffix)
    local value = eval_constant_expr(expr)
    if value == nil then
      return prefix .. expr .. suffix
    end
    changed = changed + 1
    return prefix .. format_number(value) .. suffix
  end)
  report.constant_folds = report.constant_folds + changed
  return out, changed
end

local function compute_line_starts(source)
  local starts = { 1 }
  local i = 1
  while i <= #source do
    local b = source:byte(i)
    if b == 13 then -- \r
      if source:byte(i + 1) == 10 then
        i = i + 1
      end
      starts[#starts + 1] = i + 1
    elseif b == 10 then -- \n
      starts[#starts + 1] = i + 1
    end
    i = i + 1
  end
  return starts
end

local function fold_delimited_constants(source, report)
  local ok, tokens = pcall(function()
    return LexerFull.new(source, { dialect = (report and report.dialect) }):tokenize()
  end)
  if not ok or type(tokens) ~= 'table' then
    return source, 0
  end

  local line_starts = compute_line_starts(source)
  local tok_start = {}
  local tok_end = {}
  for i, tok in ipairs(tokens) do
    if type(tok.line) == 'number' and type(tok.col) == 'number' and type(tok.value) == 'string' then
      local base = line_starts[tok.line] or 1
      local s = base + tok.col - 1
      tok_start[i] = s
      tok_end[i] = s + #tok.value - 1
    end
  end

  local function is_prefix(tok)
    if not tok then
      return true
    end
    if tok.type == 'symbol' then
      local v = tok.value
      return v == '{' or v == '[' or v == '(' or v == ',' or v == ';' or v == '=' or v == ':'
        or v == '<' or v == '>' or v == '<=' or v == '>=' or v == '==' or v == '~='
    end
    if tok.type == 'keyword' then
      local v = tok.value
      return v == 'return' or v == 'while' or v == 'if' or v == 'elseif' or v == 'until' or v == 'for'
    end
    return false
  end

  local function is_terminator(tok)
    if not tok then
      return true
    end
    if tok.type == 'symbol' then
      local v = tok.value
      -- Treat comparison operators as terminators too so we can fold constants on
      -- the LHS of `==` / `<` chains (common in VM dispatchers).
      return v == ',' or v == ';' or v == '}' or v == ']' or v == ')'
        or v == '<' or v == '>' or v == '<=' or v == '>=' or v == '==' or v == '~='
    end
    if tok.type == 'keyword' then
      local v = tok.value
      -- In minified one-line code, statement boundaries are often separated only by keywords.
      -- Treat common statement-starters as terminators so we can fold `local a=1+2 local b=3`.
      return v == 'do' or v == 'then' or v == 'end' or v == 'until'
        or v == 'local' or v == 'function' or v == 'return'
        or v == 'if' or v == 'elseif' or v == 'for' or v == 'while' or v == 'repeat'
        or v == 'break' or v == 'goto'
        or v == 'else' or v == 'and' or v == 'or'
    end
    if tok.type == 'newline' then
      return true
    end
    return false
  end

  local function is_start_token(tok)
    if not tok then
      return false
    end
    if tok.type == 'number' then
      return true
    end
    if tok.type == 'symbol' then
      local v = tok.value
      return v == '+' or v == '-' or v == '('
    end
    return false
  end

  local changes = {}
  local changed = 0
  local i = 1
  while i <= #tokens do
    local prev = tokens[i - 1]
    local tok = tokens[i]
    if is_prefix(prev) and is_start_token(tok) and tok_start[i] and tok_end[i] then
      local depth = 0
      local has_op = false
      local j = i
      while j <= #tokens do
        local t = tokens[j]
        if not t or not tok_start[j] or not tok_end[j] then
          break
        end
        if t.type == 'number' then
          -- ok
        elseif t.type == 'symbol' then
          local v = t.value
          if v == '(' then
            depth = depth + 1
          elseif v == ')' then
            if depth > 0 then
              depth = depth - 1
            else
              break
            end
          elseif v == '+' or v == '-' or v == '*' or v == '/' or v == '%' or v == '^' then
            has_op = true
          else
            break
          end
        else
          break
        end
        j = j + 1
      end

      local last = j - 1
      local next_tok = tokens[j]
      if last >= i and depth == 0 and has_op and is_terminator(next_tok) then
        local s = tok_start[i]
        local e = tok_end[last]
        if s and e and e >= s and e <= #source then
          local expr = source:sub(s, e)
          local value = eval_constant_expr(expr)
          if value ~= nil then
            local repl = format_number(value)
            -- Prevent accidental token-joins like `return1end` or `x=1foo` after folding.
            local before = s > 1 and source:sub(s - 1, s - 1) or ''
            local after = e < #source and source:sub(e + 1, e + 1) or ''
            if before:match('[%w_]') and repl:sub(1, 1):match('[%w_]') then
              repl = ' ' .. repl
            end
            if repl:sub(-1):match('[%w_]') and after:match('[%w_]') then
              repl = repl .. ' '
            end
            changes[#changes + 1] = { start_pos = s, end_pos = e, value = repl }
            i = j
          end
        end
      end
    end
    i = i + 1
  end

  if #changes == 0 then
    return source, 0
  end

  table.sort(changes, function(a, b)
    return a.start_pos > b.start_pos
  end)

  local out = source
  for _, item in ipairs(changes) do
    out = out:sub(1, item.start_pos - 1) .. item.value .. out:sub(item.end_pos + 1)
    changed = changed + 1
  end

  report.constant_folds = report.constant_folds + changed
  return out, changed
end

local function fold_comparisons(source, report)
  local changed = 0
  local out = source

  out = out:gsub('(<%s*)([%+%-]?[%d%(][%d%+%-%*%%%/%^%(%)%s%.]-)', function(prefix, expr)
    local value = eval_constant_expr(expr)
    if value == nil then
      return prefix .. expr
    end
    changed = changed + 1
    return prefix .. format_number(value)
  end)

  out = out:gsub('(==%s*)([%+%-]?[%d%(][%d%+%-%*%%%/%^%(%)%s%.]-)', function(prefix, expr)
    local value = eval_constant_expr(expr)
    if value == nil then
      return prefix .. expr
    end
    changed = changed + 1
    return prefix .. format_number(value)
  end)

  report.constant_folds = report.constant_folds + changed
  return out, changed
end

function Devirtualizer.run(source, options)
  options = options or {}
  if type(source) ~= 'string' or source == '' then
    return source, {
      enabled = true,
      applied = false,
      changed = false,
      constant_folds = 0,
      passes = 0
    }
  end

  local max_passes = tonumber(options.max_passes) or 4
  if max_passes < 1 then
    max_passes = 1
  end
  if max_passes > 8 then
    max_passes = 8
  end

  local out = source
  local report = {
    enabled = true,
    applied = false,
    changed = false,
    constant_folds = 0,
    passes = 0,
    dialect = options.dialect,
    fold_stats = {
      bracket = 0,
      parenthesized = 0,
      rhs = 0,
      comparisons = 0,
      delimited = 0
    }
  }

  for _ = 1, max_passes do
    local pass_changed = 0

    local next_out, n = fold_in_brackets(out, report)
    out = next_out
    pass_changed = pass_changed + n
    report.fold_stats.bracket = report.fold_stats.bracket + n

    next_out, n = fold_parenthesized(out, report)
    out = next_out
    pass_changed = pass_changed + n
    report.fold_stats.parenthesized = report.fold_stats.parenthesized + n

    next_out, n = fold_rhs_like(out, report)
    out = next_out
    pass_changed = pass_changed + n
    report.fold_stats.rhs = report.fold_stats.rhs + n

    next_out, n = fold_comparisons(out, report)
    out = next_out
    pass_changed = pass_changed + n
    report.fold_stats.comparisons = report.fold_stats.comparisons + n

    next_out, n = fold_delimited_constants(out, report)
    out = next_out
    pass_changed = pass_changed + n
    report.fold_stats.delimited = report.fold_stats.delimited + n

    report.passes = report.passes + 1
    if pass_changed == 0 then
      break
    end
  end

  report.changed = out ~= source
  report.applied = report.changed
  report.bytes_before = #source
  report.bytes_after = #out

  return out, report
end

return Devirtualizer
