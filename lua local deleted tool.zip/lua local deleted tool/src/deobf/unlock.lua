local Unlock = {}

local function safe_eval_number_expr(expr)
  if type(expr) ~= 'string' or expr == '' then
    return nil
  end
  if not expr:match('^[%d%+%-%*%%%/%^%(%)%s%.]+$') then
    return nil
  end
  local fn = load('return ' .. expr, '@deobf_unlock_numexpr', 't', {})
  if not fn then
    return nil
  end
  local ok, value = pcall(fn)
  if not ok or type(value) ~= 'number' then
    return nil
  end
  if value ~= value or value == math.huge or value == -math.huge then
    return nil
  end
  if math.abs(value) > 1e14 then
    return nil
  end
  return math.floor(value)
end

local function decode_lua_string_literal(lit)
  if type(lit) ~= 'string' or lit == '' then
    return nil
  end
  local fn = load('return ' .. lit, '@deobf_unlock_lit', 't', {})
  if not fn then
    return nil
  end
  local ok, value = pcall(fn)
  if not ok or type(value) ~= 'string' then
    return nil
  end
  return value
end

local function decode_custom_base64(input, map)
  if type(input) ~= 'string' or input == '' or type(map) ~= 'table' then
    return nil
  end

  local out = {}
  local acc = 0
  local count = 0
  for i = 1, #input do
    local ch = input:sub(i, i)
    if ch == '=' then
      if count == 2 then
        out[#out + 1] = string.char(math.floor(acc / 16) % 256)
      elseif count == 3 then
        out[#out + 1] = string.char(math.floor(acc / 1024) % 256)
        out[#out + 1] = string.char(math.floor(acc / 4) % 256)
      end
      return table.concat(out)
    end
    local v = map[ch]
    if type(v) ~= 'number' then
      return nil
    end
    acc = acc * 64 + v
    count = count + 1
    if count == 4 then
      out[#out + 1] = string.char(math.floor(acc / 65536) % 256)
      out[#out + 1] = string.char(math.floor(acc / 256) % 256)
      out[#out + 1] = string.char(acc % 256)
      acc = 0
      count = 0
    end
  end
  if count == 2 then
    out[#out + 1] = string.char(math.floor(acc / 16) % 256)
  elseif count == 3 then
    out[#out + 1] = string.char(math.floor(acc / 1024) % 256)
    out[#out + 1] = string.char(math.floor(acc / 4) % 256)
  end
  return table.concat(out)
end

local function is_custom_base64ish(text, map)
  if type(text) ~= 'string' or text == '' or type(map) ~= 'table' then
    return false
  end
  if #text < 4 then
    return false
  end
  if (#text % 4) == 1 then
    return false
  end
  for i = 1, #text do
    local ch = text:sub(i, i)
    if ch ~= '=' and type(map[ch]) ~= 'number' then
      return false
    end
  end
  return true
end

local function is_mostly_printable_text(text)
  if type(text) ~= 'string' or text == '' then
    return false
  end
  if text:find('\0', 1, true) then
    return false
  end
  local printable = 0
  for i = 1, #text do
    local b = text:byte(i)
    if b and ((b >= 32 and b <= 126) or b == 9 or b == 10 or b == 13) then
      printable = printable + 1
    end
  end
  return (printable / #text) >= 0.72
end

local function lua_quote_ascii(text)
  if type(text) ~= 'string' then
    return nil
  end
  local out = { '"' }
  for i = 1, #text do
    local b = text:byte(i)
    if b == 34 then
      out[#out + 1] = '\\"'
    elseif b == 92 then
      out[#out + 1] = '\\\\'
    elseif b == 9 then
      out[#out + 1] = '\\t'
    elseif b == 10 then
      out[#out + 1] = '\\n'
    elseif b == 13 then
      out[#out + 1] = '\\r'
    elseif b and b >= 32 and b <= 126 then
      out[#out + 1] = string.char(b)
    else
      out[#out + 1] = string.format('\\%03d', b or 0)
    end
  end
  out[#out + 1] = '"'
  return table.concat(out)
end

local function extract_best_custom_map(source)
  local maps = {}
  for table_lit in source:gmatch('local%s+[%a_][%w_]*%s*=%s*(%b{})') do
    local body = table_lit:sub(2, -2)
    local map = {}
    local values = {}

    for raw_key, raw_expr in body:gmatch('%[([^%]]+)%]%s*=%s*([^,;]+)') do
      local key = decode_lua_string_literal(raw_key)
      local value = safe_eval_number_expr(raw_expr)
      if type(key) == 'string' and #key == 1 and type(value) == 'number' and value >= 0 and value <= 63 then
        map[key] = value
        values[value] = true
      end
    end
    for key, raw_expr in body:gmatch('([%a_][%w_]*)%s*=%s*([^,;]+)') do
      local value = safe_eval_number_expr(raw_expr)
      if #key == 1 and type(value) == 'number' and value >= 0 and value <= 63 then
        map[key] = value
        values[value] = true
      end
    end

    local key_count = 0
    local uniq_count = 0
    for _ in pairs(map) do key_count = key_count + 1 end
    for _ in pairs(values) do uniq_count = uniq_count + 1 end
    if key_count >= 48 and uniq_count >= 48 then
      maps[#maps + 1] = {
        map = map,
        key_count = key_count,
        uniq_count = uniq_count
      }
    end
  end
  return maps
end

local function select_best_custom_map(source, table_info)
  local candidates = extract_best_custom_map(source)
  if #candidates == 0 then
    return nil
  end
  if type(table_info) ~= 'table' or type(table_info.literals) ~= 'table' then
    -- Fallback: pick the biggest map.
    table.sort(candidates, function(a, b)
      return (a.key_count or 0) > (b.key_count or 0)
    end)
    return candidates[1].map
  end

  local best = nil
  local best_score = -1
  local best_hits = 0
  local max_items = 96

  for _, item in ipairs(candidates) do
    local map = item.map
    local hits = 0
    local score = 0
    for i = 1, math.min(#table_info.literals, max_items) do
      local entry = table_info.literals[i]
      local lit = type(entry) == 'table' and entry.literal or entry
      local decoded = decode_lua_string_literal(lit)
      if decoded and is_custom_base64ish(decoded, map) then
        local out_text = decode_custom_base64(decoded, map)
        if out_text and out_text ~= '' then
          hits = hits + 1
          if is_mostly_printable_text(out_text) then
            score = score + 3
          else
            score = score + 1
          end
        end
      end
    end
    if hits >= 3 and score > best_score then
      best_score = score
      best_hits = hits
      best = map
    elseif hits >= 3 and score == best_score and best and hits > best_hits then
      best_hits = hits
      best = map
    end
  end

  return best
end

local function extract_table_literals(table_text)
  local out = {}
  if type(table_text) ~= 'string' or table_text == '' then
    return out
  end
  local i = 1
  while i <= #table_text do
    local ch = table_text:sub(i, i)
    if ch == '"' or ch == '\'' then
      local q = ch
      local j = i + 1
      while j <= #table_text do
        local c = table_text:sub(j, j)
        if c == '\\' then
          j = j + 2
        elseif c == q then
          break
        else
          j = j + 1
        end
      end
      if j <= #table_text and table_text:sub(j, j) == q then
        out[#out + 1] = {
          literal = table_text:sub(i, j),
          start_pos = i,
          end_pos = j
        }
        i = j + 1
      else
        break
      end
    else
      i = i + 1
    end
  end
  return out
end

local function scan_balanced_braces(source, brace_start)
  if source:sub(brace_start, brace_start) ~= '{' then
    return nil
  end

  local depth = 1
  local i = brace_start + 1
  local q = nil
  while i <= #source do
    local ch = source:sub(i, i)
    if q then
      if ch == '\\' then
        i = i + 2
      elseif ch == q then
        q = nil
        i = i + 1
      else
        i = i + 1
      end
    else
      if ch == '"' or ch == '\'' then
        q = ch
        i = i + 1
      elseif ch == '{' then
        depth = depth + 1
        i = i + 1
      elseif ch == '}' then
        depth = depth - 1
        if depth == 0 then
          return i
        end
        i = i + 1
      else
        i = i + 1
      end
    end
  end
  return nil
end

local function find_primary_string_table(source)
  local best = nil
  local pos = 1
  while pos <= #source do
    local start_pos, end_pos, table_name = source:find('local%s+([%a_][%w_]*)%s*=%s*', pos)
    if not start_pos then
      break
    end
    local brace_start = end_pos + 1
    while brace_start <= #source and source:sub(brace_start, brace_start):match('%s') do
      brace_start = brace_start + 1
    end
    local brace_end = nil
    if source:sub(brace_start, brace_start) == '{' then
      brace_end = scan_balanced_braces(source, brace_start)
    end

    if brace_end then
      local table_lit = source:sub(brace_start, brace_end)
      local lits = extract_table_literals(table_lit)
      if #lits >= 12 then
        if not best or #lits > #best.literals then
          best = {
            table_name = table_name,
            table_literal = table_lit,
            table_start = brace_start,
            table_end = brace_end,
            literals = lits
          }
        end
      end
      pos = brace_end + 1
    else
      pos = end_pos + 1
    end
  end
  return best
end

local function find_string_table_by_name(source, wanted_name)
  if type(wanted_name) ~= 'string' or wanted_name == '' then
    return nil
  end
  local pos = 1
  while pos <= #source do
    local start_pos, end_pos, table_name = source:find('local%s+([%a_][%w_]*)%s*=%s*', pos)
    if not start_pos then
      break
    end
    local brace_start = end_pos + 1
    while brace_start <= #source and source:sub(brace_start, brace_start):match('%s') do
      brace_start = brace_start + 1
    end
    local brace_end = nil
    if source:sub(brace_start, brace_start) == '{' then
      brace_end = scan_balanced_braces(source, brace_start)
    end

    if brace_end then
      if table_name == wanted_name then
        local table_lit = source:sub(brace_start, brace_end)
        local lits = extract_table_literals(table_lit)
        if #lits >= 1 then
          return {
            table_name = table_name,
            table_literal = table_lit,
            table_start = brace_start,
            table_end = brace_end,
            literals = lits
          }
        end
      end
      pos = brace_end + 1
    else
      pos = end_pos + 1
    end
  end
  return nil
end

local function parse_pair_list_text(text)
  local pairs = {}
  if type(text) ~= 'string' then
    return pairs
  end
  local i = 1
  while i <= #text do
    local ch = text:sub(i, i)
    if ch == '{' then
      local depth = 1
      local j = i + 1
      while j <= #text and depth > 0 do
        local c = text:sub(j, j)
        if c == '{' then
          depth = depth + 1
        elseif c == '}' then
          depth = depth - 1
        end
        j = j + 1
      end
      local seg = text:sub(i, j - 1)
      if seg:sub(1, 1) == '{' and seg:sub(-1) == '}' then
        local inner = seg:sub(2, -2)
        local a, b = inner:match('^%s*([^,;]+)%s*[,;]%s*([^,;]+)%s*$')
        local av = safe_eval_number_expr(a or '')
        local bv = safe_eval_number_expr(b or '')
        if av and bv then
          pairs[#pairs + 1] = { av, bv }
        end
      end
      i = j
    else
      i = i + 1
    end
  end
  return pairs
end

local function extract_swap_pairs(source)
  local prefix = source:sub(1, math.min(#source, 12000))
  local best = nil
  local best_count = 0
  for list_text in prefix:gmatch('ipairs%s*%(%s*(%b{})%s*%)%s*do') do
    local pairs = parse_pair_list_text(list_text:sub(2, -2))
    if #pairs >= 2 and #pairs > best_count then
      best_count = #pairs
      best = pairs
    end
  end
  return best or {}
end

local function apply_swaps(values, pairs)
  local out = {}
  for i = 1, #values do
    out[i] = values[i]
  end
  for _, pair in ipairs(pairs or {}) do
    local a = tonumber(pair[1]) or 0
    local b = tonumber(pair[2]) or 0
    a = math.floor(a)
    b = math.floor(b)
    if a >= 1 and b >= 1 and a <= #out and b <= #out then
      while a < b do
        out[a], out[b] = out[b], out[a]
        a = a + 1
        b = b - 1
      end
    end
  end
  return out
end

local function neutralize_swap_loop(source, table_name, anchor_pos, limit_bytes)
  if type(source) ~= 'string' or source == '' then
    return source, 0
  end
  if type(table_name) ~= 'string' or table_name == '' then
    return source, 0
  end

  local center = tonumber(anchor_pos) or 1
  if center < 1 then center = 1 end
  local scan_start = center - 12000
  if scan_start < 1 then scan_start = 1 end
  local scan_end = math.min(#source, scan_start + (tonumber(limit_bytes) or 20000))

  local best = nil
  local best_count = 0
  local pos = scan_start
  while pos <= scan_end do
    local s, e, list = source:find('ipairs%s*%(%s*(%b{})%s*%)%s*do', pos)
    if not s or s > scan_end then
      break
    end

    local pairs = parse_pair_list_text(list:sub(2, -2))
    if #pairs >= 2 and #pairs > best_count then
      local ctx_end = math.min(#source, e + 2200)
      local ctx = source:sub(s, ctx_end)
      if ctx:find(table_name, 1, true) then
        best = { match_start = s, match_end = e, list = list, pair_count = #pairs }
        best_count = #pairs
      end
    end

    pos = e + 1
  end

  if not best then
    return source, 0
  end

  local list_start = source:find(best.list, best.match_start, true)
  if not list_start then
    return source, 0
  end
  local list_end = list_start + #best.list - 1
  if list_end > #source then
    return source, 0
  end

  local out = source:sub(1, list_start - 1) .. '{}' .. source:sub(list_end + 1)
  return out, 1
end

local function neutralize_custom_base64_decoder(source, table_name, anchor_pos, limit_bytes)
  if type(source) ~= 'string' or source == '' then
    return source, 0
  end
  if type(table_name) ~= 'string' or table_name == '' then
    return source, 0
  end

  local center = tonumber(anchor_pos) or 1
  if center < 1 then center = 1 end
  local scan_start = center - 8000
  if scan_start < 1 then scan_start = 1 end
  local scan_end = math.min(#source, scan_start + (tonumber(limit_bytes) or 26000))

  local pos = scan_start
  while pos <= scan_end do
    local s, e, alias = source:find('local%s+([%a_][%w_]*)%s*=%s*' .. table_name .. '%f[^%w_]', pos)
    if not s or s > scan_end then
      break
    end

    local w_start = math.max(1, s - 2500)
    local w_end = math.min(#source, e + 8000)
    local window = source:sub(w_start, w_end)

    local looks_like_decoder = window:find('string.char', 1, true)
      and window:find('table.concat', 1, true)
      and (window:find('string.sub', 1, true) or window:find('string.byte', 1, true))
      and (window:find('string.len', 1, true) or window:find('#', 1, true))
      and window:find('type', 1, true)
      and (
        window:find('"string"', 1, true)
        or window:find("'string'", 1, true)
        or window:find('\\115\\116\\114\\105\\110\\103', 1, true)
      )

    if looks_like_decoder then
      local replacement = 'local ' .. alias .. ' = {}'
      local out = source:sub(1, s - 1) .. replacement .. source:sub(e + 1)
      return out, 1
    end

    pos = e + 1
  end

  return source, 0
end

local function find_accessor(source, table_name)
  if type(table_name) ~= 'string' or table_name == '' then
    return nil
  end
  local fn_name, arg_name, ref_name, op, offset_expr = source:match(
    'local%s+function%s+([%a_][%w_]*)%s*%(%s*([%a_][%w_]*)%s*%)%s*return%s+([%a_][%w_]*)%s*%[%s*%2%s*([%+%-])%s*([^%]]+)%s*%]%s*end'
  )
  if not fn_name or ref_name ~= table_name then
    return nil
  end
  local offset = safe_eval_number_expr(offset_expr or '')
  if not offset then
    return nil
  end
  if op == '-' then
    offset = -offset
  end
  return {
    fn_name = fn_name,
    arg_name = arg_name,
    table_name = ref_name,
    offset = offset
  }
end

local function literal_for_value(v, max_len)
  if type(v) == 'string' then
    if max_len and #v > max_len then
      return nil
    end
    return lua_quote_ascii(v)
  end
  if type(v) == 'number' then
    return tostring(v)
  end
  if type(v) == 'boolean' then
    return v and 'true' or 'false'
  end
  if v == nil then
    return 'nil'
  end
  return nil
end

local function replace_accessor_calls(source, accessor, values, options)
  local fn_name = accessor.fn_name
  local offset = accessor.offset
  local max_replacements = tonumber(options.max_replacements) or 8000
  local max_literal_len = tonumber(options.max_literal_len) or 220
  local count = 0
  local skipped = 0

  local padded = ' ' .. source
  local pattern = '([^%w_])' .. fn_name .. '%s*%(([%+%-]?[%d%(][%d%+%-%*%%%/%^%(%)%s%.]-)%)'
  local replaced = padded:gsub(pattern, function(prefix, expr)
    if count >= max_replacements then
      return prefix .. fn_name .. '(' .. expr .. ')'
    end
    local key = safe_eval_number_expr(expr)
    if key == nil then
      return prefix .. fn_name .. '(' .. expr .. ')'
    end
    local idx = key + offset
    if idx < 1 or idx > #values then
      return prefix .. fn_name .. '(' .. expr .. ')'
    end
    local literal = literal_for_value(values[idx], max_literal_len)
    if not literal then
      skipped = skipped + 1
      return prefix .. fn_name .. '(' .. expr .. ')'
    end
    count = count + 1
    return prefix .. literal
  end)

  return replaced:sub(2), count, skipped
end

local function rewrite_table_literals(source, table_info, values, options)
  if type(source) ~= 'string' or type(table_info) ~= 'table' then
    return source, 0, 0
  end
  if type(table_info.table_start) ~= 'number' or type(table_info.table_end) ~= 'number' then
    return source, 0, 0
  end
  if type(table_info.literals) ~= 'table' or #table_info.literals == 0 then
    return source, 0, 0
  end

  local max_literal_len = tonumber(options.rewrite_table_max_literal_len) or 260
  local printable_only = options.rewrite_table_printable_only ~= false

  local changes = {}
  local skipped = 0

  for i = 1, math.min(#table_info.literals, #values) do
    local entry = table_info.literals[i]
    local value = values[i]
    if type(entry) == 'table' and type(entry.literal) == 'string'
      and type(entry.start_pos) == 'number'
      and type(entry.end_pos) == 'number'
      and type(value) == 'string' then
      if (not printable_only or is_mostly_printable_text(value)) and #value <= max_literal_len then
        local literal = lua_quote_ascii(value)
        if literal ~= entry.literal then
          changes[#changes + 1] = {
            start_pos = table_info.table_start + entry.start_pos - 1,
            end_pos = table_info.table_start + entry.end_pos - 1,
            literal = literal
          }
        end
      else
        skipped = skipped + 1
      end
    end
  end

  if #changes == 0 then
    return source, 0, skipped
  end

  table.sort(changes, function(a, b)
    return a.start_pos > b.start_pos
  end)

  local out = source
  local changed = 0
  for _, item in ipairs(changes) do
    out = out:sub(1, item.start_pos - 1) .. item.literal .. out:sub(item.end_pos + 1)
    changed = changed + 1
  end

  return out, changed, skipped
end

function Unlock.run(source, options)
  options = options or {}
  local report = {
    enabled = true,
    changed = false,
    applied = false,
    table_name = nil,
    accessor_name = nil,
    offset = nil,
    decoded_entries = 0,
    swapped_pairs = 0,
    replacements = 0,
    replacement_skipped = 0,
    table_literal_rewrites = 0,
    table_literal_skipped = 0,
    runtime_swap_neutralized = 0,
    runtime_decoder_neutralized = 0
  }

  if type(source) ~= 'string' or source == '' then
    return source, report, nil
  end

  local analysis_source = type(options.analysis_source) == 'string' and options.analysis_source or source

  local analysis_table_info = find_primary_string_table(analysis_source)
  if not analysis_table_info then
    return source, report, nil
  end
  report.table_name = analysis_table_info.table_name

  local values_pretty = {}
  local values_final = {}
  local custom_map = select_best_custom_map(analysis_source, analysis_table_info)
  for i = 1, #analysis_table_info.literals do
    local entry = analysis_table_info.literals[i]
    local lit = type(entry) == 'table' and entry.literal or entry
    local decoded = decode_lua_string_literal(lit) or lit
    values_pretty[i] = decoded

    local final = decoded
    if custom_map and is_custom_base64ish(decoded, custom_map) then
      local custom_decoded = decode_custom_base64(decoded, custom_map)
      if custom_decoded then
        final = custom_decoded
      end
    end
    values_final[i] = final
  end
  report.decoded_entries = #values_final

  local swap_pairs = extract_swap_pairs(analysis_source)
  if #swap_pairs > 0 then
    values_pretty = apply_swaps(values_pretty, swap_pairs)
    values_final = apply_swaps(values_final, swap_pairs)
    report.swapped_pairs = #swap_pairs
  end

  local extra = {
    table_name = report.table_name,
    values_pretty = values_pretty,
    values_final = values_final
  }

  local working_source = source
  if options.rewrite_table_literals == true then
    local target_table_info = find_string_table_by_name(working_source, analysis_table_info.table_name)
      or find_primary_string_table(working_source)

    local rewrite_values = {}
    local full_decode = options.rewrite_table_full_decode == true
    for i = 1, math.max(#values_final, #values_pretty) do
      local v = values_final[i]
      if full_decode then
        if type(v) == 'string' then
          rewrite_values[i] = v
        else
          local p = values_pretty[i]
          rewrite_values[i] = type(p) == 'string' and p or v
        end
      else
        if type(v) == 'string' and is_mostly_printable_text(v) then
          rewrite_values[i] = v
        else
          local p = values_pretty[i]
          if type(p) == 'string' then
            rewrite_values[i] = p
          else
            rewrite_values[i] = v
          end
        end
      end
    end

    working_source, report.table_literal_rewrites, report.table_literal_skipped = rewrite_table_literals(
      working_source,
      target_table_info,
      rewrite_values,
      options
    )

    -- If we rewrote the string table to its decoded form, avoid reapplying swap/decode
    -- logic at runtime (would corrupt already-decoded entries).
    if options.neutralize_runtime_decoders ~= false
      and (options.rewrite_table_full_decode == true)
      and (report.table_literal_rewrites or 0) > 0
      and (report.table_literal_skipped or 0) == 0 then
      local anchor = (type(target_table_info) == 'table' and target_table_info.table_end) or 1
      working_source, report.runtime_swap_neutralized = neutralize_swap_loop(working_source, analysis_table_info.table_name, anchor, 22000)
      working_source, report.runtime_decoder_neutralized = neutralize_custom_base64_decoder(working_source, analysis_table_info.table_name, anchor, 26000)
    end
  end

  local accessor = find_accessor(working_source, analysis_table_info.table_name)
  if not accessor then
    report.changed = working_source ~= source
    return working_source, report, extra
  end
  report.accessor_name = accessor.fn_name
  report.offset = accessor.offset

  local unlocked, replaced, skipped = replace_accessor_calls(working_source, accessor, values_final, {
    max_replacements = options.max_replacements,
    max_literal_len = options.max_literal_len
  })
  report.replacements = replaced
  report.replacement_skipped = skipped
  report.changed = unlocked ~= source

  return unlocked, report, extra
end

return Unlock
