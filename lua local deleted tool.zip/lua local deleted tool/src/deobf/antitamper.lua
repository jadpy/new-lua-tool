local AntiTamper = {}

local function compute_line_starts(source)
  local starts = { 1 }
  local i = 1
  while i <= #source do
    local b = source:byte(i)
    if b == 10 then
      starts[#starts + 1] = i + 1
    elseif b == 13 then
      if source:byte(i + 1) == 10 then
        i = i + 1
      end
      starts[#starts + 1] = i + 1
    end
    i = i + 1
  end
  return starts
end

local function find_line_col(line_starts, pos)
  if type(pos) ~= 'number' or pos < 1 then
    return 1, 1
  end
  local lo, hi = 1, #line_starts
  while lo <= hi do
    local mid = math.floor((lo + hi) / 2)
    local s = line_starts[mid] or 1
    local next_s = line_starts[mid + 1]
    if (not next_s) or pos < next_s then
      return mid, pos - s + 1
    end
    if pos < s then
      hi = mid - 1
    else
      lo = mid + 1
    end
  end
  local last = #line_starts
  local s = line_starts[last] or 1
  return last, pos - s + 1
end

local function preview_around(source, pos, max_len)
  max_len = tonumber(max_len) or 120
  if max_len < 32 then max_len = 32 end
  local half = math.floor(max_len / 2)
  local start_pos = pos - half
  if start_pos < 1 then start_pos = 1 end
  local end_pos = start_pos + max_len - 1
  if end_pos > #source then end_pos = #source end
  local s = source:sub(start_pos, end_pos)
  s = s:gsub('\r', '\\r'):gsub('\n', '\\n'):gsub('\t', '\\t')
  if start_pos > 1 then s = '...' .. s end
  if end_pos < #source then s = s .. '...' end
  return s
end

local function scan_plain(source, needle, max_examples, line_starts, preview_len)
  local count = 0
  local examples = {}
  local idx = 1
  while true do
    local s = source:find(needle, idx, true)
    if not s then
      break
    end
    count = count + 1
    if max_examples and max_examples > 0 and #examples < max_examples then
      local line, col = find_line_col(line_starts, s)
      examples[#examples + 1] = {
        line = line,
        col = col,
        at = s,
        preview = preview_around(source, s, preview_len)
      }
    end
    idx = s + #needle
  end
  return count, examples
end

function AntiTamper.scan(source, options)
  options = options or {}
  if type(source) ~= 'string' or source == '' then
    return {
      suspected = false,
      score = 0,
      hits = {}
    }
  end

  local max_bytes = tonumber(options.max_bytes) or 900000
  if max_bytes < 1 then max_bytes = 1 end
  if #source > max_bytes then
    source = source:sub(1, max_bytes)
  end

  local include_examples = options.include_examples == true
  local max_examples = include_examples and (tonumber(options.max_examples) or 3) or 0
  local preview_len = tonumber(options.preview_len) or 140
  if preview_len < 40 then preview_len = 40 end

  local line_starts = include_examples and compute_line_starts(source) or { 1 }

  local patterns = {
    { id = 'tamper-message', needle = 'Tamper Detected!', weight = 12 },
    { id = 'tamper-keyword', needle = 'tamper', weight = 2 },
    { id = 'debug.sethook', needle = 'debug.sethook', weight = 8 },
    { id = 'debug.getinfo', needle = 'debug.getinfo', weight = 6 },
    { id = 'debug.getupvalue', needle = 'debug.getupvalue', weight = 6 },
    { id = 'debug.traceback', needle = 'debug.traceback', weight = 5 },
    { id = 'string.dump', needle = 'string.dump', weight = 7 },
    { id = 'newproxy', needle = 'newproxy', weight = 4 },
    { id = 'getfenv', needle = 'getfenv', weight = 3 },
    { id = 'setfenv', needle = 'setfenv', weight = 3 },
    { id = '__gc', needle = '__gc', weight = 4 },
    { id = '__metatable', needle = '__metatable', weight = 3 },
    { id = 'setmetatable', needle = 'setmetatable', weight = 2 },
    { id = 'getmetatable', needle = 'getmetatable', weight = 2 },
    { id = '__tostring', needle = '__tostring', weight = 4 },
    { id = 'hookfunction', needle = 'hookfunction', weight = 4 },
    { id = 'newcclosure', needle = 'newcclosure', weight = 3 }
  }

  local hits = {}
  local score = 0
  for _, p in ipairs(patterns) do
    local count, examples = scan_plain(source, p.needle, max_examples, line_starts, preview_len)
    if count > 0 then
      hits[#hits + 1] = {
        id = p.id,
        needle = p.needle,
        count = count,
        weight = p.weight,
        examples = include_examples and examples or nil
      }
      score = score + (p.weight * math.min(count, 4))
    end
  end

  table.sort(hits, function(a, b)
    return (a.weight * a.count) > (b.weight * b.count)
  end)

  return {
    suspected = score >= (tonumber(options.suspect_threshold) or 12),
    score = score,
    truncated = (#source >= max_bytes) and true or false,
    hits = hits
  }
end

return AntiTamper
