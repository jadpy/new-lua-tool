local LintSandbox = require('src.lint_sandbox')

local DeobfSandbox = {}

local TIMEOUT_SENTINEL = '__DEOBF_TIMEOUT__'
local unpack_fn = table.unpack or unpack

local function count_char(text, ch)
  local n = 0
  for i = 1, #text do
    if text:sub(i, i) == ch then
      n = n + 1
    end
  end
  return n
end

local function fast_hash32(text)
  local len = #text
  local h = 2166136261
  local step = 1
  if len > 8192 then
    step = math.floor(len / 4096)
    if step < 1 then step = 1 end
  end
  for i = 1, len, step do
    h = (h * 16777619) % 4294967296
    h = (h + text:byte(i)) % 4294967296
  end
  if step > 1 then
    local tail_start = len - 128
    if tail_start < 1 then tail_start = 1 end
    for i = tail_start, len do
      h = (h * 16777619) % 4294967296
      h = (h + text:byte(i)) % 4294967296
    end
  end
  return string.format('%08x', h)
end

local function text_signature(text)
  local len = #text
  local head = text:sub(1, 24)
  local tail = text:sub(-24)
  local hash = fast_hash32(text)
  local nl = count_char(text, '\n')
  return table.concat({ tostring(len), hash, tostring(nl), head, tail }, '|')
end

local function is_probably_text(text)
  if type(text) ~= 'string' or text == '' then
    return false
  end
  if text:find('\0', 1, true) then
    return false
  end
  local ctrl = 0
  for i = 1, #text do
    local b = text:byte(i)
    if b and (b < 9 or (b > 13 and b < 32)) then
      ctrl = ctrl + 1
    end
  end
  local max_ctrl = math.max(2, math.floor(#text * 0.02))
  return ctrl <= max_ctrl
end

local function looks_like_lua_text(text)
  if type(text) ~= 'string' then
    return false
  end
  if #text < 8 then
    return false
  end
  if not is_probably_text(text) then
    return false
  end
  if text:find('^[A-Za-z0-9+/=\r\n]+$') then
    return false
  end
  if text:find('%f[%a_]function%f[^%a_]') then
    return true
  end
  if text:find('%f[%a_]local%f[^%a_]') and (text:find('=', 1, true) or text:find('\n', 1, true)) then
    return true
  end
  if text:find('%f[%a_]return%f[^%a_]') and text:find('\n', 1, true) then
    return true
  end
  if text:match('^%s*[_%a][%w_%.:]*%s*%(') and text:find('%)', 1, false) then
    return true
  end
  if text:match('^%s*[_%a][%w_]*%s*=') then
    return true
  end
  return false
end

local function is_mostly_printable_text(text)
  if type(text) ~= 'string' or text == '' then
    return false
  end
  if text:find('\0', 1, true) then
    return false
  end
  local printable = 0
  for i = 1, #text do
    local b = text:byte(i)
    if b and ((b >= 32 and b <= 126) or b == 9 or b == 10 or b == 13) then
      printable = printable + 1
    end
  end
  return (printable / #text) >= 0.74
end

local function normalize_error(err)
  local s = tostring(err or '')
  if s:find(TIMEOUT_SENTINEL, 1, true) then
    return 'deobf sandbox timeout'
  end
  return s
end

local function add_capture(trace, seen, options, kind, text, meta)
  if type(text) ~= 'string' or text == '' then
    return false
  end
  local max_capture_bytes = tonumber(options.max_capture_bytes) or 1572864
  local truncated = false
  if #text > max_capture_bytes then
    text = text:sub(1, max_capture_bytes)
    truncated = true
  end

  local sig = text_signature(text)
  if seen[sig] then
    return false
  end
  seen[sig] = true

  local max_captures = tonumber(options.max_captures) or 96
  if #trace.captures >= max_captures then
    trace.captures_dropped = trace.captures_dropped + 1
    return false
  end

  local item = {
    kind = tostring(kind or 'capture'),
    bytes = #text,
    signature = sig,
    text = text,
    is_probable_text = is_probably_text(text),
    looks_like_lua = looks_like_lua_text(text),
    truncated = truncated
  }
  if meta and type(meta) == 'table' then
    for k, v in pairs(meta) do
      if item[k] == nil then
        item[k] = v
      end
    end
  end
  trace.captures[#trace.captures + 1] = item
  return true
end

local function install_hooks(hook_state)
  if type(debug) ~= 'table' or type(debug.gethook) ~= 'function' or type(debug.sethook) ~= 'function' then
    hook_state.enabled = false
    return
  end

  hook_state.enabled = true
  local old_hook, old_mask, old_count = debug.gethook()
  hook_state.old_main = {
    hook = old_hook,
    mask = old_mask,
    count = old_count
  }

  hook_state.hook_fn = function()
    hook_state.remaining = hook_state.remaining - hook_state.stride
    if hook_state.remaining <= 0 or os.clock() > hook_state.deadline then
      hook_state.timeout = true
      error(TIMEOUT_SENTINEL)
    end
  end

  local ok = pcall(debug.sethook, hook_state.hook_fn, '', hook_state.stride)
  if not ok then
    hook_state.enabled = false
  end
end

local function attach_thread_hook(hook_state, co)
  if not hook_state.enabled then
    return false
  end
  if type(co) ~= 'thread' then
    return false
  end
  if type(debug) ~= 'table' or type(debug.sethook) ~= 'function' then
    return false
  end
  local ok = pcall(debug.sethook, co, hook_state.hook_fn, '', hook_state.stride)
  if ok then
    hook_state.threads[co] = true
  end
  return ok
end

local function clear_hooks(hook_state)
  if not hook_state.enabled then
    return
  end
  if type(debug) == 'table' and type(debug.sethook) == 'function' then
    if hook_state.old_main then
      pcall(debug.sethook, hook_state.old_main.hook, hook_state.old_main.mask, hook_state.old_main.count)
    end
    for co in pairs(hook_state.threads or {}) do
      pcall(debug.sethook, co)
    end
  end
end

local function add_probe_target(list, seen, fn, label, self_arg)
  if type(fn) ~= 'function' then
    return
  end
  local key = tostring(fn) .. '|' .. tostring(label or '')
  if seen[key] then
    return
  end
  seen[key] = true
  list[#list + 1] = {
    fn = fn,
    label = tostring(label or '<fn>'),
    self_arg = self_arg
  }
end

local function collect_probe_targets(values, max_targets, max_table_fields)
  local targets = {}
  local seen = {}

  for i, v in ipairs(values or {}) do
    if type(v) == 'function' then
      add_probe_target(targets, seen, v, 'return[' .. tostring(i) .. ']', nil)
    elseif type(v) == 'table' then
      local count = 0
      for k, fn in pairs(v) do
        if count >= max_table_fields then
          break
        end
        if type(fn) == 'function' then
          add_probe_target(targets, seen, fn, 'return[' .. tostring(i) ..'].' .. tostring(k), v)
          count = count + 1
        end
      end
    end
    if #targets >= max_targets then
      break
    end
  end

  if #targets > max_targets then
    local trimmed = {}
    for i = 1, max_targets do
      trimmed[i] = targets[i]
    end
    return trimmed, #targets - max_targets
  end
  return targets, 0
end

function DeobfSandbox.execute(source, options)
  options = options or {}
  local trace_enabled = options.trace == true
  local execute_loaded = options.execute_loaded == true
  local capture_text_strings = options.capture_text_strings == true
  local min_text_capture_len = tonumber(options.min_text_capture_len) or 8
  if min_text_capture_len < 0 then
    min_text_capture_len = 0
  end

  local env, lint_trace = LintSandbox.build({
    max_history = trace_enabled and (tonumber(options.max_history) or 640) or 180
  })

  local trace = {
    captures = {},
    captures_dropped = 0,
    load_calls = 0,
    load_errors = 0,
    load_skipped = 0,
    load_reader_calls = 0,
    load_reader_errors = 0,
    probes_attempted = 0,
    probes_ok = 0,
    probes_failed = 0,
    probes_omitted = 0,
    undefined_proxy_reads = 0,
    undefined_proxy_objects = 0,
    tamper_signals = 0,
    tamper_errors_suppressed = 0
  }
  local capture_seen = {}
  local text_trace = {
    captures = {},
    captures_dropped = 0
  }
  local text_capture_seen = {}

  local max_instructions = tonumber(options.max_instructions) or 900000
  if max_instructions < 10000 then
    max_instructions = 10000
  end
  local max_seconds = tonumber(options.max_seconds) or 1.2
  if max_seconds < 0.1 then
    max_seconds = 0.1
  end
  local stride = tonumber(options.hook_stride) or 2000
  if stride < 100 then
    stride = 100
  end

  local hook_state = {
    enabled = false,
    timeout = false,
    remaining = max_instructions,
    deadline = os.clock() + max_seconds,
    stride = stride,
    threads = {}
  }

  local function native_load_chunk(chunk, chunkname, mode, target_env)
    if type(load) == 'function' then
      return load(chunk, chunkname, mode or 'bt', target_env)
    end
    if type(loadstring) == 'function' and type(chunk) == 'string' then
      local fn, err = loadstring(chunk, chunkname)
      if not fn then
        return nil, err
      end
      if type(setfenv) == 'function' and type(target_env) == 'table' then
        setfenv(fn, target_env)
      end
      return fn, nil
    end
    return nil, 'load is not available'
  end

  local function instrumented_load(kind, chunk, chunkname, mode, custom_env)
    trace.load_calls = trace.load_calls + 1
    local target_env = type(custom_env) == 'table' and custom_env or env
    local tag = tostring(kind or 'load')

    if type(chunk) == 'string' then
      add_capture(trace, capture_seen, options, tag, chunk, {
        chunkname = tostring(chunkname or ''),
        mode = tostring(mode or 'bt')
      })
      if not execute_loaded then
        trace.load_skipped = trace.load_skipped + 1
        return function() return nil end, nil
      end
      local fn, err = native_load_chunk(chunk, chunkname, mode, target_env)
      if not fn then
        trace.load_errors = trace.load_errors + 1
      end
      return fn, err
    end

    if type(chunk) == 'function' then
      trace.load_reader_calls = trace.load_reader_calls + 1
      local parts = {}
      local total = 0
      local calls = 0
      local max_reader_bytes = tonumber(options.max_reader_bytes) or 4194304
      local max_reader_parts = tonumber(options.max_reader_parts) or 32768
      local reader_error = nil
      local reader_truncated = false

      local function wrapped_reader()
        calls = calls + 1
        if calls > max_reader_parts then
          reader_truncated = true
          return nil
        end
        local ok, piece = pcall(chunk)
        if not ok then
          reader_error = tostring(piece)
          return nil
        end
        if piece == nil then
          return nil
        end
        if type(piece) ~= 'string' then
          reader_error = 'reader returned non-string value'
          return nil
        end
        if total + #piece > max_reader_bytes then
          local remain = max_reader_bytes - total
          if remain > 0 then
            parts[#parts + 1] = piece:sub(1, remain)
            total = total + remain
          end
          reader_truncated = true
          return nil
        end
        total = total + #piece
        parts[#parts + 1] = piece
        return piece
      end

      local fn, err = nil, nil
      if execute_loaded then
        fn, err = native_load_chunk(wrapped_reader, chunkname, mode, target_env)
      else
        while true do
          local piece = wrapped_reader()
          if piece == nil then
            break
          end
        end
        fn = function() return nil end
        err = nil
        trace.load_skipped = trace.load_skipped + 1
      end
      local text = table.concat(parts)
      if text ~= '' then
        add_capture(trace, capture_seen, options, 'load-reader', text, {
          chunkname = tostring(chunkname or ''),
          mode = tostring(mode or 'bt'),
          reader_calls = calls,
          reader_error = reader_error,
          reader_truncated = reader_truncated
        })
      end
      if reader_error then
        trace.load_reader_errors = trace.load_reader_errors + 1
      end
      if not fn then
        trace.load_errors = trace.load_errors + 1
      end
      return fn, err
    end

    trace.load_errors = trace.load_errors + 1
    return nil, 'unsupported load chunk type: ' .. tostring(type(chunk))
  end

  local undefined_global_mode = tostring(options.undefined_global_mode or 'nil')
  local unknown_proxy_cache = {}

  local make_unknown_proxy
  make_unknown_proxy = function(path)
    local p = {}
    local mt = {}
    mt.__index = function(_, key)
      local child = path .. '.' .. tostring(key)
      local hit = unknown_proxy_cache[child]
      if hit then
        return hit
      end
      local next_proxy = make_unknown_proxy(child)
      unknown_proxy_cache[child] = next_proxy
      return next_proxy
    end
    mt.__newindex = function() return true end
    mt.__call = function()
      return p
    end
    mt.__add = function() return 0 end
    mt.__sub = function() return 0 end
    mt.__mul = function() return 0 end
    mt.__div = function() return 0 end
    mt.__idiv = function() return 0 end
    mt.__mod = function() return 0 end
    mt.__pow = function() return 0 end
    mt.__unm = function() return 0 end
    mt.__concat = function(a, b)
      return tostring(a) .. tostring(b)
    end
    mt.__len = function() return 0 end
    mt.__eq = function(a, b) return rawequal(a, b) end
    mt.__lt = function() return false end
    mt.__le = function() return false end
    mt.__tostring = function()
      return '<unknown-global:' .. path .. '>'
    end
    return setmetatable(p, mt)
  end

  local function resolve_unknown_global(name)
    if undefined_global_mode == 'nil' then
      return nil, false
    end
    if undefined_global_mode == 'false' then
      return false, true
    end
    if undefined_global_mode == 'zero' then
      return 0, true
    end
    if undefined_global_mode == 'empty-string' then
      return '', true
    end
    if undefined_global_mode == 'empty-table' then
      return {}, true
    end
    if undefined_global_mode == 'function' then
      return function() return nil end, true
    end

    local key = tostring(name or '<unknown>')
    local cached = unknown_proxy_cache[key]
    if cached then
      return cached, true
    end
    local proxy = make_unknown_proxy(key)
    unknown_proxy_cache[key] = proxy
    trace.undefined_proxy_objects = trace.undefined_proxy_objects + 1
    return proxy, true
  end

  local env_mt = getmetatable(env)
  if type(env_mt) == 'table' then
    local base_index = env_mt.__index
    local base_newindex = env_mt.__newindex

    env_mt.__index = function(t, key)
      local value = nil
      if type(base_index) == 'function' then
        value = base_index(t, key)
      elseif type(base_index) == 'table' then
        value = base_index[key]
      end
      if value ~= nil then
        return value
      end

      local fallback, handled = resolve_unknown_global(tostring(key))
      if handled then
        trace.undefined_proxy_reads = trace.undefined_proxy_reads + 1
        return fallback
      end
      return nil
    end

    env_mt.__newindex = function(t, key, value)
      if type(value) == 'string' and #value >= (tonumber(options.min_global_capture_len) or 24) then
        if looks_like_lua_text(value) then
          add_capture(trace, capture_seen, options, 'global-write-string', value, {
            global = tostring(key)
          })
        end
      end
      if type(base_newindex) == 'function' then
        return base_newindex(t, key, value)
      end
      rawset(t, key, value)
    end
  end

  local env_pcall = rawget(env, 'pcall') or pcall
  local env_xpcall = rawget(env, 'xpcall') or xpcall
  local env_error = rawget(env, 'error') or error
  local env_assert = rawget(env, 'assert') or assert
  local anti_dumper_hardening = options.anti_dumper_hardening ~= false
  local suppress_tamper_errors = options.suppress_tamper_errors ~= false
  local protected_fns = {}

  local function is_tamper_message(msg)
    local s = tostring(msg or ''):lower()
    return s:find('tamper', 1, true) ~= nil
      or s:find('detected', 1, true) ~= nil
      or s:find('anti', 1, true) ~= nil
      or s:find('dump', 1, true) ~= nil
      or s:find('debugger', 1, true) ~= nil
      or s:find('hook', 1, true) ~= nil
  end

  local fake_clock = 0
  local clock_step = tonumber(options.clock_step) or 0.0015
  if clock_step <= 0 then
    clock_step = 0.0015
  end
  local fake_epoch = tonumber(options.fake_epoch) or 1704067200
  local function synthetic_clock()
    fake_clock = fake_clock + clock_step
    return fake_clock
  end
  local function synthetic_time(tbl)
    fake_clock = fake_clock + 1
    if type(tbl) == 'table' and type(os.time) == 'function' then
      local ok, out = pcall(os.time, tbl)
      if ok and type(out) == 'number' then
        return out
      end
    end
    return fake_epoch + math.floor(fake_clock)
  end

  local function fake_debug_traceback(msg)
    local head = tostring(msg or '')
    local line = '1'
    return head .. '\nstack traceback:\n'
      .. '@deobf_sandbox:' .. line .. ': in main chunk\n'
      .. '@deobf_sandbox:' .. line .. ': in ?\n'
      .. '@deobf_sandbox:' .. line .. ': in ?'
  end

  local function fake_debug_getinfo(target)
    if protected_fns[target] then
      return {
        source = '=[C]',
        short_src = '[C]',
        what = 'C',
        currentline = -1,
        linedefined = -1,
        lastlinedefined = -1,
        nups = 0,
        nparams = 0,
        isvararg = true,
        name = nil,
        namewhat = ''
      }
    end
    return {
      source = '@deobf_sandbox',
      short_src = 'deobf_sandbox',
      what = 'Lua',
      currentline = 0,
      linedefined = 0,
      lastlinedefined = 0,
      nups = 0,
      nparams = 0,
      isvararg = true,
      name = nil,
      namewhat = ''
    }
  end

  -- LintSandbox provides most globals via metatable __index, so rawget() is
  -- often nil until the script reads the global. Use env.<name> as fallback
  -- so we can wrap libs before executing untrusted code.
  local env_debug = rawget(env, 'debug')
  if env_debug == nil then
    env_debug = env.debug
  end
  if type(env_debug) == 'table' then
    local dbg = {}
    for k, v in pairs(env_debug) do
      dbg[k] = v
    end
    do
      local hook_fn = nil
      local hook_mask = ''
      local hook_count = 0
      local in_call = false

      dbg.sethook = function(...)
        local nargs = select('#', ...)
        if nargs == 0 then
          hook_fn = nil
          hook_mask = ''
          hook_count = 0
          return true
        end

        local first = select(1, ...)
        local fn, mask, count
        if type(first) == 'thread' then
          fn = select(2, ...)
          mask = select(3, ...)
          count = select(4, ...)
        else
          fn = first
          mask = select(2, ...)
          count = select(3, ...)
        end

        if type(fn) ~= 'function' then
          hook_fn = nil
          hook_mask = ''
          hook_count = 0
          return true
        end

        hook_fn = fn
        hook_mask = tostring(mask or '')
        hook_count = tonumber(count) or 0

        if anti_dumper_hardening and not in_call and hook_mask:find('l', 1, true) then
          in_call = true
          pcall(hook_fn, 'line', 1)
          pcall(hook_fn, 'line', 1)
          in_call = false
        end
        return true
      end

      dbg.gethook = function()
        return hook_fn, hook_mask, hook_count
      end
    end

    dbg.getregistry = function() return {} end
    dbg.getinfo = function(target)
      return fake_debug_getinfo(target)
    end
    dbg.getupvalue = function() return nil end
    dbg.setupvalue = function() return nil end
    dbg.upvalueid = function() return 0 end
    dbg.upvaluejoin = function() return true end
    dbg.getlocal = function() return nil end
    dbg.setlocal = function() return nil end
    dbg.info = function(_, _, what)
      local q = tostring(what or '')
      local out = {}
      for i = 1, #q do
        local c = q:sub(i, i)
        if c == 's' then
          out[#out + 1] = 'deobf_sandbox'
        elseif c == 'l' then
          out[#out + 1] = 0
        elseif c == 'n' then
          out[#out + 1] = nil
        elseif c == 'f' then
          out[#out + 1] = function() return nil end
        elseif c == 'a' then
          out[#out + 1] = 0
          out[#out + 1] = true
        end
      end
      return unpack_fn(out, 1, #out)
    end
    dbg.traceback = function(msg)
      if anti_dumper_hardening then
        return fake_debug_traceback(msg)
      end
      return tostring(msg or '')
    end
    if anti_dumper_hardening and type(dbg.getinfo) == 'function' then
      protected_fns[dbg.getinfo] = true
    end
    rawset(env, 'debug', dbg)
  else
    rawset(env, 'debug', {
      traceback = function(msg)
        if anti_dumper_hardening then
          return fake_debug_traceback(msg)
        end
        return tostring(msg or '')
      end,
      getinfo = function(target)
        return fake_debug_getinfo(target)
      end,
      getupvalue = function() return nil end,
      setupvalue = function() return nil end,
      upvalueid = function() return 0 end,
      upvaluejoin = function() return true end,
      getlocal = function() return nil end,
      setlocal = function() return nil end,
      info = function(_, _, what)
        local q = tostring(what or '')
        local out = {}
        for i = 1, #q do
          local c = q:sub(i, i)
          if c == 's' then
            out[#out + 1] = 'deobf_sandbox'
          elseif c == 'l' then
            out[#out + 1] = 0
          elseif c == 'n' then
            out[#out + 1] = nil
          elseif c == 'f' then
            out[#out + 1] = function() return nil end
          elseif c == 'a' then
            out[#out + 1] = 0
            out[#out + 1] = true
          end
        end
        return unpack_fn(out, 1, #out)
      end,
      sethook = function(...)
        local nargs = select('#', ...)
        if nargs == 0 then
          return true
        end
        local first = select(1, ...)
        local fn, mask
        if type(first) == 'thread' then
          fn = select(2, ...)
          mask = select(3, ...)
        else
          fn = first
          mask = select(2, ...)
        end
        if anti_dumper_hardening and type(fn) == 'function' and tostring(mask or ''):find('l', 1, true) then
          pcall(fn, 'line', 1)
          pcall(fn, 'line', 1)
        end
        return true
      end,
      gethook = function() return nil, '', 0 end,
      getregistry = function() return {} end
    })
    if anti_dumper_hardening then
      local dbg = rawget(env, 'debug')
      if type(dbg) == 'table' and type(dbg.getinfo) == 'function' then
        protected_fns[dbg.getinfo] = true
      end
    end
  end

  rawset(env, 'jit', {
    status = function() return true, 'JIT' end,
    on = function() return true end,
    off = function() return true end,
    flush = function() return true end,
    version = 'LuaJIT 2.1.0',
    version_num = 20100,
    opt = { start = function() return true end },
    util = {
      funcinfo = function()
        return {
          source = '@deobf_sandbox',
          linedefined = 0,
          lastlinedefined = 0,
          stackslots = 0,
          params = 0,
          bytecodes = 0
        }
      end
    }
  })

  if anti_dumper_hardening then
    local env_os = rawget(env, 'os')
    local os_copy = {}
    if type(env_os) == 'table' then
      for k, v in pairs(env_os) do
        os_copy[k] = v
      end
    end
    os_copy.clock = synthetic_clock
    os_copy.time = synthetic_time
    os_copy.date = function(fmt, ts)
      if type(os.date) == 'function' then
        return os.date(fmt, ts or fake_epoch)
      end
      return ''
    end
    if type(os_copy.difftime) ~= 'function' then
      os_copy.difftime = function(a, b) return (tonumber(a) or 0) - (tonumber(b) or 0) end
    end
    rawset(env, 'os', os_copy)

    rawset(env, 'collectgarbage', function(opt, arg)
      local mode = tostring(opt or 'count')
      if mode == 'count' then return 0 end
      if mode == 'isrunning' then return true end
      if mode == 'step' then return true end
      if mode == 'setpause' or mode == 'setstepmul' then
        return tonumber(arg) or 0
      end
      return 0
    end)

    rawset(env, 'tick', synthetic_clock)
    rawset(env, 'time', function() return synthetic_time() end)
    rawset(env, 'wait', function() return 0 end)

    local env_task = rawget(env, 'task')
    if type(env_task) == 'table' then
      local task_copy = {}
      for k, v in pairs(env_task) do
        task_copy[k] = v
      end
      task_copy.wait = function() return 0 end
      task_copy.cancel = function() return true end
      task_copy.synchronize = function() return true end
      task_copy.desynchronize = function() return true end
      rawset(env, 'task', task_copy)
    else
      rawset(env, 'task', {
        wait = function() return 0 end,
        spawn = function(fn, ...)
          if type(fn) == 'function' then
            return pcall(fn, ...)
          end
          return false
        end,
        defer = function(fn, ...)
          if type(fn) == 'function' then
            return pcall(fn, ...)
          end
          return false
        end,
        delay = function(_, fn, ...)
          if type(fn) == 'function' then
            return pcall(fn, ...)
          end
          return false
        end,
        cancel = function() return true end,
        synchronize = function() return true end,
        desynchronize = function() return true end
      })
    end

    rawset(env, 'error', function(msg, level)
      if suppress_tamper_errors and is_tamper_message(msg) then
        trace.tamper_signals = trace.tamper_signals + 1
        trace.tamper_errors_suppressed = trace.tamper_errors_suppressed + 1
        return nil
      end
      return env_error(msg, level)
    end)

    rawset(env, 'assert', function(v, msg, ...)
      if v then
        return v, msg, ...
      end
      if suppress_tamper_errors and is_tamper_message(msg) then
        trace.tamper_signals = trace.tamper_signals + 1
        trace.tamper_errors_suppressed = trace.tamper_errors_suppressed + 1
        return v, msg, ...
      end
      return env_assert(v, msg, ...)
    end)

    rawset(env, 'checkcaller', function() return true end)
    rawset(env, 'newcclosure', function(fn) return fn end)
    rawset(env, 'islclosure', function(fn) return type(fn) == 'function' end)
    rawset(env, 'iscclosure', function(fn) return type(fn) == 'function' end)
    rawset(env, 'isexecutorclosure', function() return false end)
    rawset(env, 'hookfunction', function(old_fn, _)
      return old_fn
    end)
    rawset(env, 'clonefunction', function(fn)
      return fn
    end)
    rawset(env, 'getnamecallmethod', function()
      return nil
    end)
    rawset(env, 'setnamecallmethod', function()
      return true
    end)
    rawset(env, 'getgc', function()
      return {}
    end)
    rawset(env, 'getgenv', function() return env end)
    rawset(env, 'getrenv', function() return env end)
    rawset(env, 'getsenv', function() return env end)
    rawset(env, 'getrawmetatable', function(obj)
      local ok, mt = pcall(getmetatable, obj)
      if ok then
        return mt
      end
      return nil
    end)
    rawset(env, 'setrawmetatable', function(obj, mt)
      local ok, out = pcall(setmetatable, obj, mt)
      if ok then
        return out
      end
      return obj
    end)
    if rawget(env, 'bit') == nil and type(bit32) == 'table' then
      rawset(env, 'bit', bit32)
    end
  end

  rawset(env, 'load', function(chunk, chunkname, mode, custom_env)
    return instrumented_load('load', chunk, chunkname, mode, custom_env)
  end)
  rawset(env, 'loadstring', function(chunk, chunkname)
    return instrumented_load('loadstring', chunk, chunkname, 'bt', env)
  end)

  rawset(env, 'pcall', function(fn, ...)
    local res = { env_pcall(fn, ...) }
    if not res[1] and tostring(res[2] or ''):find(TIMEOUT_SENTINEL, 1, true) then
      hook_state.timeout = true
    end
    return unpack_fn(res, 1, #res)
  end)
  if anti_dumper_hardening then
    protected_fns[rawget(env, 'pcall')] = true
  end

  rawset(env, 'xpcall', function(fn, errfn, ...)
    local res = { env_xpcall(fn, errfn, ...) }
    if not res[1] and tostring(res[2] or ''):find(TIMEOUT_SENTINEL, 1, true) then
      hook_state.timeout = true
    end
    return unpack_fn(res, 1, #res)
  end)
  if anti_dumper_hardening then
    protected_fns[rawget(env, 'xpcall')] = true
  end

  local env_string = rawget(env, 'string')
  if env_string == nil then
    env_string = env.string
  end
  if type(env_string) == 'table' then
    local copy = {}
    for k, v in pairs(env_string) do
      copy[k] = v
    end

    local base_char = copy.char
    if type(base_char) == 'function' then
      copy.char = function(...)
        local out = base_char(...)
        if type(out) == 'string' and #out >= (tonumber(options.min_char_capture_len) or 128) then
          if looks_like_lua_text(out) then
            add_capture(trace, capture_seen, options, 'string.char', out, {})
          end
        end
        if capture_text_strings and type(out) == 'string' and #out >= min_text_capture_len then
          if is_mostly_printable_text(out) and not looks_like_lua_text(out) then
            add_capture(text_trace, text_capture_seen, options, 'string.char-text', out, {})
          end
        end
        return out
      end
    end
    if anti_dumper_hardening and type(copy.char) == 'function' then
      protected_fns[copy.char] = true
    end

    local base_dump = copy.dump
    if type(base_dump) == 'function' then
      copy.dump = function(fn, strip)
        if anti_dumper_hardening and protected_fns[fn] then
          error('cannot dump protected function', 0)
        end
        local out = base_dump(fn, strip)
        if type(out) == 'string' then
          add_capture(trace, capture_seen, options, 'string.dump', out, {
            is_probable_text = is_probably_text(out)
          })
        end
        return out
      end
    end
    if anti_dumper_hardening and type(copy.dump) == 'function' then
      protected_fns[copy.dump] = true
    end

    if type(copy.split) ~= 'function' then
      copy.split = function(str, sep)
        local input = tostring(str or '')
        local delimiter = tostring(sep or ' ')
        if delimiter == '' then
          local chars = {}
          for i = 1, #input do
            chars[#chars + 1] = input:sub(i, i)
          end
          return chars
        end
        local out = {}
        local start = 1
        while true do
          local i, j = input:find(delimiter, start, true)
          if not i then
            out[#out + 1] = input:sub(start)
            break
          end
          out[#out + 1] = input:sub(start, i - 1)
          start = j + 1
        end
        return out
      end
    end

    rawset(env, 'string', copy)
  end

  local env_table = rawget(env, 'table')
  if env_table == nil then
    env_table = env.table
  end
  if type(env_table) == 'table' then
    local copy = {}
    for k, v in pairs(env_table) do
      copy[k] = v
    end

    local base_concat = copy.concat
    if type(base_concat) == 'function' then
      copy.concat = function(list, sep, i, j)
        local out = base_concat(list, sep, i, j)
        if type(out) == 'string' and #out >= (tonumber(options.min_concat_capture_len) or 160) then
          if looks_like_lua_text(out) then
            add_capture(trace, capture_seen, options, 'table.concat', out, {})
          end
        end
        if capture_text_strings and type(out) == 'string' and #out >= min_text_capture_len then
          if is_mostly_printable_text(out) and not looks_like_lua_text(out) then
            add_capture(text_trace, text_capture_seen, options, 'table.concat-text', out, {})
          end
        end
        return out
      end
    end

    if type(copy.freeze) ~= 'function' then
      copy.freeze = function(tbl)
        return tbl
      end
    end
    if type(copy.isfrozen) ~= 'function' then
      copy.isfrozen = function()
        return false
      end
    end
    if type(copy.clone) ~= 'function' then
      copy.clone = function(tbl)
        local out = {}
        if type(tbl) == 'table' then
          for k, v in pairs(tbl) do
            out[k] = v
          end
        end
        return out
      end
    end
    if type(copy.create) ~= 'function' then
      copy.create = function(n, value)
        local out = {}
        local count = tonumber(n) or 0
        if count < 0 then count = 0 end
        for idx = 1, count do
          out[idx] = value
        end
        return out
      end
    end
    if type(copy.clear) ~= 'function' then
      copy.clear = function(tbl)
        if type(tbl) == 'table' then
          for k in pairs(tbl) do
            tbl[k] = nil
          end
        end
      end
    end

    rawset(env, 'table', copy)
  end

  local env_coroutine = rawget(env, 'coroutine')
  if env_coroutine == nil then
    env_coroutine = env.coroutine
  end
  if type(env_coroutine) == 'table' then
    local copy = {}
    for k, v in pairs(env_coroutine) do
      copy[k] = v
    end

    local base_create = copy.create
    local base_resume = copy.resume
    if type(base_create) == 'function' and type(base_resume) == 'function' then
      copy.create = function(fn)
        local co = base_create(fn)
        attach_thread_hook(hook_state, co)
        return co
      end
      copy.resume = function(co, ...)
        attach_thread_hook(hook_state, co)
        local res = { base_resume(co, ...) }
        if not res[1] and tostring(res[2] or ''):find(TIMEOUT_SENTINEL, 1, true) then
          hook_state.timeout = true
        end
        return unpack_fn(res, 1, #res)
      end
      copy.wrap = function(fn)
        local co = copy.create(fn)
        return function(...)
          local res = { copy.resume(co, ...) }
          if not res[1] then
            error(res[2], 0)
          end
          return unpack_fn(res, 2, #res)
        end
      end
    end

    rawset(env, 'coroutine', copy)
  end

  local entry_fn, compile_err = native_load_chunk(source, '@deobf_entry', 't', env)
  if not entry_fn then
    return {
      ok = false,
      compile_ok = false,
      timeout = false,
      error = tostring(compile_err),
      captures = trace.captures,
      captures_dropped = trace.captures_dropped,
      stats = {
        load_calls = trace.load_calls,
        load_errors = trace.load_errors,
        load_skipped = trace.load_skipped,
        load_reader_calls = trace.load_reader_calls,
        load_reader_errors = trace.load_reader_errors,
        probes_attempted = trace.probes_attempted,
        probes_ok = trace.probes_ok,
        probes_failed = trace.probes_failed,
        probes_omitted = trace.probes_omitted,
        undefined_proxy_reads = trace.undefined_proxy_reads,
        undefined_proxy_objects = trace.undefined_proxy_objects,
        tamper_signals = trace.tamper_signals,
        tamper_errors_suppressed = trace.tamper_errors_suppressed
      },
      trace = trace_enabled and {
        events = lint_trace.events or {},
        history = lint_trace.history or {},
        require_calls = lint_trace.require_calls or {},
        proxy_reads = lint_trace.proxy_reads or {},
        global_reads = lint_trace.global_reads or {},
        global_writes = lint_trace.global_writes or {},
        text_captures = capture_text_strings and text_trace.captures or {},
        text_captures_dropped = capture_text_strings and text_trace.captures_dropped or 0
      } or nil
    }
  end

  local ok = false
  local runtime_err = nil
  local returns = {}

  install_hooks(hook_state)
  local exec = { pcall(entry_fn) }
  ok = exec[1] == true
  if ok then
    for i = 2, #exec do
      returns[#returns + 1] = exec[i]
    end
  else
    runtime_err = normalize_error(exec[2])
    if tostring(exec[2] or ''):find(TIMEOUT_SENTINEL, 1, true) then
      hook_state.timeout = true
    end
  end

  for i, v in ipairs(returns) do
    if type(v) == 'string' then
      if looks_like_lua_text(v) then
        add_capture(trace, capture_seen, options, 'return-string', v, { return_index = i })
      end
    end
  end

  local probe_enabled = options.probe ~= false
  if probe_enabled and not hook_state.timeout then
    local max_probe_targets = tonumber(options.max_probe_targets) or 12
    local max_probe_table_fields = tonumber(options.max_probe_table_fields) or 10
    local targets
    targets, trace.probes_omitted = collect_probe_targets(returns, max_probe_targets, max_probe_table_fields)
    for _, target in ipairs(targets) do
      if hook_state.timeout then
        break
      end
      trace.probes_attempted = trace.probes_attempted + 1
      local pres
      if target.self_arg ~= nil then
        pres = { pcall(target.fn, target.self_arg) }
      else
        pres = { pcall(target.fn) }
      end
      if pres[1] then
        trace.probes_ok = trace.probes_ok + 1
        for i = 2, #pres do
          local rv = pres[i]
          if type(rv) == 'string' and looks_like_lua_text(rv) then
            add_capture(trace, capture_seen, options, 'probe-return-string', rv, {
              label = target.label,
              return_index = i - 1
            })
          end
        end
      else
        trace.probes_failed = trace.probes_failed + 1
        local err = tostring(pres[2] or '')
        if err:find(TIMEOUT_SENTINEL, 1, true) then
          hook_state.timeout = true
        end
      end
    end
  end

  clear_hooks(hook_state)
  if hook_state.timeout then
    if not runtime_err or runtime_err == '' then
      runtime_err = 'deobf sandbox timeout'
    end
  end

  return {
    ok = ok and not hook_state.timeout,
    compile_ok = true,
    timeout = hook_state.timeout,
    error = runtime_err,
    captures = trace.captures,
    captures_dropped = trace.captures_dropped,
    stats = {
      load_calls = trace.load_calls,
      load_errors = trace.load_errors,
      load_skipped = trace.load_skipped,
      load_reader_calls = trace.load_reader_calls,
      load_reader_errors = trace.load_reader_errors,
      probes_attempted = trace.probes_attempted,
      probes_ok = trace.probes_ok,
      probes_failed = trace.probes_failed,
      probes_omitted = trace.probes_omitted,
      undefined_proxy_reads = trace.undefined_proxy_reads,
      undefined_proxy_objects = trace.undefined_proxy_objects,
      tamper_signals = trace.tamper_signals,
      tamper_errors_suppressed = trace.tamper_errors_suppressed
    },
    trace = trace_enabled and {
      events = lint_trace.events or {},
      history = lint_trace.history or {},
      require_calls = lint_trace.require_calls or {},
      proxy_reads = lint_trace.proxy_reads or {},
      global_reads = lint_trace.global_reads or {},
      global_writes = lint_trace.global_writes or {},
      text_captures = capture_text_strings and text_trace.captures or {},
      text_captures_dropped = capture_text_strings and text_trace.captures_dropped or 0
    } or nil
  }
end

return DeobfSandbox
