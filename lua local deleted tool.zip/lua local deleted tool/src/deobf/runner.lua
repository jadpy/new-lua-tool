local Lexer = require('src.lexer')
local Parser = require('src.parser')
local LexerFull = require('src.lexer_full')
local Formatter = require('src.formatter')
local DeobfSandbox = require('src.deobf.sandbox')
local VMTrace = require('src.deobf.vmtrace')
local Devirtualizer = require('src.deobf.devirtualizer')
local Unlock = require('src.deobf.unlock')
local AntiTamper = require('src.deobf.antitamper')

local Deobf = {}

local function count_char(text, ch)
  local n = 0
  for i = 1, #text do
    if text:sub(i, i) == ch then
      n = n + 1
    end
  end
  return n
end

local function fast_hash32(text)
  local len = #text
  local h = 2166136261
  local step = 1
  if len > 8192 then
    step = math.floor(len / 4096)
    if step < 1 then step = 1 end
  end
  for i = 1, len, step do
    h = (h * 16777619) % 4294967296
    h = (h + text:byte(i)) % 4294967296
  end
  if step > 1 then
    local tail_start = len - 128
    if tail_start < 1 then tail_start = 1 end
    for i = tail_start, len do
      h = (h * 16777619) % 4294967296
      h = (h + text:byte(i)) % 4294967296
    end
  end
  return string.format('%08x', h)
end

local function text_signature(text)
  local len = #text
  local head = text:sub(1, 24)
  local tail = text:sub(-24)
  local hash = fast_hash32(text)
  local nl = count_char(text, '\n')
  return table.concat({ tostring(len), hash, tostring(nl), head, tail }, '|')
end

local function can_compile(source)
  local loader = load or loadstring
  if type(loader) ~= 'function' then
    return true, nil
  end
  local fn, err = loader(source)
  if fn then
    return true, nil
  end
  return false, err
end

local function can_parse(source, dialect)
  local ok, err = pcall(function()
    local tokens = Lexer.new(source, { dialect = dialect }):tokenize()
    local parser = Parser.new(tokens, { dialect = dialect })
    parser:parse()
  end)
  if ok then
    return true, nil
  end
  return false, err
end

local function analyze_state(source, dialect, options)
  options = options or {}
  local compile_ok = false
  local compile_err = 'compile-skipped-fast-mode'
  if options.enable_compile_validation ~= false then
    compile_ok, compile_err = can_compile(source)
  end
  local parse_ok = false
  local parse_err = 'parse-skipped-fast-mode'

  if options.enable_parse_validation == true and #source <= (tonumber(options.max_parse_bytes) or 180000) then
    parse_ok, parse_err = can_parse(source, dialect)
  end

  return {
    parse_ok = parse_ok,
    compile_ok = compile_ok,
    parse_error = parse_err and tostring(parse_err) or nil,
    compile_error = compile_err and tostring(compile_err) or nil
  }
end

local function state_quality(state)
  if not state then return 0 end
  if state.parse_ok and state.compile_ok then return 3 end
  if state.parse_ok then return 2 end
  if state.compile_ok then return 1 end
  return 0
end

local function preview_text(text, max_chars)
  if type(text) ~= 'string' then
    return ''
  end
  local out = {}
  local n = #text
  if n > max_chars then
    n = max_chars
  end
  for i = 1, n do
    local ch = text:sub(i, i)
    if ch == '\n' then
      out[#out + 1] = '\\n'
    elseif ch == '\r' then
      out[#out + 1] = '\\r'
    elseif ch == '\t' then
      out[#out + 1] = '\\t'
    else
      out[#out + 1] = ch
    end
  end
  if #text > max_chars then
    out[#out + 1] = '...'
  end
  return table.concat(out)
end

local function keyword_hits(text)
  local lower = text:lower()
  local keys = {
    'function', 'local', 'return', 'if', 'then', 'end',
    'for', 'while', 'repeat', 'until', 'do'
  }
  local hits = 0
  for _, kw in ipairs(keys) do
    if lower:find(kw, 1, true) then
      hits = hits + 1
    end
  end
  return hits
end

local function is_probably_text(text)
  if type(text) ~= 'string' or text == '' then
    return false
  end
  if text:find('\0', 1, true) then
    return false
  end
  local ctrl = 0
  for i = 1, #text do
    local b = text:byte(i)
    if b and (b < 9 or (b > 13 and b < 32)) then
      ctrl = ctrl + 1
    end
  end
  local max_ctrl = math.max(2, math.floor(#text * 0.02))
  return ctrl <= max_ctrl
end

local function is_valid_utf8(text)
  if type(text) ~= 'string' then
    return false
  end
  local i = 1
  local len = #text
  while i <= len do
    local b1 = text:byte(i)
    if not b1 then
      return false
    end
    if b1 < 0x80 then
      i = i + 1
    elseif b1 >= 0xC2 and b1 <= 0xDF then
      local b2 = text:byte(i + 1)
      if not b2 or b2 < 0x80 or b2 > 0xBF then
        return false
      end
      i = i + 2
    elseif b1 == 0xE0 then
      local b2 = text:byte(i + 1)
      local b3 = text:byte(i + 2)
      if not b2 or not b3 then
        return false
      end
      if b2 < 0xA0 or b2 > 0xBF or b3 < 0x80 or b3 > 0xBF then
        return false
      end
      i = i + 3
    elseif (b1 >= 0xE1 and b1 <= 0xEC) or b1 == 0xEE or b1 == 0xEF then
      local b2 = text:byte(i + 1)
      local b3 = text:byte(i + 2)
      if not b2 or not b3 then
        return false
      end
      if b2 < 0x80 or b2 > 0xBF or b3 < 0x80 or b3 > 0xBF then
        return false
      end
      i = i + 3
    elseif b1 == 0xED then
      local b2 = text:byte(i + 1)
      local b3 = text:byte(i + 2)
      if not b2 or not b3 then
        return false
      end
      -- U+D800..U+DFFF (surrogates) are invalid in UTF-8.
      if b2 < 0x80 or b2 > 0x9F or b3 < 0x80 or b3 > 0xBF then
        return false
      end
      i = i + 3
    elseif b1 == 0xF0 then
      local b2 = text:byte(i + 1)
      local b3 = text:byte(i + 2)
      local b4 = text:byte(i + 3)
      if not b2 or not b3 or not b4 then
        return false
      end
      if b2 < 0x90 or b2 > 0xBF then
        return false
      end
      if b3 < 0x80 or b3 > 0xBF or b4 < 0x80 or b4 > 0xBF then
        return false
      end
      i = i + 4
    elseif b1 >= 0xF1 and b1 <= 0xF3 then
      local b2 = text:byte(i + 1)
      local b3 = text:byte(i + 2)
      local b4 = text:byte(i + 3)
      if not b2 or not b3 or not b4 then
        return false
      end
      if b2 < 0x80 or b2 > 0xBF or b3 < 0x80 or b3 > 0xBF or b4 < 0x80 or b4 > 0xBF then
        return false
      end
      i = i + 4
    elseif b1 == 0xF4 then
      local b2 = text:byte(i + 1)
      local b3 = text:byte(i + 2)
      local b4 = text:byte(i + 3)
      if not b2 or not b3 or not b4 then
        return false
      end
      if b2 < 0x80 or b2 > 0x8F then
        return false
      end
      if b3 < 0x80 or b3 > 0xBF or b4 < 0x80 or b4 > 0xBF then
        return false
      end
      i = i + 4
    else
      return false
    end
  end
  return true
end

local function ascii_printable_ratio(text)
  if type(text) ~= 'string' or text == '' then
    return 0
  end
  local printable = 0
  for i = 1, #text do
    local b = text:byte(i)
    if b and ((b >= 32 and b <= 126) or b == 9 or b == 10 or b == 13) then
      printable = printable + 1
    end
  end
  return printable / #text
end

local function is_texty_string(text, min_ascii_ratio)
  if type(text) ~= 'string' or text == '' then
    return false
  end
  if not is_probably_text(text) then
    return false
  end
  if text:find('[\128-\255]') then
    return is_valid_utf8(text)
  end
  return ascii_printable_ratio(text) >= (tonumber(min_ascii_ratio) or 0.92)
end

local function looks_like_lua_text(text)
  if type(text) ~= 'string' then
    return false
  end
  if #text < 8 then
    return false
  end
  if not is_probably_text(text) then
    return false
  end
  if text:find('^[A-Za-z0-9+/=\r\n]+$') then
    return false
  end
  if text:find('%f[%a_]function%f[^%a_]') then
    return true
  end
  if text:find('%f[%a_]local%f[^%a_]') and (text:find('=', 1, true) or text:find('\n', 1, true)) then
    return true
  end
  if text:find('%f[%a_]return%f[^%a_]') and text:find('\n', 1, true) then
    return true
  end
  if text:match('^%s*[_%a][%w_%.:]*%s*%(') and text:find('%)', 1, false) then
    return true
  end
  if text:match('^%s*[_%a][%w_]*%s*=') then
    return true
  end
  return false
end

local decode_lua_string_literal

local function looks_obfuscated_runtime_candidate(source)
  if type(source) ~= 'string' or source == '' then
    return false
  end

  local score = 0
  local lines = count_char(source, '\n') + 1
  if #source >= 1600 and lines <= 4 then
    score = score + 2
  end
  if source:find('\\%d%d%d') then
    score = score + 2
  end
  if source:find('return(function', 1, true) then
    score = score + 1
  end
  if source:find('newproxy', 1, true) then
    score = score + 1
  end
  if source:find('getfenv', 1, true) or source:find('setfenv', 1, true) then
    score = score + 1
  end
  if source:find('string.char', 1, true) then
    score = score + 1
  end
  if source:find('table.concat', 1, true) then
    score = score + 1
  end

  return score >= 3
end

local function decode_base64(input)
  if type(input) ~= 'string' or input == '' then
    return nil
  end
  if input:find('[^A-Za-z0-9+/=]') then
    return nil
  end
  if (#input % 4) ~= 0 then
    return nil
  end

  local alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
  local rev = {}
  for i = 1, #alpha do
    rev[alpha:sub(i, i)] = i - 1
  end

  local out = {}
  local i = 1
  while i <= #input do
    local c1 = input:sub(i, i)
    local c2 = input:sub(i + 1, i + 1)
    local c3 = input:sub(i + 2, i + 2)
    local c4 = input:sub(i + 3, i + 3)

    local n1 = rev[c1]
    local n2 = rev[c2]
    if n1 == nil or n2 == nil then
      return nil
    end

    local n3 = c3 == '=' and 0 or rev[c3]
    local n4 = c4 == '=' and 0 or rev[c4]
    if n3 == nil or n4 == nil then
      return nil
    end

    local triple = n1 * 262144 + n2 * 4096 + n3 * 64 + n4
    local b1 = math.floor(triple / 65536) % 256
    local b2 = math.floor(triple / 256) % 256
    local b3 = triple % 256

    out[#out + 1] = string.char(b1)
    if c3 ~= '=' then
      out[#out + 1] = string.char(b2)
    end
    if c4 ~= '=' then
      out[#out + 1] = string.char(b3)
    end

    i = i + 4
  end

  return table.concat(out)
end

local function safe_eval_number_expr(expr)
  if type(expr) ~= 'string' or expr == '' then
    return nil
  end
  if not expr:match('^[%d%+%-%(%s%)]+$') then
    return nil
  end
  local fn, err = load('return ' .. expr, '@deobf_numexpr', 't', {})
  if not fn then
    return nil, err
  end
  local ok, value = pcall(fn)
  if not ok or type(value) ~= 'number' then
    return nil, value
  end
  if value ~= value or value == math.huge or value == -math.huge then
    return nil
  end
  return math.floor(value), nil
end

local function decode_custom_base64(input, map)
  if type(input) ~= 'string' or input == '' or type(map) ~= 'table' then
    return nil
  end

  local out = {}
  local acc = 0
  local count = 0

  for i = 1, #input do
    local ch = input:sub(i, i)
    if ch == '=' then
      if count == 2 then
        out[#out + 1] = string.char(math.floor(acc / 16) % 256)
      elseif count == 3 then
        out[#out + 1] = string.char(math.floor(acc / 1024) % 256)
        out[#out + 1] = string.char(math.floor(acc / 4) % 256)
      end
      return table.concat(out)
    end

    local v = map[ch]
    if type(v) ~= 'number' then
      return nil
    end
    acc = acc * 64 + v
    count = count + 1
    if count == 4 then
      out[#out + 1] = string.char(math.floor(acc / 65536) % 256)
      out[#out + 1] = string.char(math.floor(acc / 256) % 256)
      out[#out + 1] = string.char(acc % 256)
      acc = 0
      count = 0
    end
  end

  if count == 2 then
    out[#out + 1] = string.char(math.floor(acc / 16) % 256)
  elseif count == 3 then
    out[#out + 1] = string.char(math.floor(acc / 1024) % 256)
    out[#out + 1] = string.char(math.floor(acc / 4) % 256)
  end
  return table.concat(out)
end

local function is_mostly_printable_text(text)
  if type(text) ~= 'string' or text == '' then
    return false
  end
  if text:find('\0', 1, true) then
    return false
  end
  local printable = 0
  for i = 1, #text do
    local b = text:byte(i)
    if b and ((b >= 32 and b <= 126) or b == 9 or b == 10 or b == 13) then
      printable = printable + 1
    end
  end
  return (printable / #text) >= 0.74
end

local function extract_custom_char_maps(source, max_maps)
  local out = {}
  local limit = tonumber(max_maps) or 3
  if limit < 1 then
    limit = 1
  end

  for table_lit in source:gmatch('local%s+[%a_][%w_]*%s*=%s*(%b{})') do
    if #out >= limit then
      break
    end
    local body = table_lit:sub(2, -2)
    local map = {}

    for raw_key, raw_expr in body:gmatch('%[([^%]]+)%]%s*=%s*([^,;]+)') do
      local key = decode_lua_string_literal(raw_key)
      local value = safe_eval_number_expr(raw_expr)
      if type(key) == 'string' and #key == 1 and type(value) == 'number' and value >= 0 and value <= 63 then
        map[key] = value
      end
    end

    for key, raw_expr in body:gmatch('([%a_][%w_]*)%s*=%s*([^,;]+)') do
      local value = safe_eval_number_expr(raw_expr)
      if #key == 1 and type(value) == 'number' and value >= 0 and value <= 63 then
        map[key] = value
      end
    end

    local size = 0
    local min_v = 999
    local max_v = -1
    local value_seen = {}
    for _, v in pairs(map) do
      size = size + 1
      value_seen[v] = true
      if v < min_v then min_v = v end
      if v > max_v then max_v = v end
    end
    local unique_count = 0
    for _ in pairs(value_seen) do
      unique_count = unique_count + 1
    end

    if size >= 48 and unique_count >= 48 and min_v <= 0 and max_v >= 63 then
      out[#out + 1] = {
        map = map,
        size = size,
        unique_count = unique_count,
        min_value = min_v,
        max_value = max_v
      }
    end
  end

  return out
end

decode_lua_string_literal = function(lit)
  if type(lit) ~= 'string' or lit == '' then
    return nil
  end
  local fn, err = load('return ' .. lit, '@deobf_static', 't', {})
  if not fn then
    return nil, err
  end
  local ok, value = pcall(fn)
  if not ok or type(value) ~= 'string' then
    return nil, value
  end
  return value, nil
end

local function lua_quote_ascii(text)
  if type(text) ~= 'string' then
    return nil
  end
  local out = { '"' }
  for i = 1, #text do
    local b = text:byte(i)
    if b == 34 then
      out[#out + 1] = '\\"'
    elseif b == 92 then
      out[#out + 1] = '\\\\'
    elseif b == 9 then
      out[#out + 1] = '\\t'
    elseif b == 10 then
      out[#out + 1] = '\\n'
    elseif b == 13 then
      out[#out + 1] = '\\r'
    elseif b and b >= 32 and b <= 126 then
      out[#out + 1] = string.char(b)
    else
      out[#out + 1] = string.format('\\%03d', b or 0)
    end
  end
  out[#out + 1] = '"'
  return table.concat(out)
end

local function to_hex_bytes(text, max_bytes)
  if type(text) ~= 'string' then
    return ''
  end
  max_bytes = tonumber(max_bytes) or 256
  if max_bytes < 8 then
    max_bytes = 8
  end
  local n = math.min(#text, max_bytes)
  local out = {}
  for i = 1, n do
    out[#out + 1] = string.format('%02X', text:byte(i))
  end
  local hex = table.concat(out, ' ')
  if #text > n then
    hex = hex .. ' ...'
  end
  return hex
end

local function build_trace_dump_file(layers, options)
  options = options or {}
  local max_items = tonumber(options.dump_max_items) or 80
  local max_item_bytes = tonumber(options.dump_max_item_bytes) or 600000
  local max_total_bytes = tonumber(options.dump_max_total_bytes) or 4194304
  if max_items < 1 then max_items = 1 end
  if max_item_bytes < 1024 then max_item_bytes = 1024 end
  if max_total_bytes < max_item_bytes then max_total_bytes = max_item_bytes end

  local out = {}
  out[#out + 1] = '-- Runtime capture dump (trace)'
  out[#out + 1] = '-- Generated at: ' .. os.date('!%Y-%m-%dT%H:%M:%SZ')
  out[#out + 1] = '-- This file stores captured runtime chunks as strings for analysis.'
  out[#out + 1] = ''
  out[#out + 1] = 'local dump = {'
  out[#out + 1] = '  runtime_chunks = {},'
  out[#out + 1] = '  runtime_chunks_dropped = 0,'
  out[#out + 1] = '  text_captures = {},'
  out[#out + 1] = '  text_captures_dropped = 0,'
  out[#out + 1] = '}'
  out[#out + 1] = ''

  local total = 0
  local added = 0
  local dropped = 0
  local seen = {}
  for _, item in ipairs(layers and layers.candidates or {}) do
    if added >= max_items then
      dropped = dropped + 1
    elseif type(item) == 'table'
      and item.origin ~= 'static'
      and item.kind ~= 'source'
      and type(item.text) == 'string'
      and item.text ~= ''
      and is_probably_text(item.text) then
      local sig = tostring(item.signature or '')
      if sig ~= '' and not seen[sig] then
        seen[sig] = true
        local text = item.text
        if #text <= max_item_bytes and (total + #text) <= max_total_bytes then
          total = total + #text
          added = added + 1
          out[#out + 1] = 'do'
          out[#out + 1] = '  dump.runtime_chunks[#dump.runtime_chunks + 1] = {'
          out[#out + 1] = '    kind = ' .. lua_quote_ascii(tostring(item.kind or 'capture')) .. ','
          out[#out + 1] = '    origin = ' .. lua_quote_ascii(tostring(item.origin or 'runtime')) .. ','
          out[#out + 1] = '    depth = ' .. tostring(tonumber(item.depth) or 0) .. ','
          out[#out + 1] = '    bytes = ' .. tostring(#text) .. ','
          out[#out + 1] = '    signature = ' .. lua_quote_ascii(sig) .. ','
          if item.chunkname ~= nil then
            out[#out + 1] = '    chunkname = ' .. lua_quote_ascii(tostring(item.chunkname)) .. ','
          end
          if item.global ~= nil then
            out[#out + 1] = '    global = ' .. lua_quote_ascii(tostring(item.global)) .. ','
          end
          out[#out + 1] = '    looks_like_lua = ' .. tostring(item.looks_like_lua and true or false) .. ','
          out[#out + 1] = '    is_probable_text = ' .. tostring(item.is_probable_text and true or false) .. ','
          out[#out + 1] = '    text = ' .. lua_quote_ascii(text) .. ','
          out[#out + 1] = '  }'
          out[#out + 1] = 'end'
        else
          dropped = dropped + 1
        end
      end
    end
  end

  local text_added = 0
  local text_total = 0
  local text_dropped = 0
  local text_seen = {}
  for _, attempt in ipairs(layers and layers.attempts or {}) do
    local tr = type(attempt) == 'table' and attempt.trace or nil
    local caps = tr and tr.text_captures
    if type(caps) == 'table' then
      for _, c in ipairs(caps) do
        if text_added >= max_items then
          text_dropped = text_dropped + 1
        elseif type(c) == 'table' and type(c.text) == 'string' and c.text ~= '' then
          local sig = tostring(c.signature or '')
          if sig == '' then
            sig = text_signature(c.text)
          end
          if not text_seen[sig] then
            text_seen[sig] = true
            local text = c.text
            if #text <= max_item_bytes and (text_total + #text) <= max_total_bytes then
              text_total = text_total + #text
              text_added = text_added + 1
              out[#out + 1] = 'do'
              out[#out + 1] = '  dump.text_captures[#dump.text_captures + 1] = {'
              out[#out + 1] = '    kind = ' .. lua_quote_ascii(tostring(c.kind or 'text')) .. ','
              out[#out + 1] = '    bytes = ' .. tostring(#text) .. ','
              out[#out + 1] = '    signature = ' .. lua_quote_ascii(sig) .. ','
              out[#out + 1] = '    text = ' .. lua_quote_ascii(text) .. ','
              out[#out + 1] = '  }'
              out[#out + 1] = 'end'
            else
              text_dropped = text_dropped + 1
            end
          end
        end
      end
    end
  end

  out[#out + 1] = ''
  out[#out + 1] = 'dump.runtime_chunks_dropped = ' .. tostring(dropped)
  out[#out + 1] = 'dump.text_captures_dropped = ' .. tostring(text_dropped)
  out[#out + 1] = ''
  out[#out + 1] = 'return dump'

  return table.concat(out, '\n')
end

local function collect_base64_decoded_strings(source, dialect, options)
  options = options or {}
  if type(source) ~= 'string' or source == '' then
    return {}, nil, {}
  end

  local max_items = tonumber(options.max_items) or 4096
  local min_encoded_len = tonumber(options.min_encoded_len) or 12
  local max_decoded_len = tonumber(options.max_decoded_len) or 1048576
  local max_custom_maps = tonumber(options.max_custom_maps) or 6
  if max_items < 1 then max_items = 1 end
  if min_encoded_len < 4 then min_encoded_len = 4 end
  if max_decoded_len < 64 then max_decoded_len = 64 end
  if max_custom_maps < 0 then max_custom_maps = 0 end

  local ok, tokens = pcall(function()
    return LexerFull.new(source, { dialect = dialect }):tokenize()
  end)
  if not ok or type(tokens) ~= 'table' then
    return {}, nil
  end

  local decoded_entries = {}
  for _, tok in ipairs(tokens) do
    if tok.type == 'string' and type(tok.value) == 'string' then
      local decoded = decode_lua_string_literal(tok.value)
      if type(decoded) == 'string' and #decoded >= min_encoded_len then
        decoded_entries[#decoded_entries + 1] = decoded
      end
    end
  end

  local function normalize_b64(s)
    if type(s) ~= 'string' or s == '' then
      return nil
    end
    local cleaned = s:gsub('[\r\n\t ]', '')
    if cleaned == '' then
      return nil
    end
    -- base64url variants are common in the wild.
    cleaned = cleaned:gsub('%-', '+'):gsub('_', '/')
    local mod = (#cleaned % 4)
    if mod == 1 then
      return nil
    elseif mod == 2 then
      cleaned = cleaned .. '=='
    elseif mod == 3 then
      cleaned = cleaned .. '='
    end
    return cleaned
  end

  local custom_maps = max_custom_maps > 0 and extract_custom_char_maps(source, max_custom_maps) or {}
  local best_custom = nil
  local best_score = -1
  local best_hits = 0

  for _, info in ipairs(custom_maps) do
    local hits = 0
    local score = 0
    local map = info.map
    for i = 1, math.min(#decoded_entries, 220) do
      local raw = decoded_entries[i]
      local norm = normalize_b64(raw)
      if norm then
        local out_text = decode_custom_base64(norm, map)
        if out_text and out_text ~= '' then
          hits = hits + 1
          if is_mostly_printable_text(out_text) then
            score = score + 3
          else
            score = score + 1
          end
        end
      end
    end
    if hits >= 3 and score > best_score then
      best_score = score
      best_hits = hits
      best_custom = map
    elseif hits >= 3 and score == best_score and best_custom and hits > best_hits then
      best_hits = hits
      best_custom = map
    end
  end

  local out_text = {}
  local out_bin = {}
  local seen_text = {}
  local seen_bin = {}

  local function add_text(value)
    if #out_text >= max_items then
      return
    end
    if type(value) ~= 'string' or value == '' then
      return
    end
    if #value > max_decoded_len then
      return
    end
    local sig = text_signature(value)
    if seen_text[sig] then
      return
    end
    seen_text[sig] = true
    out_text[#out_text + 1] = value
  end

  local function add_bin(encoded, decoded, codec)
    if #out_bin >= max_items then
      return
    end
    if type(decoded) ~= 'string' or decoded == '' then
      return
    end
    if #decoded > max_decoded_len then
      return
    end
    local sig = text_signature(decoded)
    if seen_bin[sig] then
      return
    end
    seen_bin[sig] = true
    out_bin[#out_bin + 1] = {
      encoded = encoded,
      decoded = decoded,
      codec = codec
    }
  end

  for _, raw in ipairs(decoded_entries) do
    local norm = normalize_b64(raw)
    if norm then
      local std = decode_base64(norm)
      local custom = best_custom and decode_custom_base64(norm, best_custom) or nil

      -- If we detected a custom 64-char map, prefer it and avoid dumping the
      -- "standard base64" decode of custom-alphabet strings (usually garbage).
      if custom and custom ~= '' and (std == nil or std == '') then
        if is_texty_string(custom, 0.92) then
          add_text(custom)
        else
          add_bin(raw, custom, 'custom')
        end
      elseif std and std ~= '' and (custom == nil or custom == '') then
        if is_texty_string(std, 0.92) then
          add_text(std)
        else
          add_bin(raw, std, 'std')
        end
      elseif custom and custom ~= '' and std and std ~= '' then
        local custom_texty = is_texty_string(custom, 0.92)
        local std_texty = is_texty_string(std, 0.92)
        if custom_texty and not std_texty then
          add_text(custom)
        elseif std_texty and not custom_texty then
          add_text(std)
        elseif custom_texty and std_texty then
          -- Prefer longer (tends to preserve more data), but keep custom on ties.
          if #std > #custom then
            add_text(std)
          else
            add_text(custom)
          end
        else
          -- Neither looks like text: keep in a separate binary dump.
          add_bin(raw, custom, 'custom')
        end
      end
    end
  end

  return out_text, best_custom, out_bin
end

local function build_decoded_string_dump(strings, title, meta)
  strings = type(strings) == 'table' and strings or {}
  meta = meta or {}
  local out = {}
  out[#out + 1] = '-- ' .. tostring(title or 'decoded string dump')
  out[#out + 1] = '-- Generated at: ' .. os.date('!%Y-%m-%dT%H:%M:%SZ')
  if meta.note and meta.note ~= '' then
    out[#out + 1] = '-- Note: ' .. tostring(meta.note)
  end
  out[#out + 1] = string.format('-- Strings: %d', #strings)
  out[#out + 1] = ''
  out[#out + 1] = 'return {'
  for i = 1, #strings do
    local s = strings[i]
    if type(s) == 'string' then
      out[#out + 1] = '  ' .. lua_quote_ascii(s) .. ','
    end
  end
  out[#out + 1] = '}'
  return table.concat(out, '\n')
end

local function build_binary_string_dump(entries, title, meta)
  entries = type(entries) == 'table' and entries or {}
  meta = meta or {}
  local max_hex_bytes = tonumber(meta.max_hex_bytes) or 256

  local out = {}
  out[#out + 1] = '-- ' .. tostring(title or 'binary decoded strings')
  out[#out + 1] = '-- Generated at: ' .. os.date('!%Y-%m-%dT%H:%M:%SZ')
  out[#out + 1] = string.format('-- Entries: %d', #entries)
  out[#out + 1] = ''
  out[#out + 1] = 'return {'
  for i = 1, #entries do
    local e = entries[i]
    if type(e) == 'table' then
      out[#out + 1] = '  {'
      if e.origin ~= nil then
        out[#out + 1] = '    origin = ' .. lua_quote_ascii(tostring(e.origin)) .. ','
      end
      if e.codec ~= nil then
        out[#out + 1] = '    codec = ' .. lua_quote_ascii(tostring(e.codec)) .. ','
      end
      if e.index ~= nil then
        out[#out + 1] = '    index = ' .. tostring(tonumber(e.index) or 0) .. ','
      end
      if type(e.encoded) == 'string' then
        out[#out + 1] = '    encoded = ' .. lua_quote_ascii(e.encoded) .. ','
      end
      if type(e.decoded) == 'string' then
        out[#out + 1] = '    bytes = ' .. tostring(#e.decoded) .. ','
        out[#out + 1] = '    hex = ' .. lua_quote_ascii(to_hex_bytes(e.decoded, max_hex_bytes)) .. ','
        out[#out + 1] = '    decoded = ' .. lua_quote_ascii(e.decoded) .. ','
      end
      out[#out + 1] = '  },'
    end
  end
  out[#out + 1] = '}'
  return table.concat(out, '\n')
end

local function build_string_table_map_dump(extra)
  extra = type(extra) == 'table' and extra or {}
  local values_pretty = type(extra.values_pretty) == 'table' and extra.values_pretty or {}
  local values_final = type(extra.values_final) == 'table' and extra.values_final or {}

  local n = math.max(#values_pretty, #values_final)
  local out = {}
  out[#out + 1] = '-- decoded string table map'
  out[#out + 1] = '-- Generated at: ' .. os.date('!%Y-%m-%dT%H:%M:%SZ')
  out[#out + 1] = '-- Table: ' .. tostring(extra.table_name or '?')
  out[#out + 1] = string.format('-- Entries: %d', n)
  out[#out + 1] = ''
  out[#out + 1] = 'return {'
  for i = 1, n do
    local encoded = values_pretty[i]
    local decoded = values_final[i]
    out[#out + 1] = '  {'
    out[#out + 1] = '    index = ' .. tostring(i) .. ','
    if type(encoded) == 'string' then
      out[#out + 1] = '    encoded = ' .. lua_quote_ascii(encoded) .. ','
    else
      out[#out + 1] = '    encoded = nil,'
    end
    if type(decoded) == 'string' then
      out[#out + 1] = '    decoded = ' .. lua_quote_ascii(decoded) .. ','
    else
      out[#out + 1] = '    decoded = nil,'
    end
    out[#out + 1] = '  },'
  end
  out[#out + 1] = '}'
  return table.concat(out, '\n')
end

local function compute_line_starts(source)
  local starts = { 1 }
  local i = 1
  while i <= #source do
    local b = source:byte(i)
    if b == 13 then -- \r
      if source:byte(i + 1) == 10 then
        i = i + 1
      end
      starts[#starts + 1] = i + 1
    elseif b == 10 then -- \n
      starts[#starts + 1] = i + 1
    end
    i = i + 1
  end
  return starts
end

local function rewrite_base64_string_literals(source, dialect, custom_map, options)
  options = options or {}
  if type(source) ~= 'string' or source == '' then
    return source, 0
  end

  local max_literal_len = tonumber(options.max_literal_len) or 4096
  local min_encoded_len = tonumber(options.min_encoded_len) or 12
  if max_literal_len < 64 then max_literal_len = 64 end
  if min_encoded_len < 4 then min_encoded_len = 4 end

  local ok, tokens = pcall(function()
    return LexerFull.new(source, { dialect = dialect }):tokenize()
  end)
  if not ok or type(tokens) ~= 'table' then
    return source, 0
  end

  local function normalize_b64(s)
    if type(s) ~= 'string' or s == '' then
      return nil
    end
    local cleaned = s:gsub('[\r\n\t ]', '')
    if cleaned == '' then
      return nil
    end
    cleaned = cleaned:gsub('%-', '+'):gsub('_', '/')
    local mod = (#cleaned % 4)
    if mod == 1 then
      return nil
    elseif mod == 2 then
      cleaned = cleaned .. '=='
    elseif mod == 3 then
      cleaned = cleaned .. '='
    end
    return cleaned
  end

  local line_starts = compute_line_starts(source)
  local changes = {}

  for _, tok in ipairs(tokens) do
    if tok.type == 'string' and type(tok.value) == 'string'
      and type(tok.line) == 'number' and type(tok.col) == 'number' then
      local lit = tok.value
      local decoded = decode_lua_string_literal(lit)
      if type(decoded) == 'string' and #decoded >= min_encoded_len then
        local norm = normalize_b64(decoded)
        if norm then
          local best = nil
          local std = decode_base64(norm)
          if type(std) == 'string' and std ~= '' and is_texty_string(std, 0.92) then
            best = std
          end
          if type(custom_map) == 'table' then
            local custom = decode_custom_base64(norm, custom_map)
            if type(custom) == 'string' and custom ~= '' and is_texty_string(custom, 0.92) then
              if not best or #custom > #best then
                best = custom
              end
            end
          end

          if type(best) == 'string' and #best <= max_literal_len then
            local new_lit = lua_quote_ascii(best)
            if new_lit and new_lit ~= lit then
              local base = line_starts[tok.line] or 1
              local s = base + tok.col - 1
              local e = s + #lit - 1
              if s >= 1 and e <= #source and source:sub(s, e) == lit then
                changes[#changes + 1] = { start_pos = s, end_pos = e, value = new_lit }
              end
            end
          end
        end
      end
    end
  end

  if #changes == 0 then
    return source, 0
  end

  table.sort(changes, function(a, b)
    return a.start_pos > b.start_pos
  end)

  local out = source
  for _, item in ipairs(changes) do
    out = out:sub(1, item.start_pos - 1) .. item.value .. out:sub(item.end_pos + 1)
  end

  return out, #changes
end

local function normalize_short_string_literals(source, dialect, options)
  options = options or {}
  local max_literal_len = tonumber(options.max_literal_len) or 65536
  if max_literal_len < 256 then
    max_literal_len = 256
  end

  local ok, tokens = pcall(function()
    return LexerFull.new(source, { dialect = dialect }):tokenize()
  end)
  if not ok or type(tokens) ~= 'table' then
    return source, 0
  end

  local line_starts = compute_line_starts(source)
  local changes = {}

  for _, tok in ipairs(tokens) do
    if tok.type == 'string' and type(tok.value) == 'string' then
      local lit = tok.value
      local q = lit:sub(1, 1)
      if (q == '"' or q == "'") and #lit <= max_literal_len and type(tok.line) == 'number' and type(tok.col) == 'number' then
        local base = line_starts[tok.line] or 1
        local s = base + tok.col - 1
        local e = s + #lit - 1
        if s >= 1 and e <= #source and source:sub(s, e) == lit then
          local decoded = decode_lua_string_literal(lit)
          if type(decoded) == 'string' then
            local new_lit = lua_quote_ascii(decoded)
            if new_lit ~= lit then
              changes[#changes + 1] = { start_pos = s, end_pos = e, value = new_lit }
            end
          end
        end
      end
    end
  end

  if #changes == 0 then
    return source, 0
  end

  table.sort(changes, function(a, b)
    return a.start_pos > b.start_pos
  end)

  local out = source
  for _, item in ipairs(changes) do
    out = out:sub(1, item.start_pos - 1) .. item.value .. out:sub(item.end_pos + 1)
  end

  return out, #changes
end

local function extract_static_candidates(source, dialect, options)
  options = options or {}
  local out = {}
  local seen = {}
  local min_literal_len = tonumber(options.min_static_literal_len) or 12
  local min_decoded_len = tonumber(options.min_static_decoded_len) or 8
  local max_static_candidates = tonumber(options.max_static_candidates) or 120

  local function add(kind, text, depth, extra)
    if #out >= max_static_candidates then
      return
    end
    if type(text) ~= 'string' or text == '' then
      return
    end
    local sig = text_signature(text)
    if seen[sig] then
      return
    end
    seen[sig] = true
    local row = {
      text = text,
      kind = kind,
      origin = 'static',
      depth = depth or 0,
      bytes = #text,
      signature = sig,
      looks_like_lua = looks_like_lua_text(text),
      is_probable_text = is_probably_text(text),
      truncated = false
    }
    if type(extra) == 'table' then
      for k, v in pairs(extra) do
        row[k] = v
      end
    end
    out[#out + 1] = row
  end

  local ok, tokens = pcall(function()
    return LexerFull.new(source, { dialect = dialect }):tokenize()
  end)
  if not ok or type(tokens) ~= 'table' then
    return out
  end

  local decoded_strings = {}
  local decoded_base64ish = {}
  local decoded_entries = {}

  for _, tok in ipairs(tokens) do
    if tok.type == 'string' and type(tok.value) == 'string' and #tok.value >= min_literal_len then
      local decoded = decode_lua_string_literal(tok.value)
      if decoded then
        decoded_entries[#decoded_entries + 1] = {
          token = tok,
          decoded = decoded
        }
      end
      if decoded and #decoded >= min_decoded_len then
        decoded_strings[#decoded_strings + 1] = decoded
        add('static-string-decoded', decoded, 0)
        if decoded:find('^[A-Za-z0-9+/=]+$') and (#decoded % 4 == 0) and #decoded >= 16 then
          decoded_base64ish[#decoded_base64ish + 1] = decoded
          local b64 = decode_base64(decoded)
          if b64 and #b64 >= min_decoded_len then
            add('static-base64-decoded', b64, 1)
          end
        end
      end
    end
  end

  local custom_maps = extract_custom_char_maps(source, options.max_custom_maps)
  local best_custom = nil
  local best_score = -1
  for map_idx, info in ipairs(custom_maps) do
    local score = 0
    local hits = 0
    for _, entry in ipairs(decoded_entries) do
      local text = entry.decoded
      if type(text) == 'string' and #text >= 8 and (#text % 4) == 0 and text:find('^[A-Za-z0-9+/=]+$') then
        local out_text = decode_custom_base64(text, info.map)
        if out_text and #out_text >= 3 then
          hits = hits + 1
          if is_mostly_printable_text(out_text) then
            score = score + 3
          else
            score = score + 1
          end
        end
      end
    end
    if hits >= 3 and score > best_score then
      best_score = score
      best_custom = {
        index = map_idx,
        map = info.map,
        size = info.size,
        hits = hits,
        score = score
      }
    end
  end

  if best_custom then
    local replacements = {}
    local readable_custom = {}
    local line_starts = { 1 }
    for i = 1, #source do
      if source:byte(i) == 10 then
        line_starts[#line_starts + 1] = i + 1
      end
    end

    for _, entry in ipairs(decoded_entries) do
      local text = entry.decoded
      local tok = entry.token
      if type(text) == 'string' and #text >= 8 and (#text % 4) == 0 and text:find('^[A-Za-z0-9+/=]+$') then
        local out_text = decode_custom_base64(text, best_custom.map)
        if out_text and #out_text >= min_decoded_len then
          add('static-custom-base64-decoded', out_text, 1, {
            custom_map_size = best_custom.size,
            custom_map_hits = best_custom.hits
          })

          if is_mostly_printable_text(out_text) then
            readable_custom[#readable_custom + 1] = out_text
            if #out_text <= 260 and type(tok.line) == 'number' and type(tok.col) == 'number' then
              local line_start = line_starts[tok.line]
              local pos = line_start and (line_start + tok.col - 1) or nil
              if pos and pos >= 1 and (pos + #tok.value - 1) <= #source then
                replacements[#replacements + 1] = {
                  pos = pos,
                  len = #tok.value,
                  old_lit = tok.value,
                  new_lit = lua_quote_ascii(out_text)
                }
              end
            end
          end
        end
      end
    end

    if #readable_custom >= 4 then
      add('static-custom-joined-lines', table.concat(readable_custom, '\n'), 2, {
        custom_map_size = best_custom.size,
        custom_map_hits = best_custom.hits
      })
    end

    if #replacements >= 4 then
      table.sort(replacements, function(a, b)
        return a.pos > b.pos
      end)
      local rewritten = source
      local changed = 0
      for _, rep in ipairs(replacements) do
        local old = rewritten:sub(rep.pos, rep.pos + rep.len - 1)
        if old == rep.old_lit then
          rewritten = rewritten:sub(1, rep.pos - 1) .. rep.new_lit .. rewritten:sub(rep.pos + rep.len)
          changed = changed + 1
        end
      end
      if changed > 0 then
        add('static-custom-literal-rewrite', rewritten, 2, {
          custom_map_size = best_custom.size,
          custom_map_hits = best_custom.hits,
          custom_replacements = changed,
          looks_like_lua = true,
          is_probable_text = true
        })
      end
    end
  end

  if #decoded_strings >= 4 then
    local joined_line = table.concat(decoded_strings, '\n')
    add('static-joined-lines', joined_line, 1)
  end

  if #decoded_base64ish >= 4 then
    local joined = table.concat(decoded_base64ish, '')
    if (#joined % 4) == 0 then
      local b64_joined = decode_base64(joined)
      if b64_joined and #b64_joined >= min_decoded_len then
        add('static-joined-base64', b64_joined, 2)
      end
    end
  end

  return out
end

local function score_candidate(base_text, item, state)
  local score = state_quality(state) * 900
  if item.kind ~= 'source' then
    score = score + 180
  else
    score = score - 60
  end

  if item.kind == 'load' or item.kind == 'loadstring' or item.kind == 'load-reader' then
    score = score + 260
  elseif item.kind == 'return-string' or item.kind == 'probe-return-string' then
    score = score + 140
  elseif item.kind == 'global-write-string' then
    score = score + 90
  end

  if item.looks_like_lua then
    score = score + 100
  end
  if item.is_probable_text == false then
    score = score - 600
  end
  if item.truncated then
    score = score - 220
  end
  if type(item.kind) == 'string' and item.kind:match('^static%-') and not item.looks_like_lua then
    score = score - 180
  end

  local base_len = #base_text > 0 and #base_text or 1
  local delta_ratio = math.abs(#item.text - #base_text) / base_len
  score = score - (math.min(delta_ratio, 2.5) * 75)

  local nl = count_char(item.text, '\n')
  score = score + math.min(nl, 500) * 0.9
  score = score + math.min(keyword_hits(item.text), 40) * 7
  score = score + math.min(#item.text, 300000) / 2200

  if item.depth and item.depth > 0 then
    score = score + math.min(item.depth, 4) * 12
  end

  return score
end

local function quick_score_candidate(base_text, item)
  local score = 0
  if item.kind ~= 'source' then
    score = score + 220
  else
    score = score - 100
  end

  if item.kind == 'load' or item.kind == 'loadstring' or item.kind == 'load-reader' then
    score = score + 280
  elseif item.kind == 'return-string' or item.kind == 'probe-return-string' then
    score = score + 140
  elseif item.kind == 'global-write-string' then
    score = score + 90
  end

  if item.looks_like_lua then
    score = score + 130
  end
  if item.is_probable_text == false then
    score = score - 600
  end
  if item.truncated then
    score = score - 220
  end
  if type(item.kind) == 'string' and item.kind:match('^static%-') and not item.looks_like_lua then
    score = score - 220
  end

  local base_len = #base_text > 0 and #base_text or 1
  local delta_ratio = math.abs(#item.text - #base_text) / base_len
  score = score - (math.min(delta_ratio, 2.5) * 70)

  local nl = count_char(item.text, '\n')
  score = score + math.min(nl, 500) * 0.8
  score = score + math.min(keyword_hits(item.text), 40) * 6
  score = score + math.min(#item.text, 300000) / 2600

  if item.depth and item.depth > 0 then
    score = score + math.min(item.depth, 4) * 10
  end
  return score
end

local function run_dynamic_layers(source, options)
  local max_layers = tonumber(options.max_layers) or 2
  local max_exec_nodes = tonumber(options.max_exec_nodes) or 8
  local max_queue_items = tonumber(options.max_queue_items) or 24
  local max_exec_capture_bytes = tonumber(options.max_exec_capture_bytes) or 1572864
  local max_candidates = tonumber(options.max_candidates) or 120
  local trace_enabled = options.trace == true
  local max_runtime_seconds = tonumber(options.max_runtime_seconds) or (trace_enabled and 24 or 16)
  local started_at = os.clock()

  if max_layers < 0 then max_layers = 0 end
  if max_exec_nodes < 0 then max_exec_nodes = 0 end
  if max_queue_items < 1 then max_queue_items = 1 end
  if max_candidates < 2 then max_candidates = 2 end

  local queue = { { text = source, depth = 0, origin = 'entry' } }
  local head = 1
  local seen_exec = {}
  local seen_queue = { [text_signature(source)] = true }
  local attempts = {}
  local candidates = {}
  local captures_total = 0
  local captures_dropped = 0
  local text_captures_total = 0
  local text_captures_dropped = 0
  local candidate_dropped = 0

  local function add_candidate(item)
    if type(item.text) ~= 'string' or item.text == '' then
      return
    end
    local sig = text_signature(item.text)
    for i = 1, #candidates do
      if candidates[i].signature == sig then
        local prior = candidates[i]
        if (item.depth or 99) < (prior.depth or 99) then
          item.signature = sig
          candidates[i] = item
        end
        return
      end
    end
    if #candidates >= max_candidates then
      candidate_dropped = candidate_dropped + 1
      return
    end
    item.signature = sig
    candidates[#candidates + 1] = item
  end

  add_candidate({
    text = source,
    kind = 'source',
    origin = 'entry',
    depth = 0,
    bytes = #source,
    looks_like_lua = true,
    is_probable_text = true,
    truncated = false
  })

  while head <= #queue and #attempts < max_exec_nodes do
    if (os.clock() - started_at) > max_runtime_seconds then
      break
    end
    local node = queue[head]
    head = head + 1
    local node_sig = text_signature(node.text)
    if not seen_exec[node_sig] then
      seen_exec[node_sig] = true
      local exec = DeobfSandbox.execute(node.text, options)
      local caps = exec.captures or {}
      captures_total = captures_total + #caps
      captures_dropped = captures_dropped + (exec.captures_dropped or 0)
      if trace_enabled and type(exec.trace) == 'table' then
        local tcap = exec.trace.text_captures
        if type(tcap) == 'table' then
          text_captures_total = text_captures_total + #tcap
        end
        text_captures_dropped = text_captures_dropped + (tonumber(exec.trace.text_captures_dropped) or 0)
      end

      local attempt = {
        index = #attempts + 1,
        profile = tostring(options.profile_name or 'default'),
        depth = node.depth,
        origin = node.origin,
        ok = exec.ok and true or false,
        timeout = exec.timeout and true or false,
        error = exec.error,
        capture_count = #caps,
        captures_dropped = exec.captures_dropped or 0,
        stats = exec.stats or {}
      }
      if trace_enabled and type(exec.trace) == 'table' then
        local tcap = exec.trace.text_captures
        attempt.text_capture_count = type(tcap) == 'table' and #tcap or 0
        attempt.text_captures_dropped = tonumber(exec.trace.text_captures_dropped) or 0
      end

      if trace_enabled then
        local cap_items = {}
        local max_trace_caps = tonumber(options.trace_max_caps_per_attempt) or 30
        local preview_len = tonumber(options.trace_preview_len) or 280
        for i = 1, math.min(#caps, max_trace_caps) do
          local c = caps[i]
          cap_items[#cap_items + 1] = {
            kind = c.kind,
            bytes = c.bytes,
            signature = c.signature,
            looks_like_lua = c.looks_like_lua and true or false,
            is_probable_text = c.is_probable_text and true or false,
            truncated = c.truncated and true or false,
            preview = preview_text(c.text or '', preview_len)
          }
        end
        attempt.captures = cap_items
        attempt.trace = exec.trace
      end
      attempts[#attempts + 1] = attempt

      for _, cap in ipairs(caps) do
        add_candidate({
          text = cap.text,
          kind = cap.kind or 'capture',
          origin = node.origin,
          depth = node.depth + 1,
          bytes = cap.bytes or #(cap.text or ''),
          looks_like_lua = cap.looks_like_lua,
          is_probable_text = cap.is_probable_text,
          truncated = cap.truncated,
          chunkname = cap.chunkname,
          global = cap.global
        })

        local can_queue = node.depth < max_layers
          and #queue < max_queue_items
          and type(cap.text) == 'string'
          and #cap.text <= max_exec_capture_bytes
          and cap.is_probable_text
          and (cap.looks_like_lua or cap.kind == 'load' or cap.kind == 'loadstring' or cap.kind == 'load-reader')

        if can_queue then
          local cap_sig = text_signature(cap.text)
          if not seen_queue[cap_sig] then
            seen_queue[cap_sig] = true
            queue[#queue + 1] = {
              text = cap.text,
              depth = node.depth + 1,
              origin = cap.kind or 'capture'
            }
          end
        end
      end
    end
  end

  return {
    attempts = attempts,
    candidates = candidates,
    captures_total = captures_total,
    captures_dropped = captures_dropped,
    text_captures_total = text_captures_total,
    text_captures_dropped = text_captures_dropped,
    candidate_dropped = candidate_dropped,
    queue_total = #queue
  }
end

local function merge_layer_results(base, extra, phase_name)
  if type(base) ~= 'table' then
    return extra
  end
  if type(extra) ~= 'table' then
    return base
  end

  local seen = {}
  for _, item in ipairs(base.candidates or {}) do
    if item.signature then
      seen[item.signature] = true
    elseif item.text then
      seen[text_signature(item.text)] = true
    end
  end

  for _, attempt in ipairs(extra.attempts or {}) do
    local row = {}
    for k, v in pairs(attempt) do
      row[k] = v
    end
    row.index = #base.attempts + 1
    row.phase = tostring(phase_name or row.phase or 'extra')
    base.attempts[#base.attempts + 1] = row
  end

  for _, item in ipairs(extra.candidates or {}) do
    local sig = item.signature
    if not sig and type(item.text) == 'string' then
      sig = text_signature(item.text)
      item.signature = sig
    end
    if sig and not seen[sig] then
      seen[sig] = true
      base.candidates[#base.candidates + 1] = item
    end
  end

  base.captures_total = (base.captures_total or 0) + (extra.captures_total or 0)
  base.captures_dropped = (base.captures_dropped or 0) + (extra.captures_dropped or 0)
  base.text_captures_total = (base.text_captures_total or 0) + (extra.text_captures_total or 0)
  base.text_captures_dropped = (base.text_captures_dropped or 0) + (extra.text_captures_dropped or 0)
  base.candidate_dropped = (base.candidate_dropped or 0) + (extra.candidate_dropped or 0)
  if (extra.queue_total or 0) > (base.queue_total or 0) then
    base.queue_total = extra.queue_total
  end
  return base
end

local function rank_candidates(source, candidates, dialect, options)
  options = options or {}
  local cache = {}
  local ranked = {}
  local pre = {}
  local parse_budget = 48

  local function analyze_cached(text, do_compile)
    local sig = text_signature(text) .. '|' .. (do_compile and '1' or '0')
    if cache[sig] then
      return cache[sig]
    end
    local st = analyze_state(text, dialect, {
      enable_compile_validation = do_compile,
      enable_parse_validation = false
    })
    cache[sig] = st
    return st
  end

  for _, item in ipairs(candidates) do
    pre[#pre + 1] = {
      item = item,
      quick = quick_score_candidate(source, item)
    }
  end

  table.sort(pre, function(a, b)
    if a.quick == b.quick then
      return #a.item.text > #b.item.text
    end
    return a.quick > b.quick
  end)

  if #pre > 0 then
    parse_budget = math.min(#pre, 48 + math.floor(#pre / 3))
  end

  for idx, row in ipairs(pre) do
    local item = row.item
    local st = nil
    local score = row.quick - 1000
    if idx <= parse_budget then
      st = analyze_cached(item.text, item.kind ~= 'source')
      score = score_candidate(source, item, st)
    else
      st = {
        parse_ok = false,
        compile_ok = false,
        parse_error = 'analysis-skipped',
        compile_error = 'analysis-skipped'
      }
    end
    local row = {
      text = item.text,
      kind = item.kind,
      origin = item.origin,
      depth = item.depth or 0,
      bytes = item.bytes or #item.text,
      signature = item.signature,
      looks_like_lua = item.looks_like_lua and true or false,
      is_probable_text = item.is_probable_text and true or false,
      truncated = item.truncated and true or false,
      score = score,
      state = st
    }
    ranked[#ranked + 1] = row
  end

  table.sort(ranked, function(a, b)
    if a.score == b.score then
      local aq = state_quality(a.state)
      local bq = state_quality(b.state)
      if aq == bq then
        if a.depth == b.depth then
          return a.bytes > b.bytes
        end
        return a.depth < b.depth
      end
      return aq > bq
    end
    return a.score > b.score
  end)

  local selected = nil
  for _, item in ipairs(ranked) do
    if item.kind ~= 'source' and item.state.compile_ok then
      selected = item
      break
    end
  end
  if not selected and options.prefer_extracted then
    for _, item in ipairs(ranked) do
      if item.kind ~= 'source' and item.looks_like_lua and item.bytes >= 40 then
        selected = item
        break
      end
    end
  end
  if not selected then
    for _, item in ipairs(ranked) do
      if item.state.compile_ok then
        selected = item
        break
      end
    end
  end
  if not selected then
    for _, item in ipairs(ranked) do
      if item.kind ~= 'source' and item.state.parse_ok then
        selected = item
        break
      end
    end
  end
  if not selected then
    for _, item in ipairs(ranked) do
      if item.kind == 'source' then
        selected = item
        break
      end
    end
  end
  if not selected then
    selected = ranked[1]
  end

  return selected, ranked
end

function Deobf.run(source, options)
  options = options or {}
  local dialect = options.dialect
  local trace_enabled = options.trace == true
  local has_runtime_hint = source:find('loadstring', 1, true)
    or source:find('load(', 1, true)
    or source:find('load ', 1, true)
    or source:find('string.dump', 1, true)
  local has_obf_hint = looks_obfuscated_runtime_candidate(source)
  local trace_parse_enabled = trace_enabled and not has_obf_hint and options.trace_parse_validation ~= false
  local before = analyze_state(source, dialect, {
    enable_compile_validation = trace_enabled,
    enable_parse_validation = trace_parse_enabled,
    max_parse_bytes = options.max_parse_bytes
  })
  local runtime_enabled = options.force_runtime == true or has_runtime_hint ~= nil or has_obf_hint
  local runtime_skip_reason = nil
  if not runtime_enabled then
    runtime_skip_reason = 'no runtime hints (loader or obfuscation patterns)'
  end

  local runtime_max_nodes = 0
  if runtime_enabled then
    runtime_max_nodes = tonumber(options.max_exec_nodes) or 2
  end
  local runtime_max_instructions = options.max_instructions
  local runtime_max_seconds = options.max_seconds
  local runtime_hook_stride = options.hook_stride
  local runtime_total_seconds = tonumber(options.max_runtime_seconds)
  if runtime_enabled and options.force_runtime ~= true then
    if runtime_max_instructions == nil then
      runtime_max_instructions = 420000
    end
    if runtime_max_seconds == nil then
      runtime_max_seconds = 0.55
    end
    if runtime_hook_stride == nil then
      runtime_hook_stride = 1200
    end
  end
  if runtime_total_seconds == nil and runtime_enabled then
    runtime_total_seconds = has_obf_hint and 2.4 or 1.4
  end

  local layers = run_dynamic_layers(source, {
    profile_name = 'primary',
    trace = trace_enabled,
    max_layers = options.max_layers,
    max_exec_nodes = runtime_max_nodes,
    max_queue_items = options.max_queue_items,
    max_exec_capture_bytes = options.max_exec_capture_bytes,
    max_candidates = options.max_candidates,
    max_instructions = runtime_max_instructions,
    max_seconds = runtime_max_seconds,
    hook_stride = runtime_hook_stride,
    max_captures = options.max_captures,
    max_capture_bytes = options.max_capture_bytes,
    max_reader_bytes = options.max_reader_bytes,
    max_reader_parts = options.max_reader_parts,
    min_global_capture_len = options.min_global_capture_len,
    min_char_capture_len = options.min_char_capture_len,
    min_concat_capture_len = options.min_concat_capture_len,
    capture_text_strings = trace_enabled,
    min_text_capture_len = 8,
    probe = options.probe == true,
    max_probe_targets = options.max_probe_targets,
    max_probe_table_fields = options.max_probe_table_fields,
    max_history = options.max_history,
    trace_max_caps_per_attempt = options.trace_max_caps_per_attempt,
    trace_preview_len = options.trace_preview_len,
    execute_loaded = options.execute_loaded == true,
    max_runtime_seconds = runtime_total_seconds,
    undefined_global_mode = options.undefined_global_mode,
    anti_dumper_hardening = options.anti_dumper_hardening
  })
  for _, attempt in ipairs(layers.attempts or {}) do
    attempt.phase = attempt.phase or 'primary'
  end

  local rescue_attempts = 0
  local rescue_used = false
  if runtime_enabled and has_obf_hint and (layers.captures_total or 0) == 0 and options.deobf_rescue ~= false then
    local rescue_max_nodes = math.max(1, math.min(runtime_max_nodes, 2))
    local rescue_layers = run_dynamic_layers(source, {
      profile_name = 'rescue-proxy',
      trace = trace_enabled,
      max_layers = options.max_layers,
      max_exec_nodes = rescue_max_nodes,
      max_queue_items = options.max_queue_items,
      max_exec_capture_bytes = options.max_exec_capture_bytes,
      max_candidates = options.max_candidates,
      max_instructions = math.max(runtime_max_instructions or 420000, 1400000),
      max_seconds = math.max(runtime_max_seconds or 0.55, 1.2),
      hook_stride = math.min(runtime_hook_stride or 1200, 900),
      max_captures = options.max_captures,
      max_capture_bytes = options.max_capture_bytes,
      max_reader_bytes = options.max_reader_bytes,
      max_reader_parts = options.max_reader_parts,
      min_global_capture_len = options.min_global_capture_len,
      min_char_capture_len = options.min_char_capture_len,
      min_concat_capture_len = options.min_concat_capture_len,
      capture_text_strings = trace_enabled,
      min_text_capture_len = 8,
      probe = true,
      max_probe_targets = options.max_probe_targets,
      max_probe_table_fields = options.max_probe_table_fields,
      max_history = options.max_history,
      trace_max_caps_per_attempt = options.trace_max_caps_per_attempt,
      trace_preview_len = options.trace_preview_len,
      execute_loaded = options.execute_loaded == true,
      max_runtime_seconds = math.max(runtime_total_seconds or 1.4, 2.6),
      undefined_global_mode = 'proxy',
      anti_dumper_hardening = true
    })
    rescue_attempts = #(rescue_layers.attempts or {})
    if rescue_attempts > 0 then
      rescue_used = true
      layers = merge_layer_results(layers, rescue_layers, 'rescue-proxy')
    end
  end

  local static_candidates = extract_static_candidates(source, dialect, {
    min_static_literal_len = options.min_static_literal_len,
    min_static_decoded_len = options.min_static_decoded_len,
    max_static_candidates = options.max_static_candidates
  })
  for _, item in ipairs(static_candidates) do
    layers.candidates[#layers.candidates + 1] = item
  end

  local selected, ranked = rank_candidates(source, layers.candidates, dialect, {
    prefer_extracted = options.prefer_extracted ~= false
  })
  local output = selected and selected.text or source
  local post_steps = {}
  local unlock_export_source = nil
  local unlock_extra = nil
  local unlock_report = {
    enabled = options.unlock ~= false,
    changed = false,
    applied = false,
    replacements = 0,
    replacement_skipped = 0
  }

  if unlock_report.enabled then
    local unlock_opts = {
      analysis_source = source,
      max_replacements = options.unlock_max_replacements,
      max_literal_len = options.unlock_max_literal_len,
      rewrite_table_literals = options.unlock_rewrite_table_literals == true,
      rewrite_table_full_decode = options.unlock_rewrite_table_literals == true,
      neutralize_runtime_decoders = options.unlock_rewrite_table_literals == true
    }
    if options.unlock_rewrite_table_literals == true then
      unlock_opts.rewrite_table_printable_only = false
      unlock_opts.rewrite_table_max_literal_len = 4096
    end

    local unlock_source, unlock_meta, unlock_more = Unlock.run(output, unlock_opts)
    unlock_report = unlock_meta or unlock_report
    unlock_extra = unlock_more
    unlock_export_source = unlock_source
    if unlock_source ~= output then
      local compile_ok, compile_err = can_compile(unlock_source)
      unlock_report.compile_ok = compile_ok and true or false
      unlock_report.compile_error = compile_err and tostring(compile_err) or nil
      if compile_ok or options.unlock_allow_unverified == true then
        output = unlock_source
        unlock_report.applied = true
        post_steps[#post_steps + 1] = 'unlock'
      else
        unlock_report.applied = false
      end
    else
      unlock_report.compile_ok = nil
      unlock_report.compile_error = nil
      unlock_report.applied = false
    end
  end

  local vm_trace_before = VMTrace.extract(output, {
    max_sequence = options.vmtrace_max_sequence,
    max_top_states = options.vmtrace_max_top_states,
    max_transitions = options.vmtrace_max_transitions
  })

  local devirtualizer_report = {
    enabled = options.devirtualize ~= false,
    applied = false,
    changed = false,
    constant_folds = 0,
    passes = 0
  }
  if devirtualizer_report.enabled then
    local devirt_source, devirt_meta = Devirtualizer.run(output, {
      max_passes = options.devirt_max_passes
    })
    devirtualizer_report = devirt_meta or devirtualizer_report
    if devirt_source ~= output then
      local compile_ok, compile_err = can_compile(devirt_source)
      devirtualizer_report.compile_ok = compile_ok and true or false
      devirtualizer_report.compile_error = compile_err and tostring(compile_err) or nil
      if compile_ok or options.devirt_allow_unverified == true then
        output = devirt_source
        devirtualizer_report.applied = true
        post_steps[#post_steps + 1] = 'devirtualizer'
      else
        devirtualizer_report.applied = false
      end
    else
      devirtualizer_report.compile_ok = nil
      devirtualizer_report.compile_error = nil
      devirtualizer_report.applied = false
    end
  end

  local vm_trace_after = VMTrace.extract(output, {
    max_sequence = options.vmtrace_max_sequence,
    max_top_states = options.vmtrace_max_top_states,
    max_transitions = options.vmtrace_max_transitions
  })

  local timeout_count = 0
  local fail_count = 0
  local tamper_signals_total = 0
  local tamper_errors_suppressed_total = 0
  for _, attempt in ipairs(layers.attempts or {}) do
    local st = attempt.stats or {}
    tamper_signals_total = tamper_signals_total + (tonumber(st.tamper_signals) or 0)
    tamper_errors_suppressed_total = tamper_errors_suppressed_total + (tonumber(st.tamper_errors_suppressed) or 0)
    if attempt.timeout then
      timeout_count = timeout_count + 1
    end
    if not attempt.ok then
      fail_count = fail_count + 1
    end
  end
  local anti_dumper_suspected = runtime_enabled
    and #layers.attempts > 0
    and layers.captures_total == 0
    and (timeout_count > 0 or has_obf_hint)
  local runtime_stop_reason = nil
  if tamper_signals_total > 0 and (layers.captures_total or 0) == 0 then
    runtime_stop_reason = 'tamper signals observed; runtime likely blocked by anti-tamper/anti-dumper checks'
  elseif anti_dumper_suspected then
    runtime_stop_reason = 'runtime produced no captures; likely anti-dumper loop/checks or VM-only obfuscation'
  end

  local after = analyze_state(output, dialect, {
    enable_compile_validation = trace_enabled,
    enable_parse_validation = trace_parse_enabled,
    max_parse_bytes = options.max_parse_bytes
  })

  local report = {
    type = 'deobf-report',
    generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
    trace_enabled = trace_enabled and true or false,
    before = before,
    after = after,
    changed = output ~= source,
    extracted = selected and selected.kind ~= 'source' and output ~= source or false,
    unlocked = unlock_report.applied and true or false,
    devirtualized = devirtualizer_report.applied and true or false,
    success = selected ~= nil and output ~= '',
    selected = selected and {
      kind = selected.kind,
      origin = selected.origin,
      depth = selected.depth,
      bytes = selected.bytes,
      signature = selected.signature,
      score = selected.score,
      parse_ok = selected.state and selected.state.parse_ok or false,
      compile_ok = selected.state and selected.state.compile_ok or false,
      parse_error = selected.state and selected.state.parse_error or nil,
      compile_error = selected.state and selected.state.compile_error or nil,
      post_process = #post_steps > 0 and table.concat(post_steps, '+') or nil
    } or nil,
    unlock = unlock_report,
    devirtualizer = devirtualizer_report,
    vm_trace = {
      before = vm_trace_before,
      after = vm_trace_after
    },
    runtime = {
      runtime_enabled = runtime_enabled and true or false,
      runtime_loader_hint = has_runtime_hint ~= nil,
      runtime_obfuscation_hint = has_obf_hint and true or false,
      anti_dumper_suspected = anti_dumper_suspected and true or false,
      runtime_skip_reason = runtime_skip_reason,
      runtime_stop_reason = runtime_stop_reason,
      tamper_signals = tamper_signals_total,
      tamper_errors_suppressed = tamper_errors_suppressed_total,
      rescue_profile_used = rescue_used and true or false,
      rescue_attempts = rescue_attempts,
      attempts = #layers.attempts,
      failed_attempts = fail_count,
      timeout_attempts = timeout_count,
      queue_total = layers.queue_total,
      captures_total = layers.captures_total,
      captures_dropped = layers.captures_dropped,
      text_captures_total = layers.text_captures_total or 0,
      text_captures_dropped = layers.text_captures_dropped or 0,
      candidate_count = #layers.candidates,
      candidate_dropped = layers.candidate_dropped,
      static_candidates = #static_candidates
    },
    attempts = layers.attempts
  }

  report.antitamper = {
    output = AntiTamper.scan(output, {
      include_examples = trace_enabled,
      max_examples = 3
    }),
    unlocked = (type(unlock_export_source) == 'string' and unlock_export_source ~= '') and AntiTamper.scan(unlock_export_source, {
      include_examples = false
    }) or nil
  }

  local top_candidates = {}
  local preview_len = tonumber(options.report_preview_len) or 320
  local top_n = tonumber(options.report_top_candidates) or 16
  for i = 1, math.min(#ranked, top_n) do
    local item = ranked[i]
    top_candidates[#top_candidates + 1] = {
      rank = i,
      kind = item.kind,
      origin = item.origin,
      depth = item.depth,
      bytes = item.bytes,
      signature = item.signature,
      score = item.score,
      parse_ok = item.state.parse_ok,
      compile_ok = item.state.compile_ok,
      preview = preview_text(item.text, preview_len)
    }
  end
  report.top_candidates = top_candidates

  local base64_decoded, best_custom_map, base64_binary = collect_base64_decoded_strings(source, dialect, {
    max_items = tonumber(options.dump_max_items) or 4096,
    max_decoded_len = tonumber(options.dump_max_item_bytes) or 600000,
    max_custom_maps = 8
  })

  local extra_outputs = {}

  do
    local dump_strings = {}
    local dump_seen = {}
    local dump_bin = {}

    local function add_dump(value)
      if type(value) ~= 'string' or value == '' then
        return
      end
      if not is_texty_string(value, 0.92) then
        return
      end
      local sig = text_signature(value)
      if dump_seen[sig] then
        return
      end
      dump_seen[sig] = true
      dump_strings[#dump_strings + 1] = value
    end

    if unlock_extra and type(unlock_extra.values_final) == 'table' then
      for i, v in ipairs(unlock_extra.values_final) do
        if is_texty_string(v, 0.92) then
          add_dump(v)
        else
          dump_bin[#dump_bin + 1] = {
            origin = 'string-table',
            index = i,
            encoded = (type(unlock_extra.values_pretty) == 'table' and unlock_extra.values_pretty[i]) or nil,
            decoded = v
          }
        end
      end
    end
    for _, v in ipairs(base64_decoded) do
      add_dump(v)
    end
    for _, e in ipairs(base64_binary or {}) do
      if type(e) == 'table' then
        dump_bin[#dump_bin + 1] = {
          origin = 'base64',
          codec = e.codec,
          encoded = e.encoded,
          decoded = e.decoded
        }
      end
    end

    extra_outputs[#extra_outputs + 1] = {
      suffix = '.dump.lua',
      content = build_decoded_string_dump(dump_strings, 'decoded strings', {})
    }

    if #dump_bin > 0 then
      extra_outputs[#extra_outputs + 1] = {
        suffix = '.dump.bin.lua',
        content = build_binary_string_dump(dump_bin, 'binary decoded strings', { max_hex_bytes = 256 })
      }
    end

    if unlock_extra and (type(unlock_extra.values_pretty) == 'table' or type(unlock_extra.values_final) == 'table') then
      extra_outputs[#extra_outputs + 1] = {
        suffix = '.dump.map.lua',
        content = build_string_table_map_dump(unlock_extra)
      }
    end
  end

  if trace_enabled then
    -- Export runtime-captured chunks for offline inspection.
    do
      local runtime_candidates = {}
      for _, item in ipairs(layers.candidates or {}) do
        if type(item) == 'table'
          and item.origin ~= 'static'
          and item.kind ~= 'source'
          and item.is_probable_text then
          runtime_candidates[#runtime_candidates + 1] = item
        end
      end

      local best = nil
      if #runtime_candidates > 0 then
        best = rank_candidates(source, runtime_candidates, dialect, { prefer_extracted = true })
      end

      local best_text = type(best) == 'table' and best.text or nil
      if type(best_text) ~= 'string' or best_text == '' then
        best_text = '-- deobf: no runtime chunk captures (anti-dumper or VM-only obfuscation likely)\n'
          .. '-- deobf: see *.deobflol.dump.lua for captured runtime text strings\n'
      end

      extra_outputs[#extra_outputs + 1] = {
        suffix = '.deobflol.lua',
        content = best_text
      }

      local dump_file = build_trace_dump_file(layers, options)
      if type(dump_file) == 'string' and dump_file ~= '' then
        extra_outputs[#extra_outputs + 1] = {
          suffix = '.deobflol.dump.lua',
          content = dump_file
        }
      end
    end

    local trace_candidates = {}
    local trace_limit = tonumber(options.trace_candidate_limit) or 40
    for i = 1, math.min(#ranked, trace_limit) do
      local item = ranked[i]
      trace_candidates[#trace_candidates + 1] = {
        rank = i,
        kind = item.kind,
        depth = item.depth,
        bytes = item.bytes,
        signature = item.signature,
        parse_ok = item.state.parse_ok,
        compile_ok = item.state.compile_ok,
        preview = preview_text(item.text, preview_len)
      }
    end
    report.trace_data = {
      candidates = trace_candidates
    }
  end

  local meta = {
    report_data = report,
    report_suffix = '.deobf.json',
    output_suffix = '.deobf.unlocked.folded.lua'
  }

  if type(unlock_export_source) == 'string' and unlock_export_source ~= '' then
    if unlock_export_source ~= output or unlock_report.changed then
      local unlocked_norm, unlocked_norm_n = normalize_short_string_literals(unlock_export_source, dialect, {
        max_literal_len = options.normalize_max_literal_len
      })
      if unlocked_norm_n > 0 and type(unlocked_norm) == 'string' and unlocked_norm ~= '' then
        unlock_export_source = unlocked_norm
        report.unlocked_string_literals_normalized = unlocked_norm_n
      end

      extra_outputs[#extra_outputs + 1] = {
        suffix = '.deobf.unlocked.lua',
        content = unlock_export_source
      }

      local unlock_folded, unlock_fold_meta = Devirtualizer.run(unlock_export_source, {
        max_passes = tonumber(options.readable_devirt_max_passes) or 8
      })
      if type(unlock_folded) == 'string' and unlock_folded ~= '' and unlock_folded ~= unlock_export_source then
        extra_outputs[#extra_outputs + 1] = {
          suffix = '.deobf.unlocked.folded.lua',
          content = unlock_folded
        }
        report.unlocked_folded = unlock_fold_meta
      end
    end
  end

  local readable_enabled = options.readable_output ~= false
  if readable_enabled and type(output) == 'string' and output ~= '' then
    local readable = output

    -- Readability output is allowed to be non-semantic (e.g. rewriting the decoded string table).
    local readable_unlock, readable_unlock_meta = Unlock.run(readable, {
      analysis_source = source,
      max_replacements = options.unlock_max_replacements,
      max_literal_len = options.unlock_max_literal_len,
      rewrite_table_literals = true,
      rewrite_table_full_decode = true,
      neutralize_runtime_decoders = true,
      rewrite_table_printable_only = false,
      rewrite_table_max_literal_len = 4096
    })
    if type(readable_unlock) == 'string' and readable_unlock ~= '' then
      readable = readable_unlock
      report.readable_unlock = readable_unlock_meta
    end

    local readable_b64, readable_b64_n = rewrite_base64_string_literals(readable, dialect, best_custom_map, {
      max_literal_len = 4096
    })
    if readable_b64_n > 0 and type(readable_b64) == 'string' and readable_b64 ~= '' then
      readable = readable_b64
      report.readable_base64_literal_rewrites = readable_b64_n
    end

    local readable_norm, readable_norm_n = normalize_short_string_literals(readable, dialect, {
      max_literal_len = options.normalize_max_literal_len
    })
    if readable_norm_n > 0 and type(readable_norm) == 'string' and readable_norm ~= '' then
      readable = readable_norm
      report.readable_string_literals_normalized = readable_norm_n
    end

    local fmt_ok, fmt_out = pcall(Formatter.format, readable, { dialect = dialect })
    if fmt_ok and type(fmt_out) == 'string' and fmt_out ~= '' then
      readable = fmt_out
    end

    local folded, fold_meta = Devirtualizer.run(readable, {
      max_passes = tonumber(options.readable_devirt_max_passes) or 8
    })
    if type(folded) == 'string' and folded ~= '' then
      readable = folded
      report.readable = {
        enabled = true,
        formatter_ok = fmt_ok and true or false,
        devirtualizer = fold_meta,
        bytes_before = #output,
        bytes_after = #readable
      }
      local compile_ok, compile_err = can_compile(readable)
      report.readable.compile_ok = compile_ok and true or false
      report.readable.compile_error = compile_err and tostring(compile_err) or nil
      extra_outputs[#extra_outputs + 1] = {
        suffix = '.deobf.readable.lua',
        content = readable
      }
    end
  end

  if #extra_outputs > 0 then
    meta.extra_outputs = extra_outputs
  end

  return output, { all_locals = {} }, meta
end

return Deobf
