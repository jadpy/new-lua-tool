local Lexer = require('src.lexer')
local Parser = require('src.parser')
local LexerFull = require('src.lexer_full')
local Formatter = require('src.formatter')
local CodeFixAI = require('src.codefix_ai')

local CodeFix = {}

local read_long_open
local read_long_close

local merge_pairs = {
  ['--'] = true, ['=='] = true, ['~='] = true, ['<='] = true, ['>='] = true,
  ['<<'] = true, ['>>'] = true, ['//'] = true, ['..'] = true, ['...'] = true,
  ['::'] = true, ['+='] = true, ['-='] = true, ['*='] = true, ['/='] = true,
  ['%='] = true, ['^='] = true, ['&='] = true, ['|='] = true, ['..='] = true,
  ['->'] = true, ['=>'] = true, [':='] = true, ['&&'] = true, ['||'] = true
}

local stmt_start_keywords = {
  ['local'] = true, ['function'] = true, ['if'] = true, ['while'] = true,
  ['repeat'] = true, ['for'] = true, ['do'] = true, ['break'] = true,
  ['return'] = true, ['goto'] = true, ['continue'] = true
}

local function is_wordlike(tok)
  return tok.type == 'keyword' or tok.type == 'ident' or tok.type == 'number' or tok.type == 'string' or tok.type == 'long_string'
end

local function comment_has_newline(tok)
  if not tok or tok.type ~= 'comment' then return false end
  return tok.value:find('\n', 1, true) ~= nil or tok.value:find('\r', 1, true) ~= nil
end

local function needs_space(prev, nxt)
  if not prev or not nxt then return false end
  if nxt.type == 'symbol' then
    local nv = nxt.value
    if nv == ')' or nv == ']' or nv == ',' or nv == ';' then
      return false
    end
  end
  if is_wordlike(prev) and is_wordlike(nxt) then return true end
  if prev.type == 'number' and nxt.type == 'symbol' and nxt.value:sub(1, 1) == '.' then return true end
  if prev.type == 'symbol' and nxt.type == 'symbol' then
    if merge_pairs[prev.value .. nxt.value] then return true end
    if prev.value:sub(-1) == '.' and nxt.value:sub(1, 1) == '.' then return true end
  end
  if prev.type == 'symbol' and prev.value == '[' and (nxt.value == '[' or nxt.value:sub(1, 1) == '=') then return true end
  if prev.type == 'symbol' and prev.value == ':' and nxt.value == ':' then return true end
  return false
end

local function can_parse(source, dialect)
  local ok, err = pcall(function()
    local tokens = Lexer.new(source, { dialect = dialect }):tokenize()
    local parser = Parser.new(tokens, { dialect = dialect })
    parser:parse()
  end)
  if ok then
    return true, nil
  end
  return false, err
end

local function can_compile_load(source)
  local loader = load or loadstring
  if type(loader) ~= 'function' then
    return true, nil
  end
  local fn, err = loader(source)
  if fn then
    return true, nil
  end
  return false, err
end

local function should_use_load_compile(dialect)
  local key = tostring(dialect or 'auto'):lower()
  return key == 'lua51'
    or key == 'lua52'
    or key == 'lua53'
    or key == 'lua54'
    or key == 'lua55'
end

local function string_sanity_check(source)
  local n = #source
  local i = 1
  local line = 1
  local col = 1

  local function step()
    local c = source:sub(i, i)
    i = i + 1
    if c == '\n' then
      line = line + 1
      col = 1
    else
      col = col + 1
    end
    return c
  end

  local function consume_to(end_i)
    while i <= n and i <= end_i do
      step()
    end
  end

  while i <= n do
    local ch = source:sub(i, i)
    local ch2 = source:sub(i, i + 1)

    if ch2 == '--' then
      step()
      step()

      local eq_count, open_end = nil, nil
      if read_long_open then
        eq_count, open_end = read_long_open(source, i)
      end
      if eq_count ~= nil and open_end then
        consume_to(open_end)
        local closed = false
        while i <= n do
          local close_end = read_long_close and read_long_close(source, i, eq_count) or nil
          if close_end then
            consume_to(close_end)
            closed = true
            break
          end
          step()
        end
        if not closed then
          return false, 'unclosed-long-comment', { line = line, col = col, message = 'unclosed long comment' }
        end
      else
        while i <= n do
          local c = step()
          if c == '\n' then
            break
          end
        end
      end
    elseif ch == '"' or ch == "'" then
      local quote = ch
      step()
      local closed = false
      while i <= n do
        local c = source:sub(i, i)
        if c == '\n' then
          return false, 'newline-in-short-string', { line = line, col = col, message = 'newline in short string' }
        end
        c = step()
        if c == '\\' then
          if i <= n then
            step()
          end
        elseif c == quote then
          closed = true
          break
        end
      end
      if not closed then
        return false, 'unclosed-short-string', { line = line, col = col, message = 'unclosed short string' }
      end
    else
      local eq_count, open_end = nil, nil
      if ch == '[' and read_long_open then
        eq_count, open_end = read_long_open(source, i)
      end
      if eq_count ~= nil and open_end then
        consume_to(open_end)
        local closed = false
        while i <= n do
          local close_end = read_long_close and read_long_close(source, i, eq_count) or nil
          if close_end then
            consume_to(close_end)
            closed = true
            break
          end
          step()
        end
        if not closed then
          return false, 'unclosed-long-string', { line = line, col = col, message = 'unclosed long string' }
        end
      else
        step()
      end
    end
  end

  return true, nil, nil
end

local function parse_error_location(err)
  if not err then
    return nil
  end
  local s = tostring(err)
  if s == '' then
    return nil
  end

  local line, col = s:match('line%s+(%d+)%s+col%s+(%d+)')
  if line then
    return {
      line = tonumber(line),
      col = tonumber(col),
      message = s
    }
  end

  line = s:match('at line%s+(%d+)')
  if line then
    return {
      line = tonumber(line),
      col = nil,
      message = s
    }
  end

  -- Lua load/loadstring errors typically look like:
  --   [string "..."]:12: syntax error near <eof>
  -- or:
  --   chunkname:12: ...
  line = s:match(':(%d+):')
  if line then
    return {
      line = tonumber(line),
      col = nil,
      message = s
    }
  end

  return {
    line = nil,
    col = nil,
    message = s
  }
end

local function analyze_state(source, dialect)
  local parse_ok, parse_err = can_parse(source, dialect)

  local wants_load = should_use_load_compile(dialect)
  local string_ok = true
  local string_err = nil
  local string_loc = nil
  if (not wants_load) or (not parse_ok) then
    string_ok, string_err, string_loc = string_sanity_check(source)
  end

  local compile_ok = false
  local compile_err = nil
  local compile_loc = nil

  if parse_ok then
    if not string_ok then
      compile_ok = false
      compile_err = (string_loc and string_loc.message) or string_err
      compile_loc = string_loc
    elseif wants_load then
      compile_ok, compile_err = can_compile_load(source)
    else
      compile_ok = true
    end
  end
  local parse_loc = parse_error_location(parse_err)
  if not compile_loc then
    compile_loc = parse_error_location(compile_err)
  end
  return {
    parse_ok = parse_ok,
    compile_ok = compile_ok,
    parse_error = parse_err and tostring(parse_err) or nil,
    compile_error = compile_err and tostring(compile_err) or nil,
    parse_loc = parse_loc,
    compile_loc = compile_loc,
    string_ok = string_ok,
    string_error = string_err and tostring(string_err) or nil,
    string_loc = string_loc
  }
end

local function tokenize_full(source, dialect)
  local ok, tokens_or_err = pcall(function()
    return LexerFull.new(source, { dialect = dialect }):tokenize()
  end)
  if not ok then
    return nil, tokens_or_err
  end
  return tokens_or_err, nil
end

local function rebuild_source(tokens)
  local out = {}
  local prev = nil
  for _, tok in ipairs(tokens) do
    if tok.type == 'newline' then
      out[#out + 1] = '\n'
      prev = nil
    elseif tok.type == 'comment' then
      out[#out + 1] = tok.value
      if comment_has_newline(tok) then
        prev = nil
      end
    else
      if prev and needs_space(prev, tok) then
        out[#out + 1] = ' '
      end
      out[#out + 1] = tok.value
      prev = tok
    end
  end
  return table.concat(out)
end

local function can_end_table_field(tok)
  if not tok then return false end
  if tok.type == 'ident' or tok.type == 'number' or tok.type == 'string' or tok.type == 'long_string' then
    return true
  end
  if tok.type == 'keyword' then
    return tok.value == 'nil' or tok.value == 'true' or tok.value == 'false' or tok.value == 'end'
  end
  if tok.type == 'symbol' then
    return tok.value == ')' or tok.value == ']' or tok.value == '}' or tok.value == '...'
  end
  return false
end

local function can_start_table_field(tok)
  if not tok then return false end
  if tok.type == 'ident' or tok.type == 'number' or tok.type == 'string' or tok.type == 'long_string' then
    return true
  end
  if tok.type == 'keyword' then
    return tok.value == 'function' or tok.value == 'nil' or tok.value == 'true' or tok.value == 'false'
  end
  if tok.type == 'symbol' then
    return tok.value == '{' or tok.value == '[' or tok.value == '('
  end
  return false
end

local function fix_missing_table_commas(source, dialect)
  local tokens, err = tokenize_full(source, dialect)
  if not tokens then
    return nil, 0, err
  end

  local out = {}
  local fixes = 0
  local brace_depth = 0
  local paren_depth = 0
  local bracket_depth = 0
  local block_depth = 0
  local table_stack = {}
  local pending_break = false
  local prev_sig = nil

  local function in_top_table()
    local top = table_stack[#table_stack]
    if not top then return false end
    return brace_depth == top.brace_level
      and paren_depth == top.paren_level
      and bracket_depth == top.bracket_level
      and block_depth == top.block_level
  end

  local function peek_next_sig(idx)
    local j = idx + 1
    while j <= #tokens do
      local t = tokens[j]
      if t.type ~= 'newline' and t.type ~= 'comment' then
        return t, j
      end
      j = j + 1
    end
    return nil, nil
  end

  for i, tok in ipairs(tokens) do
    if tok.type == 'newline' then
      if in_top_table() then
        pending_break = true
      end
      out[#out + 1] = tok
    elseif tok.type == 'comment' then
      if in_top_table() and comment_has_newline(tok) then
        pending_break = true
      end
      out[#out + 1] = tok
    else
      local next_sig = nil
      local inline_named_field = false
      local inline_index_field = false
      if in_top_table() then
        next_sig = peek_next_sig(i)
        inline_named_field = tok.type == 'ident' and next_sig and next_sig.type == 'symbol' and next_sig.value == '='
        inline_index_field = tok.type == 'symbol' and tok.value == '['
      end

      if pending_break and in_top_table() and prev_sig and can_end_table_field(prev_sig) and can_start_table_field(tok) then
        out[#out + 1] = { type = 'symbol', value = ',', line = tok.line, col = tok.col }
        fixes = fixes + 1
        pending_break = false
        prev_sig = { type = 'symbol', value = ',' }
      elseif in_top_table() and prev_sig and can_end_table_field(prev_sig) and (inline_named_field or inline_index_field) then
        out[#out + 1] = { type = 'symbol', value = ',', line = tok.line, col = tok.col }
        fixes = fixes + 1
        prev_sig = { type = 'symbol', value = ',' }
      end

      out[#out + 1] = tok

      if tok.type == 'symbol' then
        if tok.value == '(' then
          paren_depth = paren_depth + 1
        elseif tok.value == ')' and paren_depth > 0 then
          paren_depth = paren_depth - 1
        elseif tok.value == '[' then
          bracket_depth = bracket_depth + 1
        elseif tok.value == ']' and bracket_depth > 0 then
          bracket_depth = bracket_depth - 1
        elseif tok.value == '{' then
          brace_depth = brace_depth + 1
          table_stack[#table_stack + 1] = {
            brace_level = brace_depth,
            paren_level = paren_depth,
            bracket_level = bracket_depth,
            block_level = block_depth
          }
        elseif tok.value == '}' then
          local top = table_stack[#table_stack]
          if top and brace_depth == top.brace_level then
            table.remove(table_stack)
          end
          if brace_depth > 0 then
            brace_depth = brace_depth - 1
          end
        elseif tok.value == ',' or tok.value == ';' then
          pending_break = false
        end
      elseif tok.type == 'keyword' then
        if tok.value == 'function' or tok.value == 'then' or tok.value == 'do' or tok.value == 'repeat' then
          block_depth = block_depth + 1
        elseif tok.value == 'end' or tok.value == 'until' then
          if block_depth > 0 then
            block_depth = block_depth - 1
          end
        end
      end

      prev_sig = tok
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end
  return rebuild_source(out), fixes, nil
end

local function can_end_statement(tok)
  if not tok then return false end
  if tok.type == 'ident' or tok.type == 'number' or tok.type == 'string' or tok.type == 'long_string' then
    return true
  end
  if tok.type == 'keyword' then
    return tok.value == 'end' or tok.value == 'until' or tok.value == 'break' or tok.value == 'return'
      or tok.value == 'continue' or tok.value == 'true' or tok.value == 'false' or tok.value == 'nil'
  end
  if tok.type == 'symbol' then
    return tok.value == ')' or tok.value == ']' or tok.value == '}'
  end
  return false
end

local function can_start_statement(tok)
  if not tok then return false end
  if tok.type == 'keyword' and stmt_start_keywords[tok.value] then
    return true
  end
  if tok.type == 'ident' then
    return true
  end
  if tok.type == 'symbol' and tok.value == '::' then
    return true
  end
  return false
end

local function can_end_expression(tok)
  if not tok then return false end
  if tok.type == 'ident' or tok.type == 'number' or tok.type == 'string' or tok.type == 'long_string' then
    return true
  end
  if tok.type == 'keyword' then
    return tok.value == 'nil' or tok.value == 'true' or tok.value == 'false' or tok.value == 'end'
  end
  if tok.type == 'symbol' then
    return tok.value == ')' or tok.value == ']' or tok.value == '}' or tok.value == '...'
  end
  return false
end

local unary_prefix_symbols = {
  ['-'] = true, ['+'] = true, ['#'] = true, ['~'] = true
}

local function can_start_expression(tok)
  if not tok then return false end
  if tok.type == 'ident' or tok.type == 'number' or tok.type == 'string' or tok.type == 'long_string' then
    return true
  end
  if tok.type == 'keyword' then
    return tok.value == 'nil' or tok.value == 'true' or tok.value == 'false'
      or tok.value == 'function' or tok.value == 'not'
  end
  if tok.type == 'symbol' then
    return tok.value == '{' or tok.value == '[' or tok.value == '('
      or tok.value == '...'
      or unary_prefix_symbols[tok.value] == true
  end
  return false
end

local function fix_statement_separators(source, dialect)
  local tokens, err = tokenize_full(source, dialect)
  if not tokens then
    return nil, 0, err
  end

  local out = {}
  local fixes = 0
  local prev = nil
  local paren_depth = 0
  local bracket_depth = 0
  local brace_depth = 0
  local pending_break = false

  local function in_expression_context()
    return paren_depth > 0 or bracket_depth > 0 or brace_depth > 0
  end

  for _, tok in ipairs(tokens) do
    if tok.type == 'newline' then
      pending_break = true
      out[#out + 1] = tok
    elseif tok.type == 'comment' then
      if comment_has_newline(tok) then
        pending_break = true
      end
      out[#out + 1] = tok
    else
      if (not pending_break) and (not in_expression_context()) and prev and can_end_statement(prev) and can_start_statement(tok) then
        local prev_is_separator = prev.type == 'symbol' and (prev.value == ';' or prev.value == ',' or prev.value == '::')
        if not prev_is_separator then
          out[#out + 1] = { type = 'symbol', value = ';', line = tok.line, col = tok.col }
          fixes = fixes + 1
          prev = { type = 'symbol', value = ';' }
        end
      end

      out[#out + 1] = tok
      if tok.type == 'symbol' then
        if tok.value == '(' then
          paren_depth = paren_depth + 1
        elseif tok.value == ')' and paren_depth > 0 then
          paren_depth = paren_depth - 1
        elseif tok.value == '[' then
          bracket_depth = bracket_depth + 1
        elseif tok.value == ']' and bracket_depth > 0 then
          bracket_depth = bracket_depth - 1
        elseif tok.value == '{' then
          brace_depth = brace_depth + 1
        elseif tok.value == '}' and brace_depth > 0 then
          brace_depth = brace_depth - 1
        end
      end
      prev = tok
      pending_break = false
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end
  return rebuild_source(out), fixes, nil
end

local function fix_missing_call_commas(source, dialect)
  local tokens, err = tokenize_full(source, dialect)
  if not tokens then
    return nil, 0, err
  end

  local out = {}
  local fixes = 0
  local paren_depth = 0
  local brace_depth = 0
  local bracket_depth = 0
  local prev_sig = nil
  local pending_break = false
  local paren_stack = {}

  local function current_call_args_scope()
    local top = paren_stack[#paren_stack]
    if not top or not top.is_call_args then return false end
    return paren_depth == top.paren_level and brace_depth == top.brace_level and bracket_depth == top.bracket_level
  end

  local function is_call_args_start(prev_tok)
    if not prev_tok then return false end
    if prev_tok.type == 'ident' or prev_tok.type == 'string' or prev_tok.type == 'long_string' then
      return true
    end
    if prev_tok.type == 'symbol' then
      return prev_tok.value == ')' or prev_tok.value == ']' or prev_tok.value == '}'
    end
    if prev_tok.type == 'keyword' then
      return prev_tok.value == 'end'
    end
    return false
  end

  for _, tok in ipairs(tokens) do
    if tok.type == 'newline' then
      if current_call_args_scope() then
        pending_break = true
      end
      out[#out + 1] = tok
    elseif tok.type == 'comment' then
      if current_call_args_scope() and comment_has_newline(tok) then
        pending_break = true
      end
      out[#out + 1] = tok
    else
      if pending_break and current_call_args_scope() and prev_sig and can_end_expression(prev_sig) and can_start_expression(tok) then
        out[#out + 1] = { type = 'symbol', value = ',', line = tok.line, col = tok.col }
        fixes = fixes + 1
        prev_sig = { type = 'symbol', value = ',' }
        pending_break = false
      end

      out[#out + 1] = tok

      if tok.type == 'symbol' then
        if tok.value == '(' then
          paren_depth = paren_depth + 1
          paren_stack[#paren_stack + 1] = {
            paren_level = paren_depth,
            brace_level = brace_depth,
            bracket_level = bracket_depth,
            is_call_args = is_call_args_start(prev_sig)
          }
          pending_break = false
        elseif tok.value == ')' then
          local top = paren_stack[#paren_stack]
          if top and paren_depth == top.paren_level then
            table.remove(paren_stack)
          end
          if paren_depth > 0 then
            paren_depth = paren_depth - 1
          end
          pending_break = false
        elseif tok.value == '{' then
          brace_depth = brace_depth + 1
        elseif tok.value == '}' and brace_depth > 0 then
          brace_depth = brace_depth - 1
        elseif tok.value == '[' then
          bracket_depth = bracket_depth + 1
        elseif tok.value == ']' and bracket_depth > 0 then
          bracket_depth = bracket_depth - 1
        elseif tok.value == ',' or tok.value == ';' then
          pending_break = false
        end
      end

      prev_sig = tok
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end
  return rebuild_source(out), fixes, nil
end

local function fix_missing_control_keywords(source, dialect)
  local tokens, err = tokenize_full(source, dialect)
  if not tokens then
    return nil, 0, err
  end

  local need_map = {
    ['if'] = 'then',
    ['elseif'] = 'then',
    ['while'] = 'do',
    ['for'] = 'do'
  }

  local insert_before = {}
  local fixes = 0

  for i = 1, #tokens do
    local tok = tokens[i]
    if tok.type == 'keyword' then
      local needed = need_map[tok.value]
      if needed then
        local paren_depth = 0
        local bracket_depth = 0
        local brace_depth = 0
        local prev_sig = nil
        local found_needed = false
        local insert_at = nil
        local j = i + 1

        while j <= #tokens do
          local t = tokens[j]
          if t.type == 'newline' then
            if paren_depth == 0 and bracket_depth == 0 and brace_depth == 0 and prev_sig and can_end_expression(prev_sig) then
              insert_at = j
              break
            end
          elseif t.type == 'comment' then
            if paren_depth == 0 and bracket_depth == 0 and brace_depth == 0 and comment_has_newline(t) and prev_sig and can_end_expression(prev_sig) then
              insert_at = j
              break
            end
          else
            if paren_depth == 0 and bracket_depth == 0 and brace_depth == 0 then
              if t.type == 'keyword' and t.value == needed then
                found_needed = true
                break
              end
              if prev_sig and can_end_expression(prev_sig) and can_start_statement(t) then
                insert_at = j
                break
              end
              if t.type == 'keyword' and (t.value == 'end' or t.value == 'elseif' or t.value == 'else' or t.value == 'until') then
                insert_at = j
                break
              end
              if t.type == 'symbol' and t.value == ';' then
                insert_at = j
                break
              end
            end

            if t.type == 'symbol' then
              if t.value == '(' then
                paren_depth = paren_depth + 1
              elseif t.value == ')' and paren_depth > 0 then
                paren_depth = paren_depth - 1
              elseif t.value == '[' then
                bracket_depth = bracket_depth + 1
              elseif t.value == ']' and bracket_depth > 0 then
                bracket_depth = bracket_depth - 1
              elseif t.value == '{' then
                brace_depth = brace_depth + 1
              elseif t.value == '}' and brace_depth > 0 then
                brace_depth = brace_depth - 1
              end
            end
            prev_sig = t
          end
          j = j + 1
        end

        if not found_needed and not insert_at and prev_sig and can_end_expression(prev_sig) then
          insert_at = #tokens + 1
        end

        if not found_needed and insert_at then
          insert_before[insert_at] = insert_before[insert_at] or {}
          insert_before[insert_at][#insert_before[insert_at] + 1] = {
            type = 'keyword',
            value = needed,
            line = tok.line,
            col = tok.col
          }
          fixes = fixes + 1
        end
      end
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end

  local out = {}
  for i = 1, #tokens do
    local pending = insert_before[i]
    if pending then
      for _, t in ipairs(pending) do
        out[#out + 1] = t
      end
    end
    out[#out + 1] = tokens[i]
  end
  if insert_before[#tokens + 1] then
    for _, t in ipairs(insert_before[#tokens + 1]) do
      out[#out + 1] = t
    end
  end
  return rebuild_source(out), fixes, nil
end

local function append_missing_closers(source, dialect)
  local function expected_at_eof(err)
    if not err then
      return nil
    end
    local msg = tostring(err)
    local expected, got = msg:match('Expected%s+([%w_]+)%s+but got%s+([%w_]+)')
    if got == 'EOF' then
      return expected
    end
    return nil
  end

  local append_map = {
    RPAREN = ')',
    RBRACKET = ']',
    RBRACE = '}',
    END = 'end',
    UNTIL = 'until true'
  }

  local working = source
  local fixes = 0
  local safety = 32
  while safety > 0 do
    local ok, err = can_parse(working, dialect)
    if ok then
      break
    end
    local expected = expected_at_eof(err)
    local piece = expected and append_map[expected] or nil
    if not piece then
      break
    end
    working = working .. '\n' .. piece
    fixes = fixes + 1
    safety = safety - 1
  end
  if fixes > 0 then
    return working, fixes, nil
  end

  local tokens, err = tokenize_full(source, dialect)
  if not tokens then
    return nil, 0, err
  end

  local sym_stack = {}
  local function push_sym(close_char)
    sym_stack[#sym_stack + 1] = close_char
  end
  local function pop_sym(close_char)
    if sym_stack[#sym_stack] == close_char then
      table.remove(sym_stack)
    end
  end

  for _, tok in ipairs(tokens) do
    if tok.type == 'symbol' then
      if tok.value == '(' then push_sym(')') end
      if tok.value == '[' then push_sym(']') end
      if tok.value == '{' then push_sym('}') end
      if tok.value == ')' then pop_sym(')') end
      if tok.value == ']' then pop_sym(']') end
      if tok.value == '}' then pop_sym('}') end
    end
  end

  if #sym_stack == 0 then
    return nil, 0, nil
  end

  local suffix = {}
  while #sym_stack > 0 do
    suffix[#suffix + 1] = table.remove(sym_stack)
  end
  return source .. '\n' .. table.concat(suffix, '\n'), #suffix, nil
end

local function is_hex(ch)
  return ch ~= '' and ch:match('^[0-9A-Fa-f]$') ~= nil
end

local function is_digit(ch)
  return ch ~= '' and ch:match('^%d$') ~= nil
end

local function is_space(ch)
  return ch ~= '' and ch:match('^%s$') ~= nil
end

local valid_simple_escapes = {
  ['a'] = true, ['b'] = true, ['f'] = true, ['n'] = true, ['r'] = true,
  ['t'] = true, ['v'] = true, ['\\'] = true, ['"'] = true, ["'"] = true
}

read_long_open = function(source, i)
  if source:sub(i, i) ~= '[' then
    return nil
  end
  local j = i + 1
  while source:sub(j, j) == '=' do
    j = j + 1
  end
  if source:sub(j, j) == '[' then
    return j - i - 1, j
  end
  return nil
end

read_long_close = function(source, i, eq_count)
  if source:sub(i, i) ~= ']' then
    return nil
  end
  local j = i + 1
  local matched = 0
  while matched < eq_count and source:sub(j, j) == '=' do
    matched = matched + 1
    j = j + 1
  end
  if matched == eq_count and source:sub(j, j) == ']' then
    return j
  end
  return nil
end

local statement_start_token_types = {
  ['LOCAL'] = true,
  ['FUNCTION'] = true,
  ['IF'] = true,
  ['ELSEIF'] = true,
  ['ELSE'] = true,
  ['WHILE'] = true,
  ['REPEAT'] = true,
  ['FOR'] = true,
  ['DO'] = true,
  ['END'] = true,
  ['UNTIL'] = true,
  ['RETURN'] = true,
  ['BREAK'] = true,
  ['GOTO'] = true,
  ['CONTINUE'] = true,
  ['TYPE'] = true,
  ['EXPORT'] = true
}

local likely_call_heads = {
  print = true, warn = true, error = true, assert = true, require = true,
  tostring = true, tonumber = true, type = true, select = true,
  pcall = true, xpcall = true,
  pairs = true, ipairs = true, next = true,
  setmetatable = true, getmetatable = true, rawget = true, rawset = true
}

local function infer_statement_start(source, idx, dialect)
  local n = #source
  local i = idx
  while i <= n do
    local ch = source:sub(i, i)
    if ch == ' ' or ch == '\t' then
      i = i + 1
    else
      break
    end
  end
  if i > n then
    return false
  end

  if source:sub(i, i + 1) == '--' then
    return false
  end

  local eol = source:find('[\r\n]', i)
  local line = eol and source:sub(i, eol - 1) or source:sub(i)
  if line == '' then
    return false
  end

  local ok, tokens = pcall(function()
    return Lexer.new(line, { dialect = dialect }):tokenize()
  end)
  if not ok or type(tokens) ~= 'table' or #tokens == 0 then
    return false
  end

  local t1 = tokens[1]
  if not t1 or not t1.type then
    return false
  end

  if t1.type == 'SEMICOLON' then
    return true
  end
  if t1.type == 'DBLCOLON' then
    return true
  end
  if statement_start_token_types[t1.type] then
    return true
  end
  if t1.type == 'LPAREN' then
    return true
  end

  if t1.type ~= 'IDENT' then
    return false
  end

  local t2 = tokens[2]
  if not t2 or not t2.type then
    return false
  end

  if t2.type == 'ASSIGN' or t2.type == 'COMMA' then
    return true
  end
  if t2.type == 'LPAREN' or t2.type == 'DOT' or t2.type == 'COLON' or t2.type == 'LBRACKET' then
    return true
  end
  if t2.type == 'STRING' or t2.type == 'LBRACE' then
    return true
  end

  if (t2.type == 'IDENT' or t2.type == 'NUMBER') and likely_call_heads[t1.value] then
    return true
  end

  return false
end

local function fix_invalid_string_escapes(source, dialect)
  local out = {}
  local fixes = 0
  local n = #source
  local i = 1

  while i <= n do
    local ch = source:sub(i, i)
    local ch2 = source:sub(i, i + 1)

    if ch2 == '--' then
      local eq_count, long_end = read_long_open(source, i + 2)
      if eq_count ~= nil then
        table.insert(out, source:sub(i, long_end))
        i = long_end + 1
        while i <= n do
          local close_end = read_long_close(source, i, eq_count)
          if close_end then
            table.insert(out, source:sub(i, close_end))
            i = close_end + 1
            break
          else
            table.insert(out, source:sub(i, i))
            i = i + 1
          end
        end
      else
        while i <= n do
          local c = source:sub(i, i)
          table.insert(out, c)
          i = i + 1
          if c == '\n' then
            break
          end
        end
      end
    elseif ch == "'" or ch == '"' then
      local quote = ch
      local closed = false
      table.insert(out, quote)
      i = i + 1
      while i <= n do
        local c = source:sub(i, i)
        if c == quote then
          table.insert(out, c)
          i = i + 1
          closed = true
          break
        elseif c == '\n' then
          local next_idx = i + 1
          if infer_statement_start(source, next_idx, dialect) then
            table.insert(out, quote)
            table.insert(out, '\n')
            fixes = fixes + 1
            i = next_idx
            closed = true
            break
          else
            table.insert(out, '\\n')
            fixes = fixes + 1
            i = i + 1
          end
        elseif c == '\r' and source:sub(i + 1, i + 1) == '\n' then
          local next_idx = i + 2
          if infer_statement_start(source, next_idx, dialect) then
            table.insert(out, quote)
            table.insert(out, '\n')
            fixes = fixes + 1
            i = next_idx
            closed = true
            break
          else
            table.insert(out, '\\n')
            fixes = fixes + 1
            i = i + 2
          end
        elseif c == '\r' then
          local next_idx = i + 1
          if infer_statement_start(source, next_idx, dialect) then
            table.insert(out, quote)
            table.insert(out, '\n')
            fixes = fixes + 1
            i = next_idx
            closed = true
            break
          else
            table.insert(out, '\\n')
            fixes = fixes + 1
            i = i + 1
          end
        elseif c == '\\' then
          local nxt = source:sub(i + 1, i + 1)
          local nxt2 = source:sub(i + 2, i + 2)
          if nxt == '' then
            table.insert(out, '\\\\')
            fixes = fixes + 1
            i = i + 1
          elseif nxt == '\n' then
            table.insert(out, '\\n')
            fixes = fixes + 1
            i = i + 2
          elseif nxt == '\r' and nxt2 == '\n' then
            table.insert(out, '\\n')
            fixes = fixes + 1
            i = i + 3
          elseif nxt == '\r' then
            table.insert(out, '\\n')
            fixes = fixes + 1
            i = i + 2
          elseif valid_simple_escapes[nxt] then
            table.insert(out, '\\' .. nxt)
            i = i + 2
          elseif nxt == 'x' then
            table.insert(out, '\\x')
            i = i + 2
            local copied = 0
            while copied < 2 and is_hex(source:sub(i, i)) do
              table.insert(out, source:sub(i, i))
              i = i + 1
              copied = copied + 1
            end
          elseif nxt == 'u' and source:sub(i + 2, i + 2) == '{' then
            table.insert(out, '\\u{')
            i = i + 3
            while i <= n and source:sub(i, i) ~= '}' do
              table.insert(out, source:sub(i, i))
              i = i + 1
            end
            if source:sub(i, i) == '}' then
              table.insert(out, '}')
              i = i + 1
            end
          elseif nxt == 'z' then
            table.insert(out, '\\z')
            i = i + 2
            while i <= n and is_space(source:sub(i, i)) do
              table.insert(out, source:sub(i, i))
              i = i + 1
            end
          elseif is_digit(nxt) then
            table.insert(out, '\\' .. nxt)
            i = i + 2
            local copied = 1
            while copied < 3 and is_digit(source:sub(i, i)) do
              table.insert(out, source:sub(i, i))
              i = i + 1
              copied = copied + 1
            end
          else
            table.insert(out, '\\\\' .. nxt)
            fixes = fixes + 1
            i = i + 2
          end
        else
          table.insert(out, c)
          i = i + 1
        end
      end
      if not closed then
        table.insert(out, quote)
        fixes = fixes + 1
      end
    else
      local eq_count, long_end = read_long_open(source, i)
      if eq_count ~= nil then
        table.insert(out, source:sub(i, long_end))
        i = long_end + 1
        while i <= n do
          local close_end = read_long_close(source, i, eq_count)
          if close_end then
            table.insert(out, source:sub(i, close_end))
            i = close_end + 1
            break
          else
            table.insert(out, source:sub(i, i))
            i = i + 1
          end
        end
      else
        table.insert(out, ch)
        i = i + 1
      end
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end
  return table.concat(out), fixes, nil
end

local function split_line_comment_aware(line)
  local i = 1
  local n = #line
  local quote = nil
  local long_eq = nil

  while i <= n do
    local ch = line:sub(i, i)
    if quote then
      if ch == '\\' then
        i = i + 2
      elseif ch == quote then
        quote = nil
        i = i + 1
      else
        i = i + 1
      end
    elseif long_eq ~= nil then
      if ch == ']' then
        local close_end = read_long_close(line, i, long_eq)
        if close_end then
          long_eq = nil
          i = close_end + 1
        else
          i = i + 1
        end
      else
        i = i + 1
      end
    else
      if ch == '"' or ch == "'" then
        quote = ch
        i = i + 1
      elseif ch == '[' then
        local eq_count, open_end = read_long_open(line, i)
        if eq_count ~= nil then
          long_eq = eq_count
          i = open_end + 1
        else
          i = i + 1
        end
      elseif ch == '-' and line:sub(i + 1, i + 1) == '-' then
        return line:sub(1, i - 1), line:sub(i)
      else
        i = i + 1
      end
    end
  end

  return line, ''
end

local function fix_unclosed_short_strings(source)
  local lines = {}
  local start_at = 1
  while true do
    local nl = source:find('\n', start_at, true)
    if not nl then
      lines[#lines + 1] = source:sub(start_at)
      break
    end
    lines[#lines + 1] = source:sub(start_at, nl - 1)
    start_at = nl + 1
  end

  local fixes = 0
  for i = 1, #lines do
    local line = lines[i]
    local code, comment = split_line_comment_aware(line)
    local quote = nil
    local quote_pos = nil
    local quote_content = 0
    local j = 1
    local n = #code
    while j <= n do
      local ch = code:sub(j, j)
      if quote then
        if ch == '\\' then
          quote_content = quote_content + 1
          j = j + 2
        elseif ch == quote then
          quote = nil
          quote_pos = nil
          quote_content = 0
          j = j + 1
        else
          quote_content = quote_content + 1
          j = j + 1
        end
      else
        if ch == '"' or ch == "'" then
          quote = ch
          quote_pos = j
          quote_content = 0
          j = j + 1
        else
          j = j + 1
        end
      end
    end

    if quote then
      if quote_pos == #code and quote_content == 0 then
        -- A dangling quote at end-of-line (often accidental) is safer to drop than to create `...""`.
        lines[i] = code:sub(1, quote_pos - 1) .. comment
      else
        lines[i] = code .. quote .. comment
      end
      fixes = fixes + 1
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end
  return table.concat(lines, '\n'), fixes, nil
end

local function stringify_undefined_print_args(source, dialect)
  local Linter = require('src.linter')
  local ok_lint, lint = pcall(function()
    return Linter.run(source, { dialect = dialect, dynamic = false })
  end)
  if not ok_lint or type(lint) ~= 'table' then
    return nil, 0, nil
  end

  local undefined = {}
  for _, d in ipairs(lint.diagnostics or {}) do
    if d.code == 'undefined-reference' and type(d.message) == 'string' then
      local name = d.message:match("undefined reference '([^']+)'")
      if name and name ~= '' then
        undefined[name] = true
      end
    end
  end
  if next(undefined) == nil then
    return nil, 0, nil
  end

  local ok_ast, ast = pcall(function()
    local tokens = Lexer.new(source, { dialect = dialect }):tokenize()
    local parser = Parser.new(tokens, { dialect = dialect })
    return parser:parse()
  end)
  if not ok_ast or type(ast) ~= 'table' then
    return nil, 0, nil
  end

  local function new_scope(parent)
    return { parent = parent, locals = {} }
  end

  local function lookup_local(scope, name)
    local cur = scope
    while cur do
      if cur.locals[name] then
        return true
      end
      cur = cur.parent
    end
    return false
  end

  local function declare_local(scope, name)
    if type(name) == 'string' and name ~= '' then
      scope.locals[name] = true
    end
  end

  local function clone_set(set)
    local out = {}
    for k, v in pairs(set or {}) do
      if v then
        out[k] = true
      end
    end
    return out
  end

  local global_defs = {}
  local replacements = {}
  local names_set = {}
  local fixes = 0

  local function should_stringify(scope, name)
    if type(name) ~= 'string' or name == '' then
      return false
    end
    if not undefined[name] then
      return false
    end
    if lookup_local(scope, name) then
      return false
    end
    if global_defs[name] then
      return false
    end
    return true
  end

  local walk_expr, walk_block, walk_stmt

  walk_expr = function(node, scope)
    if not node or type(node) ~= 'table' then
      return
    end

    local t = node.type
    if t == 'FunctionCall' then
      local callee = node.callee
      if callee and type(callee) == 'table' and callee.type == 'Identifier' and callee.name == 'print' then
        if not lookup_local(scope, 'print') and not global_defs.print then
          for _, arg in ipairs(node.args or {}) do
            if arg and type(arg) == 'table' and arg.type == 'Identifier' then
              if should_stringify(scope, arg.name) then
                local tok = arg.token
                if tok and tok.line and tok.col then
                  fixes = fixes + 1
                  replacements[#replacements + 1] = { line = tok.line, col = tok.col, name = arg.name }
                  names_set[arg.name] = true
                end
              end
            end
          end
        end
      end

      walk_expr(callee, scope)
      for _, arg in ipairs(node.args or {}) do
        walk_expr(arg, scope)
      end
      return
    end

    if t == 'MethodCall' then
      walk_expr(node.object, scope)
      for _, arg in ipairs(node.args or {}) do
        walk_expr(arg, scope)
      end
      return
    end

    if t == 'BinaryOp' then
      walk_expr(node.left, scope)
      walk_expr(node.right, scope)
      return
    end

    if t == 'UnaryOp' then
      walk_expr(node.operand, scope)
      return
    end

    if t == 'IndexExpr' then
      walk_expr(node.object, scope)
      walk_expr(node.index, scope)
      return
    end

    if t == 'PropertyExpr' then
      walk_expr(node.object, scope)
      return
    end

    if t == 'Table' then
      for _, f in ipairs(node.fields or {}) do
        if f and type(f) == 'table' then
          if f.key then walk_expr(f.key, scope) end
          walk_expr(f.value, scope)
        end
      end
      return
    end

    if t == 'Function' then
      local fn_scope = new_scope(scope)
      for _, p in ipairs(node.params or {}) do
        declare_local(fn_scope, p)
      end
      local saved = global_defs
      global_defs = clone_set(saved)
      walk_block(node.body, fn_scope)
      global_defs = saved
      return
    end

    for k, v in pairs(node) do
      if k ~= 'token' and k ~= 'name_token' and k ~= 'name_tokens' and k ~= 'param_tokens' and k ~= 'var_token' and k ~= 'var_tokens' then
        if type(v) == 'table' then
          if v.type then
            walk_expr(v, scope)
          else
            for _, item in pairs(v) do
              if type(item) == 'table' and item.type then
                walk_expr(item, scope)
              end
            end
          end
        end
      end
    end
  end

  walk_block = function(block, scope)
    if not block or type(block) ~= 'table' then
      return
    end
    for _, stmt in ipairs(block.statements or {}) do
      walk_stmt(stmt, scope)
    end
  end

  walk_stmt = function(stmt, scope)
    if not stmt or type(stmt) ~= 'table' then
      return
    end
    local t = stmt.type

    if t == 'LocalDecl' then
      for _, v in ipairs(stmt.values or {}) do
        walk_expr(v, scope)
      end
      for _, name in ipairs(stmt.names or {}) do
        declare_local(scope, name)
      end
      return
    end

    if t == 'LocalFunc' then
      declare_local(scope, stmt.name)
      local saved = global_defs
      global_defs = clone_set(saved)
      walk_expr(stmt.body, scope)
      global_defs = saved
      return
    end

    if t == 'FunctionDecl' then
      local head = type(stmt.name) == 'string' and stmt.name:match('^([%a_][%w_]*)') or nil
      if head and not lookup_local(scope, head) then
        global_defs[head] = true
      end
      local fn_scope = new_scope(scope)
      for _, p in ipairs(stmt.params or {}) do
        declare_local(fn_scope, p)
      end
      local saved = global_defs
      global_defs = clone_set(saved)
      walk_block(stmt.body, fn_scope)
      global_defs = saved
      return
    end

    if t == 'If' then
      walk_expr(stmt.condition, scope)
      walk_block(stmt.then_body, new_scope(scope))
      for _, part in ipairs(stmt.elseif_parts or {}) do
        walk_expr(part.condition, scope)
        walk_block(part.body, new_scope(scope))
      end
      if stmt.else_body then
        walk_block(stmt.else_body, new_scope(scope))
      end
      return
    end

    if t == 'While' then
      walk_expr(stmt.condition, scope)
      walk_block(stmt.body, new_scope(scope))
      return
    end

    if t == 'Repeat' then
      local rep_scope = new_scope(scope)
      walk_block(stmt.body, rep_scope)
      walk_expr(stmt.condition, rep_scope)
      return
    end

    if t == 'For' then
      walk_expr(stmt.start, scope)
      walk_expr(stmt.finish, scope)
      if stmt.step then walk_expr(stmt.step, scope) end
      local for_scope = new_scope(scope)
      declare_local(for_scope, stmt.var)
      walk_block(stmt.body, for_scope)
      return
    end

    if t == 'ForIn' then
      for _, it in ipairs(stmt.iterators or {}) do
        walk_expr(it, scope)
      end
      local for_scope = new_scope(scope)
      for _, v in ipairs(stmt.vars or {}) do
        declare_local(for_scope, v)
      end
      walk_block(stmt.body, for_scope)
      return
    end

    if t == 'Do' then
      walk_block(stmt.body, new_scope(scope))
      return
    end

    if t == 'Assignment' then
      for _, v in ipairs(stmt.values or {}) do
        walk_expr(v, scope)
      end
      for _, target in ipairs(stmt.targets or {}) do
        if target and type(target) == 'table' and target.type == 'Identifier' and type(target.name) == 'string' then
          if not lookup_local(scope, target.name) then
            global_defs[target.name] = true
          end
        else
          walk_expr(target, scope)
        end
      end
      return
    end

    if t == 'Return' then
      for _, v in ipairs(stmt.values or {}) do
        walk_expr(v, scope)
      end
      return
    end

    walk_expr(stmt, scope)
  end

  local root = new_scope(nil)
  if ast.type == 'Chunk' and ast.body and ast.body.type == 'Block' then
    walk_block(ast.body, root)
  elseif ast.type == 'Block' then
    walk_block(ast, root)
  else
    walk_expr(ast, root)
  end

  if fixes == 0 then
    return nil, 0, nil
  end

  local names = {}
  for name in pairs(names_set) do
    names[#names + 1] = name
  end
  table.sort(names)

  local lines = {}
  local start_at = 1
  while true do
    local nl = source:find('\n', start_at, true)
    if not nl then
      lines[#lines + 1] = source:sub(start_at)
      break
    end
    lines[#lines + 1] = source:sub(start_at, nl - 1)
    start_at = nl + 1
  end

  local by_line = {}
  for _, rep in ipairs(replacements) do
    if rep.line and rep.col and rep.name then
      by_line[rep.line] = by_line[rep.line] or {}
      by_line[rep.line][#by_line[rep.line] + 1] = rep
    end
  end

  local function col_to_byte(line, col)
    col = tonumber(col) or 1
    if col <= 1 then
      return 1
    end
    if type(utf8) == 'table' and utf8.offset then
      local ok, b = pcall(utf8.offset, line, col)
      if ok and b then
        return b
      end
    end
    return col
  end

  local function escape_string(s)
    return tostring(s)
      :gsub('\\', '\\\\')
      :gsub('"', '\\"')
  end

  for line_no, reps in pairs(by_line) do
    local line = lines[line_no]
    if type(line) == 'string' then
      table.sort(reps, function(a, b)
        return (a.col or 0) > (b.col or 0)
      end)
      for _, rep in ipairs(reps) do
        local name = rep.name
        local b = col_to_byte(line, rep.col)
        local got = line:sub(b, b + #name - 1)
        if got == name then
          line = line:sub(1, b - 1) .. '"' .. escape_string(name) .. '"' .. line:sub(b + #name)
        end
      end
      lines[line_no] = line
    end
  end

  return table.concat(lines, '\n'), fixes, names
end
local lua_keywords = {
  ['and'] = true, ['break'] = true, ['do'] = true, ['else'] = true, ['elseif'] = true,
  ['end'] = true, ['false'] = true, ['for'] = true, ['function'] = true, ['goto'] = true,
  ['if'] = true, ['in'] = true, ['local'] = true, ['nil'] = true, ['not'] = true,
  ['or'] = true, ['repeat'] = true, ['return'] = true, ['then'] = true, ['true'] = true,
  ['until'] = true, ['while'] = true
}

local function normalize_unicode_in_code_regions(source, replace_map, remove_list)
  local replace_keys = {}
  for bad in pairs(replace_map or {}) do
    replace_keys[#replace_keys + 1] = bad
  end
  table.sort(replace_keys, function(a, b)
    return #a > #b
  end)

  local remove_keys = {}
  for _, bad in ipairs(remove_list or {}) do
    remove_keys[#remove_keys + 1] = bad
  end
  table.sort(remove_keys, function(a, b)
    return #a > #b
  end)

  local function match_key(keys, i)
    for _, key in ipairs(keys) do
      if source:sub(i, i + #key - 1) == key then
        return key
      end
    end
    return nil
  end

  local out = {}
  local fixes = 0
  local n = #source
  local i = 1

  while i <= n do
    local ch = source:sub(i, i)
    local ch2 = source:sub(i, i + 1)

    if ch2 == '--' then
      local eq_count, long_end = read_long_open(source, i + 2)
      if eq_count ~= nil then
        out[#out + 1] = source:sub(i, long_end)
        i = long_end + 1
        while i <= n do
          local close_end = read_long_close(source, i, eq_count)
          if close_end then
            out[#out + 1] = source:sub(i, close_end)
            i = close_end + 1
            break
          end
          out[#out + 1] = source:sub(i, i)
          i = i + 1
        end
      else
        while i <= n do
          local c = source:sub(i, i)
          out[#out + 1] = c
          i = i + 1
          if c == '\n' then
            break
          end
        end
      end
    elseif ch == '"' or ch == "'" then
      local quote = ch
      out[#out + 1] = quote
      i = i + 1
      while i <= n do
        local c = source:sub(i, i)
        out[#out + 1] = c
        if c == '\\' then
          i = i + 1
          if i <= n then
            out[#out + 1] = source:sub(i, i)
            i = i + 1
          end
        elseif c == quote then
          i = i + 1
          break
        else
          i = i + 1
        end
      end
    else
      local eq_count, long_end = read_long_open(source, i)
      if eq_count ~= nil then
        out[#out + 1] = source:sub(i, long_end)
        i = long_end + 1
        while i <= n do
          local close_end = read_long_close(source, i, eq_count)
          if close_end then
            out[#out + 1] = source:sub(i, close_end)
            i = close_end + 1
            break
          end
          out[#out + 1] = source:sub(i, i)
          i = i + 1
        end
      else
        local remove_key = match_key(remove_keys, i)
        if remove_key then
          fixes = fixes + 1
          i = i + #remove_key
        else
          local replace_key = match_key(replace_keys, i)
          if replace_key then
            out[#out + 1] = replace_map[replace_key]
            fixes = fixes + 1
            i = i + #replace_key
          else
            out[#out + 1] = ch
            i = i + 1
          end
        end
      end
    end
  end

  return table.concat(out), fixes
end

local function fix_aggressive_lua_salvage(source)
  local fixes = 0
  local text = source

  local unicode_map = {
    ['（'] = '(', ['）'] = ')',
    ['［'] = '[', ['］'] = ']',
    ['｛'] = '{', ['｝'] = '}',
    ['，'] = ',', ['；'] = ';', ['：'] = ':',
    ['．'] = '.', ['。'] = '.',
    ['＋'] = '+', ['－'] = '-', ['＊'] = '*', ['／'] = '/',
    ['％'] = '%', ['＝'] = '=', ['＜'] = '<', ['＞'] = '>',
    ['！'] = '!', ['＆'] = '&', ['｜'] = '|', ['＾'] = '^',
    ['～'] = '~', ['＃'] = '#',
    ['“'] = '"', ['”'] = '"', ['„'] = '"',
    ['‘'] = "'", ['’'] = "'", ['‚'] = "'",
    ['「'] = '"', ['」'] = '"', ['『'] = '"', ['』'] = '"',
    ['　'] = ' '
  }

  local unicode_removed = {
    '\226\128\139', -- U+200B zero width space
    '\226\128\140', -- U+200C zero width non-joiner
    '\226\128\141', -- U+200D zero width joiner
    '\239\187\191'  -- U+FEFF BOM
  }

  local normalized_text, normalized_fixes = normalize_unicode_in_code_regions(text, unicode_map, unicode_removed)
  if normalized_fixes > 0 then
    text = normalized_text
    fixes = fixes + normalized_fixes
  end

  local function split_lines(src)
    local lines = {}
    local s = 1
    while true do
      local p = src:find('\n', s, true)
      if not p then
        lines[#lines + 1] = src:sub(s)
        break
      end
      lines[#lines + 1] = src:sub(s, p - 1)
      s = p + 1
    end
    return lines
  end

  local function split_comment_local(line)
    return split_line_comment_aware(line)
  end

  local keyword_list = {
    'local', 'function', 'return', 'then', 'elseif', 'else', 'end',
    'for', 'while', 'repeat', 'until', 'break', 'goto',
    'not', 'and', 'nil', 'true', 'false'
  }

  local identifier_hints = {
    'print', 'pairs', 'ipairs', 'require', 'tostring', 'tonumber',
    'setmetatable', 'getmetatable', 'pcall', 'xpcall', 'assert', 'type'
  }

  local word_set = {}
  local function seed_words(list)
    for _, w in ipairs(list) do
      word_set[w] = true
    end
  end
  seed_words(keyword_list)
  seed_words(identifier_hints)

  local function collapse_spaced_words(code)
    local leading = code:match('^(%s*)') or ''
    local body = code:sub(#leading + 1)
    local tokens = {}
    for t in body:gmatch('%S+') do
      tokens[#tokens + 1] = t
    end
    if #tokens == 0 then
      return code, 0
    end

    local out = {}
    local i = 1
    local changed = 0

    while i <= #tokens do
      local tk = tokens[i]
      if tk:match('^[_%a]$') then
        local j = i
        while j <= #tokens and tokens[j]:match('^[_%a]$') do
          j = j + 1
        end

        local best_end = nil
        local acc = ''
        for k = i, j - 1 do
          acc = acc .. tokens[k]
          if word_set[acc] then
            best_end = k
          end
        end

        if best_end then
          out[#out + 1] = table.concat(tokens, '', i, best_end)
          changed = changed + (best_end - i)
          i = best_end + 1
        else
          out[#out + 1] = tk
          i = i + 1
        end
      else
        out[#out + 1] = tk
        i = i + 1
      end
    end

    return leading .. table.concat(out, ' '), changed
  end

  local function compact_spaced_keyword(code)
    local changed = 0
    local function apply_word_list(words)
      for _, kw in ipairs(words) do
        local chars = {}
        for i = 1, #kw do
          chars[#chars + 1] = kw:sub(i, i)
        end
        local pat = '%f[%a_]' .. table.concat(chars, '%s+') .. '%f[^%a_]'
        local c = 0
        code, c = code:gsub(pat, kw)
        if c > 0 then
          changed = changed + c
        end
      end
    end

    apply_word_list(keyword_list)
    apply_word_list(identifier_hints)

    local line_lead_short = {
      { pat = '^%s*i%s+f%f[^%a_]', rep = 'if' },
      { pat = '^%s*d%s+o%f[^%a_]', rep = 'do' },
      { pat = '^%s*o%s+r%f[^%a_]', rep = 'or' },
      { pat = '^%s*i%s+n%f[^%a_]', rep = 'in' }
    }
    for _, item in ipairs(line_lead_short) do
      local c = 0
      code, c = code:gsub(item.pat, item.rep)
      if c > 0 then
        changed = changed + c
      end
    end

    return code, changed
  end

  local function normalize_ops(code)
    local changed = 0
    local function rep(pat, repl)
      local c = 0
      code, c = code:gsub(pat, repl)
      changed = changed + c
    end

    rep('=%s*=', '==')
    rep('~%s*=', '~=')
    rep('<%s*=', '<=')
    rep('>%s*=', '>=')
    rep('%/%s*/', '//')
    rep(':%s*:', '::')
    rep('%.%s*%.%s*%.', '...')
    rep('%.%s*%.', '..')
    rep('%-%s*>', '->')
    rep('=%s*>', '=>')
    rep('%+%s*=', '+=')
    rep('%-%s*=', '-=')
    rep('%*%s*=', '*=')
    rep('/%s*=', '/=')
    rep('%% %s*=', '%%=')
    rep('%^%s*=', '^=')
    rep('&%s*=', '&=')
    rep('|%s*=', '|=')
    rep('%.%.%s*=', '..=')
    rep('&%s*&', '&&')
    rep('|%s*|', '||')

    return code, changed
  end

  local lines = split_lines(text)
  local line_fix = 0

  for i = 1, #lines do
    local line = lines[i]
    local code, comment = split_comment_local(line)
    local c1 = 0
    local c2 = 0
    local c3 = 0
    local fixed = code
    fixed, c1 = collapse_spaced_words(fixed)
    fixed, c2 = compact_spaced_keyword(fixed)
    fixed, c3 = normalize_ops(fixed)
    if c1 > 0 or c2 > 0 or c3 > 0 then
      line_fix = line_fix + c1 + c2 + c3
      lines[i] = fixed .. comment
    end
  end

  fixes = fixes + line_fix
  text = table.concat(lines, '\n')

  if fixes == 0 then
    return nil, 0, nil
  end
  return text, fixes, nil
end

local function fix_keyword_typos(source)
  local replacements = {
    fucntion = 'function',
    funtion = 'function',
    funciton = 'function',
    functoin = 'function',
    locla = 'local',
    loacl = 'local',
    retrun = 'return',
    retun = 'return',
    whlie = 'while',
    untli = 'until',
    pritn = 'print',
    prnit = 'print'
  }

  local keys = {}
  for k in pairs(replacements) do
    keys[#keys + 1] = k
  end
  table.sort(keys, function(a, b)
    return #a > #b
  end)

  local function is_word_char(ch)
    return ch ~= '' and ch:match('^[%w_]$') ~= nil
  end

  local out = {}
  local fixes = 0
  local n = #source
  local i = 1

  while i <= n do
    local ch = source:sub(i, i)
    local ch2 = source:sub(i, i + 1)

    if ch2 == '--' then
      local eq_count, long_end = read_long_open(source, i + 2)
      if eq_count ~= nil then
        out[#out + 1] = source:sub(i, long_end)
        i = long_end + 1
        while i <= n do
          local close_end = read_long_close(source, i, eq_count)
          if close_end then
            out[#out + 1] = source:sub(i, close_end)
            i = close_end + 1
            break
          end
          out[#out + 1] = source:sub(i, i)
          i = i + 1
        end
      else
        while i <= n do
          local c = source:sub(i, i)
          out[#out + 1] = c
          i = i + 1
          if c == '\n' then
            break
          end
        end
      end
    elseif ch == '"' or ch == "'" then
      local quote = ch
      out[#out + 1] = quote
      i = i + 1
      while i <= n do
        local c = source:sub(i, i)
        out[#out + 1] = c
        if c == '\\' then
          i = i + 1
          if i <= n then
            out[#out + 1] = source:sub(i, i)
            i = i + 1
          end
        elseif c == quote then
          i = i + 1
          break
        else
          i = i + 1
        end
      end
    else
      local eq_count, long_end = read_long_open(source, i)
      if eq_count ~= nil then
        out[#out + 1] = source:sub(i, long_end)
        i = long_end + 1
        while i <= n do
          local close_end = read_long_close(source, i, eq_count)
          if close_end then
            out[#out + 1] = source:sub(i, close_end)
            i = close_end + 1
            break
          end
          out[#out + 1] = source:sub(i, i)
          i = i + 1
        end
      else
        local replaced = false
        for _, key in ipairs(keys) do
          if source:sub(i, i + #key - 1) == key then
            local prev = source:sub(i - 1, i - 1)
            local nxt = source:sub(i + #key, i + #key)
            if not is_word_char(prev) and not is_word_char(nxt) then
              out[#out + 1] = replacements[key]
              i = i + #key
              fixes = fixes + 1
              replaced = true
              break
            end
          end
        end
        if not replaced then
          out[#out + 1] = ch
          i = i + 1
        end
      end
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end
  return table.concat(out), fixes, nil
end

local function fix_missing_equals_in_local_assign(source)
  local function trim_inline(s)
    return (s:gsub('^%s+', ''):gsub('%s+$', ''))
  end

  local lines = {}
  local start_at = 1
  while true do
    local nl = source:find('\n', start_at, true)
    if not nl then
      lines[#lines + 1] = source:sub(start_at)
      break
    end
    lines[#lines + 1] = source:sub(start_at, nl - 1)
    start_at = nl + 1
  end

  local fixes = 0
  for i = 1, #lines do
    local line = lines[i]
    local leading, body = line:match('^(%s*)(.*)$')
    local code, trailing_comment = split_line_comment_aware(body)
    local trimmed = trim_inline(code)

    local name, rest = trimmed:match('^local%s+([_%a][%w_]*)%s+(.+)$')
    if name and rest then
      local rest_trim = trim_inline(rest)
      local first = rest_trim:sub(1, 1)
      local second = rest_trim:sub(2, 2)

      local is_local_function = rest_trim:match('^function%f[^%a_]') ~= nil
      local is_typed = first == ':'
      local is_already_assign = first == '='
      local is_multi_decl = first == ','
      local looks_compare = first == '=' and second == '='

      if (not is_typed) and (not is_already_assign) and (not is_multi_decl) and (not looks_compare) then
        local rebuilt = leading .. 'local ' .. name .. ' = ' .. rest_trim .. trailing_comment
        if rebuilt ~= line then
          lines[i] = rebuilt
          fixes = fixes + 1
        end
      elseif is_local_function then
        -- prefer `local name = function(...)` if a broken `local name function` was produced
        local rebuilt = leading .. 'local ' .. name .. ' = ' .. rest_trim .. trailing_comment
        if rebuilt ~= line then
          lines[i] = rebuilt
          fixes = fixes + 1
        end
      end
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end
  return table.concat(lines, '\n'), fixes, nil
end

local function fix_split_return_values(source)
  local lines = {}
  local start_at = 1
  while true do
    local nl = source:find('\n', start_at, true)
    if not nl then
      lines[#lines + 1] = source:sub(start_at)
      break
    end
    lines[#lines + 1] = source:sub(start_at, nl - 1)
    start_at = nl + 1
  end

  local fixes = 0
  local removed = {}

  local function trim_inline(s)
    return (s:gsub('^%s+', ''):gsub('%s+$', ''))
  end

  local function split_comment_local(line)
    return split_line_comment_aware(line)
  end

  local function starts_expression(line)
    local t = trim_inline(line)
    if t == '' then return false end
    local c = t:sub(1, 1)
    if c:match('^[%a_]$') or c:match('^%d$') then
      return true
    end
    if c == '"' or c == "'" or c == '(' or c == '{' or c == '[' or c == '-' or c == '#' or c == '~' then
      return true
    end
    return t:match('^%.%.%.') ~= nil
  end

  local function starts_statement(line)
    local t = trim_inline(line)
    if t == '' then return false end
    local w = t:match('^([_%a][%w_]*)')
    if not w then
      return false
    end
    if w == 'if' or w == 'for' or w == 'while' or w == 'repeat' or w == 'do'
      or w == 'function' or w == 'local' or w == 'return' or w == 'break'
      or w == 'end' or w == 'else' or w == 'elseif' or w == 'until'
      or w == 'goto' then
      return true
    end
    return false
  end

  for i = 1, #lines do
    local line = lines[i]
    local code, comment = split_comment_local(line)
    local trimmed = trim_inline(code)
    if trimmed == 'return' then
      local j = i + 1
      while j <= #lines and trim_inline(lines[j]) == '' do
        j = j + 1
      end
      if j <= #lines and starts_expression(lines[j]) and not starts_statement(lines[j]) then
        local next_code, _ = split_comment_local(lines[j])
        local merged = code .. ' ' .. trim_inline(next_code) .. comment
        lines[i] = merged
        removed[j] = true
        fixes = fixes + 1
      end
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end

  local out = {}
  for i = 1, #lines do
    if not removed[i] then
      out[#out + 1] = lines[i]
    end
  end
  return table.concat(out, '\n'), fixes, nil
end

local function fix_missing_call_parentheses(source)
  local function trim_inline(s)
    return (s:gsub('^%s+', ''):gsub('%s+$', ''))
  end

  local lines = {}
  local start_at = 1
  while true do
    local nl = source:find('\n', start_at, true)
    if not nl then
      lines[#lines + 1] = source:sub(start_at)
      break
    end
    lines[#lines + 1] = source:sub(start_at, nl - 1)
    start_at = nl + 1
  end

  local fixes = 0
  for i = 1, #lines do
    local line = lines[i]
    local leading, body = line:match('^(%s*)(.*)$')
    local code, trailing_comment = body:match('^(.-)(%-%-.*)$')
    if not code then
      code = body
      trailing_comment = ''
    end

    local trimmed = trim_inline(code)
    if trimmed ~= '' then
      local callee, arg = trimmed:match('^([_%a][%w_%.:]*)%s+(.+)$')
      if callee and arg then
        local arg_trim = trim_inline(arg)
        local first = arg_trim:sub(1, 1)
        local is_keyword = lua_keywords[callee] == true
        local looks_assignment = first == '='
        local already_valid_short_call = first == '"' or first == "'" or first == '{'
        local already_parenthesized = first == '('
        local call_continuation = first == ':' or first == '.'
        local bad_start = first == '' or first == ',' or first == ';' or first == ')'
        local is_label = callee:sub(1, 2) == '::'

        if (not is_keyword)
          and (not looks_assignment)
          and (not already_valid_short_call)
          and (not already_parenthesized)
          and (not call_continuation)
          and (not bad_start)
          and (not is_label) then
          local rebuilt = leading .. callee .. '(' .. arg_trim .. ')' .. trailing_comment
          if rebuilt ~= line then
            lines[i] = rebuilt
            fixes = fixes + 1
          end
        end
      end
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end
  return table.concat(lines, '\n'), fixes, nil
end

local function best_error_loc(state)
  if not state then
    return nil
  end
  local c = state.compile_loc
  if c and tonumber(c.line) then
    return c
  end
  local p = state.parse_loc
  if p and tonumber(p.line) then
    return p
  end
  return nil
end

local function fix_missing_call_parentheses_at_error(source, _, state)
  local loc = best_error_loc(state)
  if not loc or not loc.line then
    return nil, 0, nil
  end

  local line_no = tonumber(loc.line)
  if not line_no or line_no < 1 then
    return nil, 0, nil
  end

  local function trim_inline(s)
    return (s:gsub('^%s+', ''):gsub('%s+$', ''))
  end

  local lines = {}
  local start_at = 1
  while true do
    local nl = source:find('\n', start_at, true)
    if not nl then
      lines[#lines + 1] = source:sub(start_at)
      break
    end
    lines[#lines + 1] = source:sub(start_at, nl - 1)
    start_at = nl + 1
  end

  local line = lines[line_no]
  if type(line) ~= 'string' then
    return nil, 0, nil
  end

  local leading, body = line:match('^(%s*)(.*)$')
  local code, trailing_comment = split_line_comment_aware(body)
  local trimmed = trim_inline(code)
  if trimmed == '' then
    return nil, 0, nil
  end

  local callee, arg = trimmed:match('^([_%a][%w_%.:]*)%s+(.+)$')
  if not callee or not arg then
    return nil, 0, nil
  end

  if lua_keywords[callee] == true then
    return nil, 0, nil
  end

  local arg_trim = trim_inline(arg)
  local first = arg_trim:sub(1, 1)
  if first == '' then
    return nil, 0, nil
  end
  if first == '=' or first == ',' or first == ';' or first == ')' then
    return nil, 0, nil
  end
  if first == '(' or first == '{' or first == '"' or first == "'" then
    return nil, 0, nil
  end
  if first == ':' or first == '.' then
    return nil, 0, nil
  end
  if callee:sub(1, 2) == '::' then
    return nil, 0, nil
  end

  local rebuilt = leading .. callee .. '(' .. arg_trim .. ')' .. trailing_comment
  if rebuilt == line then
    return nil, 0, nil
  end
  lines[line_no] = rebuilt
  return table.concat(lines, '\n'), 1, nil
end

local function fix_orphan_end_line_at_error(source, _, state)
  if not state or not state.parse_error then
    return nil, 0, nil
  end
  local msg = tostring(state.parse_error)
  if not (msg:find('Unexpected token: END', 1, true) or msg:find('unexpected token: END', 1, true)) then
    return nil, 0, nil
  end

  local loc = best_error_loc(state)
  if not loc or not loc.line then
    return nil, 0, nil
  end

  local line_no = tonumber(loc.line)
  if not line_no or line_no < 1 then
    return nil, 0, nil
  end

  local lines = {}
  local start_at = 1
  while true do
    local nl = source:find('\n', start_at, true)
    if not nl then
      lines[#lines + 1] = source:sub(start_at)
      break
    end
    lines[#lines + 1] = source:sub(start_at, nl - 1)
    start_at = nl + 1
  end

  local line = lines[line_no]
  if type(line) ~= 'string' then
    return nil, 0, nil
  end

  local code, comment = split_line_comment_aware(line)
  local trimmed = (code:gsub('^%s+', ''):gsub('%s+$', ''))
  if trimmed ~= 'end' and trimmed ~= 'end;' then
    return nil, 0, nil
  end

  lines[line_no] = comment ~= '' and comment or ''
  return table.concat(lines, '\n'), 1, nil
end

local function count_char_in_text(text, ch)
  local n = 0
  for i = 1, #text do
    if text:sub(i, i) == ch then
      n = n + 1
    end
  end
  return n
end

local function strip_short_strings(line)
  local out = {}
  local i = 1
  local n = #line
  while i <= n do
    local ch = line:sub(i, i)
    if ch == '"' or ch == "'" then
      local q = ch
      out[#out + 1] = ' '
      i = i + 1
      while i <= n do
        local c = line:sub(i, i)
        if c == '\\' then
          i = i + 2
        elseif c == q then
          i = i + 1
          break
        else
          i = i + 1
        end
      end
    else
      out[#out + 1] = ch
      i = i + 1
    end
  end
  return table.concat(out)
end

local function split_line_comment_simple(line)
  return split_line_comment_aware(line)
end

local function is_table_field_assignment(text)
  if text:match('^[_%a][%w_]*%s*=%s*.+$') then
    return true
  end
  if text:match('^%[[^%]]+%]%s*=%s*.+$') then
    return true
  end
  return false
end

local function needs_then_line(trimmed)
  if trimmed:match('^if%s+') or trimmed:match('^elseif%s+') then
    if not trimmed:match('%f[%a]then%f[%A]') then
      return true
    end
  end
  return false
end

local function needs_do_line(trimmed)
  if trimmed:match('^while%s+') or trimmed:match('^for%s+') then
    if not trimmed:match('%f[%a]do%f[%A]') then
      return true
    end
  end
  return false
end

local function add_inline_table_value_commas(code)
  local changed = false
  local out = code:gsub('{([^{}]+)}', function(inner)
    local fixed = inner
    local prev = fixed
    repeat
      prev = fixed
      fixed = fixed:gsub('(%d+)%s+(%d+)', '%1,%2')
      fixed = fixed:gsub('("[^"\n]*")%s+("[^"\n]*")', '%1,%2')
      fixed = fixed:gsub("('[^'\n]*')%s+('[^'\n]*')", '%1,%2')
      fixed = fixed:gsub('([_%a][%w_]*)%s+([_%a][%w_]*)', '%1,%2')
    until fixed == prev
    if fixed ~= inner then
      changed = true
    end
    return '{' .. fixed .. '}'
  end)
  return out, changed
end

local function fix_lua_line_heuristics(source)
  local function trim_inline(s)
    return (s:gsub('^%s+', ''):gsub('%s+$', ''))
  end

  local lines = {}
  local start_at = 1
  while true do
    local nl = source:find('\n', start_at, true)
    if not nl then
      lines[#lines + 1] = source:sub(start_at)
      break
    end
    lines[#lines + 1] = source:sub(start_at, nl - 1)
    start_at = nl + 1
  end

  local fixes = 0
  local brace_depth = 0

  local function next_nonempty_index(i)
    local j = i + 1
    while j <= #lines do
      if trim_inline(lines[j]) ~= '' then
        return j
      end
      j = j + 1
    end
    return nil
  end

  for i = 1, #lines do
    local line = lines[i]
    local code, trailing_comment = split_line_comment_simple(line)
    local leading = code:match('^(%s*)') or ''
    local body = code:sub(#leading + 1)
    local trimmed = trim_inline(body)

    if trimmed ~= '' then
      if needs_then_line(trimmed) then
        body = body .. ' then'
        fixes = fixes + 1
      elseif needs_do_line(trimmed) then
        body = body .. ' do'
        fixes = fixes + 1
      end

      local paren_scan = strip_short_strings(body)
      local paren_delta = count_char_in_text(paren_scan, '(') - count_char_in_text(paren_scan, ')')

      if paren_delta > 0 and trim_inline(body):match('^return%f[%A]') then
        body = body .. string.rep(')', paren_delta)
        fixes = fixes + 1
      end

      if paren_delta > 0 and body:match('%(%s*$') then
        body = body .. ')'
        fixes = fixes + 1
      elseif body:match('^[%s]*[%w_%.:]+%s*%(%s*$') then
        local next_i = next_nonempty_index(i)
        if next_i then
          local nx = trim_inline(lines[next_i])
          if nx:match('^return%f[%A]') or nx:match('^end%f[%A]') or nx:match('^elseif%f[%A]')
            or nx:match('^else%f[%A]') or nx:match('^until%f[%A]') or nx:match('^[%}%)]') then
            body = body .. ')'
            fixes = fixes + 1
          end
        end
      end

      local fixed_inline, inline_changed = add_inline_table_value_commas(body)
      if inline_changed then
        body = fixed_inline
        fixes = fixes + 1
      end
    end

    local rebuilt = leading .. body .. trailing_comment
    lines[i] = rebuilt

    local scan_line = strip_short_strings(body)
    local depth_before = brace_depth
    brace_depth = brace_depth + count_char_in_text(scan_line, '{') - count_char_in_text(scan_line, '}')
    if brace_depth < 0 then
      brace_depth = 0
    end

    if depth_before > 0 then
      local cur_trim = trim_inline(body)
      if is_table_field_assignment(cur_trim) and not cur_trim:match('[,;]%s*$') then
        local j = next_nonempty_index(i)
        if j then
          local next_code, _ = split_line_comment_simple(lines[j])
          local next_trim = trim_inline(next_code)
          if is_table_field_assignment(next_trim) then
            lines[i] = lines[i] .. ','
            fixes = fixes + 1
          end
        end
      end
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end
  return table.concat(lines, '\n'), fixes, nil
end

local function trim_line(s)
  return (s:gsub('^%s+', ''):gsub('%s+$', ''))
end

local function count_line_char(s, ch)
  local n = 0
  for i = 1, #s do
    if s:sub(i, i) == ch then
      n = n + 1
    end
  end
  return n
end

local function can_merge_orphan_closers(prev_line, closers)
  local close_seq = closers:gsub('[,;]', '')
  local paren_delta = count_line_char(prev_line, '(') - count_line_char(prev_line, ')')
  local bracket_delta = count_line_char(prev_line, '[') - count_line_char(prev_line, ']')
  local brace_delta = count_line_char(prev_line, '{') - count_line_char(prev_line, '}')

  for i = 1, #close_seq do
    local c = close_seq:sub(i, i)
    if c == ')' then
      if paren_delta <= 0 then
        return false
      end
      paren_delta = paren_delta - 1
    elseif c == ']' then
      if bracket_delta <= 0 then
        return false
      end
      bracket_delta = bracket_delta - 1
    elseif c == '}' then
      if brace_delta <= 0 then
        return false
      end
      brace_delta = brace_delta - 1
    end
  end

  return true
end

local function fix_orphan_closer_lines(source)
  local lines = {}
  local start_at = 1
  while true do
    local nl = source:find('\n', start_at, true)
    if not nl then
      lines[#lines + 1] = source:sub(start_at)
      break
    end
    lines[#lines + 1] = source:sub(start_at, nl - 1)
    start_at = nl + 1
  end

  local removed = {}
  local fixes = 0

  for i = 2, #lines do
    local cur_trim = trim_line(lines[i])
    if cur_trim ~= '' and cur_trim:match('^[%)%]%}]+[,;]?$') then
      local j = i - 1
      while j >= 1 and trim_line(lines[j]) == '' do
        j = j - 1
      end
      if j >= 1 and can_merge_orphan_closers(lines[j], cur_trim) then
        lines[j] = lines[j] .. cur_trim
        removed[i] = true
        fixes = fixes + 1
      end
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end

  local out = {}
  for i = 1, #lines do
    if not removed[i] then
      out[#out + 1] = lines[i]
    end
  end
  return table.concat(out, '\n'), fixes, nil
end

local function fix_broken_text_seed(source, dialect)
  local current = source
  local fixes = 0

  local pipeline = {
    fix_aggressive_lua_salvage,
    fix_keyword_typos,
    fix_missing_equals_in_local_assign,
    fix_unclosed_short_strings,
    fix_invalid_string_escapes,
    fix_missing_call_parentheses,
    fix_missing_control_keywords,
    fix_lua_line_heuristics,
    append_missing_closers
  }

  for _, fn in ipairs(pipeline) do
    local candidate, count = fn(current, dialect)
    if candidate and candidate ~= current then
      current = candidate
      fixes = fixes + (count or 0)
    end
  end

  if fixes == 0 then
    return nil, 0, nil
  end
  return current, fixes, nil
end

local function normalize_reasoning(value)
  local v = tostring(value or 'high'):lower()
  if v ~= 'basic' and v ~= 'high' and v ~= 'max' then
    return 'high'
  end
  return v
end

local function normalize_memory(value)
  local v = tostring(value or 'low'):lower()
  if v ~= 'tiny' and v ~= 'low' and v ~= 'balanced' and v ~= 'high' then
    return 'low'
  end
  return v
end

local function build_ai_settings(source_len, options)
  local reasoning = normalize_reasoning(options.reasoning)
  local memory = normalize_memory(options.memory)
  local lua_specialized = options.lua_specialized ~= false

  local depth
  local beam
  local attempts
  if source_len >= 500000 then
    depth = 2
    beam = 2
    attempts = 180
  elseif source_len >= 200000 then
    depth = 3
    beam = 3
    attempts = 240
  elseif source_len >= 90000 then
    depth = 4
    beam = 5
    attempts = 320
  else
    depth = 5
    beam = 8
    attempts = 420
  end

  local max_change_ratio = 0.72
  local max_score_drop = 340
  local max_semicolon_spike = 200
  local max_single_fixes = 20000
  local max_quality_drop_depth = 2
  local max_quality_drop_ratio = 0.25
  local max_fixers_per_node = nil
  local max_fixers_per_node_step = nil

  if memory == 'tiny' then
    depth = math.min(depth, 2)
    beam = math.min(beam, 2)
    attempts = math.min(attempts, 120)
    max_change_ratio = 0.72
    max_score_drop = 900
    max_semicolon_spike = 70
    max_single_fixes = 5000
    max_quality_drop_depth = 2
    max_quality_drop_ratio = 0.45
    max_fixers_per_node = 8
    max_fixers_per_node_step = 4
  elseif memory == 'low' then
    depth = math.min(depth, 4)
    beam = math.min(beam, 5)
    attempts = math.min(attempts, 260)
    max_change_ratio = 0.82
    max_score_drop = 1500
    max_semicolon_spike = 110
    max_single_fixes = 9000
    max_quality_drop_depth = 4
    max_quality_drop_ratio = 0.75
    max_fixers_per_node = 10
    max_fixers_per_node_step = 4
  elseif memory == 'balanced' then
    max_change_ratio = 0.72
    max_score_drop = 340
    max_semicolon_spike = 200
    max_single_fixes = 20000
    max_quality_drop_depth = 2
    max_quality_drop_ratio = 0.25
  elseif memory == 'high' then
    depth = depth + 1
    beam = beam + 2
    attempts = math.floor(attempts * 1.35)
    max_change_ratio = 0.82
    max_score_drop = 420
    max_semicolon_spike = 300
    max_single_fixes = 35000
    max_quality_drop_depth = 3
    max_quality_drop_ratio = 0.33
  end

  if reasoning == 'basic' then
    depth = math.max(1, depth - 1)
    beam = math.max(1, beam - 1)
    attempts = math.max(80, math.floor(attempts * 0.75))
    max_score_drop = math.max(150, max_score_drop - 80)
    max_quality_drop_depth = math.max(1, max_quality_drop_depth - 1)
    max_quality_drop_ratio = math.max(0.12, max_quality_drop_ratio - 0.06)
  elseif reasoning == 'max' then
    depth = depth + 2
    beam = beam + 2
    attempts = math.floor(attempts * 1.5)
    max_change_ratio = math.min(0.92, max_change_ratio + 0.08)
    max_score_drop = max_score_drop + 120
    max_semicolon_spike = max_semicolon_spike + 100
    max_single_fixes = max_single_fixes + 12000
    max_quality_drop_depth = max_quality_drop_depth + 1
    max_quality_drop_ratio = math.min(0.5, max_quality_drop_ratio + 0.1)
  end

  if lua_specialized then
    max_change_ratio = math.min(0.92, max_change_ratio + 0.03)
    max_score_drop = max_score_drop + 30
    max_quality_drop_ratio = math.min(0.5, max_quality_drop_ratio + 0.03)
  end

  if tonumber(options.ai_max_depth) then
    depth = math.max(1, math.floor(tonumber(options.ai_max_depth)))
  end
  if tonumber(options.ai_beam_width) then
    beam = math.max(1, math.floor(tonumber(options.ai_beam_width)))
  end
  if tonumber(options.ai_attempt_limit) then
    attempts = math.max(16, math.floor(tonumber(options.ai_attempt_limit)))
  end

  return {
    reasoning = reasoning,
    memory = memory,
    lua_specialized = lua_specialized,
    max_depth = depth,
    beam_width = beam,
    attempt_limit = attempts,
    max_change_ratio = max_change_ratio,
    max_score_drop = max_score_drop,
    max_semicolon_spike = max_semicolon_spike,
    max_single_fixes = max_single_fixes,
    max_quality_drop_depth = max_quality_drop_depth,
    max_quality_drop_ratio = max_quality_drop_ratio,
    max_fixers_per_node = max_fixers_per_node,
    max_fixers_per_node_step = max_fixers_per_node_step
  }
end

local function state_quality_value(state)
  if not state then return 0 end
  if state.parse_ok and state.compile_ok then return 3 end
  if state.parse_ok then return 2 end
  if state.compile_ok then return 1 end
  return 0
end

local function run_fallback_pipeline(source, fixers, dialect, max_rounds)
  local current = source
  local before = analyze_state(current, dialect)
  local current_state = before
  local best = current
  local best_state = before
  local best_quality = state_quality_value(before)
  local rounds = {}
  local applied_fixes = {}

  max_rounds = tonumber(max_rounds) or 6
  if max_rounds < 1 then
    max_rounds = 1
  end

  for round = 1, max_rounds do
    local round_changed = false
    local steps = {}
    for _, fixer in ipairs(fixers) do
      if current_state.parse_ok and current_state.compile_ok then
        break
      end

      local candidate, fixes, err = fixer.fn(current, dialect, current_state)
      if candidate and candidate ~= current then
        local st = analyze_state(candidate, dialect)
        local applied = false
        local pruned_reason = nil

        if current_state.parse_ok and not st.parse_ok then
          pruned_reason = 'ast-regression'
        else
          local q_old = state_quality_value(current_state)
          local q_new = state_quality_value(st)
          if q_new < q_old then
            pruned_reason = 'quality-regression'
          elseif q_new == q_old then
            local a = best_error_loc(current_state)
            local b = best_error_loc(st)
            if a and b and tonumber(a.line) and tonumber(b.line) then
              if tonumber(b.line) > tonumber(a.line) then
                applied = true
              elseif tonumber(b.line) == tonumber(a.line) and tonumber(a.col) and tonumber(b.col) and tonumber(b.col) > tonumber(a.col) then
                applied = true
              end
            elseif (not a) and b and tonumber(b.line) then
              applied = true
            end
            if not applied then
              pruned_reason = 'no-progress'
            end
          else
            applied = true
          end
        end

        steps[#steps + 1] = {
          name = fixer.name,
          changed = true,
          applied = applied,
          fixes = fixes or 0,
          pruned = pruned_reason,
          parse_ok = st.parse_ok,
          compile_ok = st.compile_ok,
          parse_error = st.parse_error,
          compile_error = st.compile_error
        }

        if applied then
          current = candidate
          current_state = st
          applied_fixes[#applied_fixes + 1] = fixer.name
          round_changed = true

          local q = state_quality_value(st)
          if q > best_quality then
            best = candidate
            best_state = st
            best_quality = q
          elseif q == best_quality then
            if st.parse_ok and st.compile_ok then
              best = candidate
              best_state = st
            end
          end

          if current_state.parse_ok and current_state.compile_ok then
            break
          end
        end
      else
        steps[#steps + 1] = {
          name = fixer.name,
          changed = false,
          fixes = fixes or 0,
          error = err and tostring(err) or nil
        }
      end
    end

    local state_after_round = current_state
    if state_quality_value(state_after_round) >= best_quality then
      best = current
      best_state = state_after_round
      best_quality = state_quality_value(state_after_round)
    end

    rounds[#rounds + 1] = {
      round = round,
      changed = round_changed,
      parse_ok = state_after_round.parse_ok,
      compile_ok = state_after_round.compile_ok,
      parse_error = state_after_round.parse_error,
      compile_error = state_after_round.compile_error,
      steps = steps
    }

    if state_after_round.parse_ok and state_after_round.compile_ok then
      return {
        success = true,
        text = current,
        state = state_after_round,
        rounds = rounds,
        applied_fixes = applied_fixes
      }
    end
    if not round_changed then
      break
    end
  end

  return {
    success = best_state.parse_ok and best_state.compile_ok,
    text = best,
    state = best_state,
    rounds = rounds,
    applied_fixes = applied_fixes
  }
end

function CodeFix.run(source, options)
  options = options or {}
  local dialect = options.dialect
  local report = {
    type = 'codefix-report',
    generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
    attempts = {}
  }

  local raw_source = source
  local normalized_source = source
  local normalization_fixes = 0
  do
    local c = 0
    normalized_source, c = normalized_source:gsub('^\239\187\191', '')
    normalization_fixes = normalization_fixes + c
    normalized_source, c = normalized_source:gsub('\r\n', '\n')
    normalization_fixes = normalization_fixes + c
    normalized_source, c = normalized_source:gsub('\r', '\n')
    normalization_fixes = normalization_fixes + c
  end
  report.normalization = {
    applied = normalization_fixes > 0,
    fixes = normalization_fixes
  }

  local before = analyze_state(normalized_source, dialect)
  report.before = before

  local function add_attempt(name, changed, fixes, state, err, meta)
    local item = {
      name = name,
      changed = changed and true or false,
      fixes = fixes or 0
    }
    if state then
      item.parse_ok = state.parse_ok
      item.compile_ok = state.compile_ok
      item.parse_error = state.parse_error
      item.compile_error = state.compile_error
    end
    if err then
      item.error = tostring(err)
    end
    if meta then
      if meta.pruned ~= nil then
        item.pruned = meta.pruned
      end
      if meta.duplicate then
        item.duplicate = true
      end
      if meta.score ~= nil then
        item.score = meta.score
      end
      if meta.degraded then
        item.degraded = true
      end
    end
    report.attempts[#report.attempts + 1] = item
  end

  local working = normalized_source
  local working_state = before
  local fixers = {
    { name = 'fix-keyword-typos', fn = fix_keyword_typos },
    { name = 'fix-orphan-end-line@error', fn = fix_orphan_end_line_at_error },
    { name = 'fix-missing-call-parentheses@error', fn = fix_missing_call_parentheses_at_error },
    { name = 'fix-missing-local-equals', fn = fix_missing_equals_in_local_assign },
    { name = 'fix-broken-text-seed', fn = fix_broken_text_seed },
    { name = 'fix-aggressive-lua-salvage', fn = fix_aggressive_lua_salvage },
    { name = 'fix-invalid-string-escapes', fn = fix_invalid_string_escapes },
    { name = 'fix-unclosed-short-strings', fn = fix_unclosed_short_strings },
    { name = 'fix-lua-line-heuristics', fn = fix_lua_line_heuristics },
    { name = 'fix-split-return-values', fn = fix_split_return_values },
    { name = 'fix-missing-call-parentheses', fn = fix_missing_call_parentheses },
    { name = 'fix-missing-table-commas', fn = fix_missing_table_commas },
    { name = 'fix-missing-call-commas', fn = fix_missing_call_commas },
    { name = 'fix-missing-control-keywords', fn = fix_missing_control_keywords },
    { name = 'insert-statement-separators', fn = fix_statement_separators },
    { name = 'append-missing-closers', fn = append_missing_closers },
    { name = 'merge-orphan-closers', fn = fix_orphan_closer_lines }
  }

  local ai_settings = build_ai_settings(#working, {
    reasoning = options.reasoning,
    memory = options.memory,
    lua_specialized = options.lua_specialized,
    ai_max_depth = options.ai_max_depth,
    ai_beam_width = options.ai_beam_width,
    ai_attempt_limit = options.ai_attempt_limit
  })

  local solved = CodeFixAI.solve(working, fixers, analyze_state, {
    dialect = dialect,
    max_depth = ai_settings.max_depth,
    beam_width = ai_settings.beam_width,
    attempt_limit = ai_settings.attempt_limit,
    max_change_ratio = ai_settings.max_change_ratio,
    max_score_drop = ai_settings.max_score_drop,
    max_semicolon_spike = ai_settings.max_semicolon_spike,
    max_single_fixes = ai_settings.max_single_fixes,
    max_quality_drop_depth = ai_settings.max_quality_drop_depth,
    max_quality_drop_ratio = ai_settings.max_quality_drop_ratio,
    max_fixers_per_node = ai_settings.max_fixers_per_node,
    max_fixers_per_node_step = ai_settings.max_fixers_per_node_step
  })

  report.ai = {
    enabled = true,
    mode = 'full-ai',
    reasoning = ai_settings.reasoning,
    memory = ai_settings.memory,
    lua_specialized = ai_settings.lua_specialized,
    max_depth = ai_settings.max_depth,
    beam_width = ai_settings.beam_width,
    attempt_limit = ai_settings.attempt_limit,
    attempts = #solved.attempts,
    attempts_dropped = solved.attempts_dropped or 0,
    best_score = solved.best and solved.best.score or nil,
    best_path = solved.best and solved.best.path or nil,
    stats = solved.stats or {}
  }

  local ai_applied_fixes = {}
  if solved.best and solved.best.path and solved.best.path ~= '' then
    for seg in tostring(solved.best.path):gmatch('[^>]+') do
      local name = seg:gsub('^%s+', ''):gsub('%s+$', '')
      if name ~= '' then
        ai_applied_fixes[#ai_applied_fixes + 1] = name
      end
    end
  end
  report.ai.applied_fixes = ai_applied_fixes

  for _, attempt in ipairs(solved.attempts) do
    local state = nil
    if attempt.parse_ok ~= nil or attempt.compile_ok ~= nil then
      state = {
        parse_ok = attempt.parse_ok,
        compile_ok = attempt.compile_ok,
        parse_error = attempt.parse_error,
        compile_error = attempt.compile_error
      }
    end
    add_attempt(attempt.name, attempt.changed, attempt.fixes, state, attempt.error, attempt)
  end

  if solved.best then
    working = solved.best.text
    working_state = solved.best.state
  end

  local ai_success = working_state.parse_ok and working_state.compile_ok
  if not ai_success then
    local fallback = run_fallback_pipeline(working, fixers, dialect, options.fallback_rounds)
    report.fallback = {
      attempted = true,
      success = fallback.success and true or false,
      rounds = #fallback.rounds,
      details = fallback.rounds,
      applied_fixes = fallback.applied_fixes or {}
    }
    if fallback.text and fallback.state then
      working = fallback.text
      working_state = fallback.state
    end
  else
    report.fallback = { attempted = false, success = false, rounds = 0 }
  end

  local success = working_state.parse_ok and working_state.compile_ok
  local final_output = raw_source
  local applied_fixes_final = {}
  for i = 1, #ai_applied_fixes do
    applied_fixes_final[#applied_fixes_final + 1] = ai_applied_fixes[i]
  end
  if report.fallback and report.fallback.attempted and report.fallback.applied_fixes then
    for i = 1, #report.fallback.applied_fixes do
      applied_fixes_final[#applied_fixes_final + 1] = report.fallback.applied_fixes[i]
    end
  end
  if success then
    final_output = working
    local merged_text, merged_fixes = fix_orphan_closer_lines(final_output)
    if merged_text and merged_fixes > 0 then
      local merged_state = analyze_state(merged_text, dialect)
      if merged_state.parse_ok and merged_state.compile_ok then
        final_output = merged_text
        working_state = merged_state
        report.post_fix = report.post_fix or {}
        report.post_fix.orphan_closer_merges = merged_fixes
        applied_fixes_final[#applied_fixes_final + 1] = 'post:merge-orphan-closers'
      end
    end

    do
      local want_stringify = (options.stringify_undefined_print_args ~= false)
      if want_stringify then
        local patched, patched_count, patched_names = stringify_undefined_print_args(final_output, dialect)
        if patched and patched_count > 0 then
          local patched_state = analyze_state(patched, dialect)
          if patched_state.parse_ok and patched_state.compile_ok then
            final_output = patched
            working_state = patched_state
            report.post_fix = report.post_fix or {}
            report.post_fix.undefined_print_args = {
              count = patched_count,
              names = patched_names
            }
            applied_fixes_final[#applied_fixes_final + 1] = 'post:stringify-undefined-print-args'
          else
            report.post_fix = report.post_fix or {}
            report.post_fix.undefined_print_args = {
              count = patched_count,
              names = patched_names,
              applied = false,
              state = {
                parse_ok = patched_state.parse_ok,
                compile_ok = patched_state.compile_ok,
                parse_error = patched_state.parse_error,
                compile_error = patched_state.compile_error
              }
            }
          end
        end
      end
    end

    do
      local want_format = (options.format_output ~= false)
      if want_format then
        local ok, formatted_or_err = pcall(function()
          return Formatter.format(final_output, { dialect = dialect })
        end)
        if ok and type(formatted_or_err) == 'string' then
          local formatted = formatted_or_err
          if formatted ~= final_output then
            local formatted_state = analyze_state(formatted, dialect)
            if formatted_state.parse_ok and formatted_state.compile_ok then
              final_output = formatted
              working_state = formatted_state
              report.post_fix = report.post_fix or {}
              report.post_fix.formatted = true
              applied_fixes_final[#applied_fixes_final + 1] = 'post:format'
            else
              report.post_fix = report.post_fix or {}
              report.post_fix.formatted = false
              report.post_fix.format_state = {
                parse_ok = formatted_state.parse_ok,
                compile_ok = formatted_state.compile_ok,
                parse_error = formatted_state.parse_error,
                compile_error = formatted_state.compile_error
              }
            end
          else
            report.post_fix = report.post_fix or {}
            report.post_fix.formatted = false
            report.post_fix.format_reason = 'no-change'
          end
        else
          report.post_fix = report.post_fix or {}
          report.post_fix.formatted = false
          report.post_fix.format_error = tostring(formatted_or_err)
        end
      end
    end

    report.after = working_state
  else
    report.after = before
    report.reverted_to_source = true
    applied_fixes_final = {}
  end

  report.success = success and (final_output ~= nil)
  report.changed = final_output ~= raw_source
  report.applied_fixes = applied_fixes_final

  do
    local function has_fix(name)
      for i = 1, #applied_fixes_final do
        if applied_fixes_final[i] == name then
          return true
        end
      end
      return false
    end

    local notes = {}
    if report.normalization and report.normalization.applied then
      notes[#notes + 1] = 'input normalized (BOM/CRLF); locations refer to normalized text'
    end
    if has_fix('fix-aggressive-lua-salvage') or has_fix('fix-broken-text-seed') then
      notes[#notes + 1] = 'unicode normalization may shift column positions vs original source (esp. zero-width removals)'
    end
    if #notes > 0 then
      report.location_notes = notes
    end
  end

  return final_output, { all_locals = {} }, {
    report_data = report,
    report_suffix = '.codefix.json'
  }
end

return CodeFix
