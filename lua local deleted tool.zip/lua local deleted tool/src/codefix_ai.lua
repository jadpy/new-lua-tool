local CodeFixAI = {}

local function count_char(text, ch)
  local n = 0
  for i = 1, #text do
    if text:sub(i, i) == ch then
      n = n + 1
    end
  end
  return n
end

local function state_quality(state)
  if not state then return 0 end
  if state.parse_ok and state.compile_ok then
    return 3
  end
  if state.parse_ok then
    return 2
  end
  if state.compile_ok then
    return 1
  end
  return 0
end

local function fast_hash32(text)
  local len = #text
  local h = 2166136261
  local step = 1
  if len > 8192 then
    step = math.floor(len / 4096)
    if step < 1 then step = 1 end
  end
  for i = 1, len, step do
    h = (h * 16777619) % 4294967296
    h = (h + text:byte(i)) % 4294967296
  end
  if step > 1 then
    local tail_start = len - 128
    if tail_start < 1 then tail_start = 1 end
    for i = tail_start, len do
      h = (h * 16777619) % 4294967296
      h = (h + text:byte(i)) % 4294967296
    end
  end
  return string.format('%08x', h)
end

local function text_signature(text)
  local len = #text
  local head = text:sub(1, 24)
  local tail = text:sub(-24)
  local hash = fast_hash32(text)
  local nl = count_char(text, '\n')
  return table.concat({ tostring(len), hash, tostring(nl), head, tail }, '|')
end

local function safe_transition(from_text, to_text, meta, options)
  if not to_text or to_text == '' then
    return false, 'empty-output'
  end
  if to_text:find('\0', 1, true) then
    return false, 'binary-output'
  end

  local max_change_ratio = tonumber(options.max_change_ratio) or 0.75
  local from_len = #from_text
  local to_len = #to_text
  local ratio = 0
  if from_len > 0 then
    ratio = math.abs(to_len - from_len) / from_len
  end
  if ratio > max_change_ratio then
    return false, 'large-delta'
  end

  local max_semicolon_spike = tonumber(options.max_semicolon_spike) or 200
  local semi_delta = count_char(to_text, ';') - count_char(from_text, ';')
  if semi_delta > max_semicolon_spike then
    return false, 'semicolon-spike'
  end

  if meta and tonumber(meta.fixes) and meta.fixes > (tonumber(options.max_single_fixes) or 20000) then
    return false, 'too-many-fixes'
  end

  return true, nil
end

local function score_candidate(base_text, text, state, meta, parent_state)
  local quality = state_quality(state)
  local parent_quality = state_quality(parent_state)
  local score = quality * 800

  if quality > parent_quality then
    score = score + (quality - parent_quality) * 180
  elseif quality < parent_quality then
    score = score - (parent_quality - quality) * 260
  end

  if state.parse_ok then
    score = score + 130
  end
  if state.compile_ok then
    score = score + 190
  end

  local base_len = #base_text
  local cur_len = #text
  local delta_ratio = 0
  if base_len > 0 then
    delta_ratio = math.abs(cur_len - base_len) / base_len
  end
  score = score - (delta_ratio * 180)

  local change_ratio = meta and meta.change_ratio or 0
  score = score - (change_ratio * 90)

  local depth = meta and meta.depth or 0
  score = score - (depth * 2.5)

  local fixes = meta and (meta.fixes or 0) or 0
  score = score + math.min(fixes, 24) * 1.1

  local semicolons = count_char(text, ';')
  score = score - (semicolons * 0.25)

  if state.parse_error and state.parse_error ~= '' then
    score = score - 35
  end
  if state.compile_error and state.compile_error ~= '' then
    score = score - 30
  end

  if parent_state then
    if parent_state.string_ok == false and state.string_ok == true then
      score = score + 60
    elseif parent_state.string_ok == true and state.string_ok == false then
      score = score - 80
    end
  end

  local function best_loc(st)
    if not st then return nil end
    local c = st.compile_loc
    if c and tonumber(c.line) then
      return c
    end
    local p = st.parse_loc
    if p and tonumber(p.line) then
      return p
    end
    return nil
  end

  -- Prefer candidates that move the primary error location "forward" (later line/col).
  if parent_state and quality == parent_quality and quality < 2 then
    local a = best_loc(parent_state)
    local b = best_loc(state)
    if a and b and tonumber(a.line) and tonumber(b.line) then
      local delta_line = tonumber(b.line) - tonumber(a.line)
      if delta_line ~= 0 then
        score = score + math.max(-40, math.min(40, delta_line * 2))
      elseif tonumber(a.col) and tonumber(b.col) then
        local delta_col = tonumber(b.col) - tonumber(a.col)
        score = score + math.max(-15, math.min(15, delta_col * 0.6))
      end
    end
  end

  if meta and meta.pruned_reason then
    score = score - 400
  end

  return score
end

local function append_path(path, step)
  if not path or path == '' then
    return step
  end
  return path .. ' > ' .. step
end

local function push_attempt(attempts, attempt_limit, dropped, item)
  if #attempts < attempt_limit then
    attempts[#attempts + 1] = item
  else
    dropped.value = dropped.value + 1
  end
end

local function default_depth_for_size(len)
  if len >= 500000 then return 2 end
  if len >= 200000 then return 3 end
  if len >= 90000 then return 4 end
  return 5
end

local function default_beam_for_size(len)
  if len >= 500000 then return 2 end
  if len >= 200000 then return 3 end
  if len >= 90000 then return 5 end
  return 8
end

function CodeFixAI.solve(source, fixers, analyze_fn, options)
  options = options or {}
  local dialect = options.dialect
  local src_len = #source
  local max_depth = tonumber(options.max_depth) or default_depth_for_size(src_len)
  local beam_width = tonumber(options.beam_width) or default_beam_for_size(src_len)
  local attempt_limit = tonumber(options.attempt_limit) or 320
  local max_score_drop = tonumber(options.max_score_drop) or 320
  local max_quality_drop_depth = tonumber(options.max_quality_drop_depth) or 2
  local max_quality_drop_ratio = tonumber(options.max_quality_drop_ratio) or 0.25
  local max_fixers_per_node = tonumber(options.max_fixers_per_node)
  local max_fixers_per_node_step = tonumber(options.max_fixers_per_node_step) or 0

  if max_depth < 1 then max_depth = 1 end
  if beam_width < 1 then beam_width = 1 end
  if attempt_limit < 16 then attempt_limit = 16 end
  if max_fixers_per_node and max_fixers_per_node < 1 then
    max_fixers_per_node = nil
  end

  local attempts = {}
  local dropped = { value = 0 }
  local stats = {
    analyzed = 0,
    cache_hits = 0,
    cache_misses = 0,
    pruned_duplicate = 0,
    pruned_safety = 0,
    pruned_ast = 0,
    pruned_score = 0,
    signatures_seen = 0
  }

  local state_cache = {}
  local function analyze_cached(text)
    local sig = text_signature(text)
    local cached = state_cache[sig]
    if cached then
      stats.cache_hits = stats.cache_hits + 1
      return cached, sig
    end
    local state = analyze_fn(text, dialect)
    state_cache[sig] = state
    stats.cache_misses = stats.cache_misses + 1
    stats.analyzed = stats.analyzed + 1
    return state, sig
  end

  local initial_state, initial_sig = analyze_cached(source)
  local initial_score = score_candidate(source, source, initial_state, { depth = 0, fixes = 0, change_ratio = 0 }, nil)

  local best = {
    text = source,
    state = initial_state,
    score = initial_score,
    depth = 0,
    path = '',
    signature = initial_sig
  }

  local seen_score = { [initial_sig] = initial_score }
  local beam = { best }
  stats.signatures_seen = 1

  if initial_state and initial_state.parse_ok and initial_state.compile_ok then
    stats.attempts_kept = 0
    stats.attempts_dropped = 0
    return {
      initial_state = initial_state,
      best = best,
      attempts = attempts,
      attempts_dropped = 0,
      stats = stats
    }
  end

  for depth = 1, max_depth do
    local candidate_map = {}
    local any_candidate = false

    for _, node in ipairs(beam) do
      local fixers_n = #fixers
      if max_fixers_per_node then
        fixers_n = math.min(fixers_n, max_fixers_per_node + (depth - 1) * max_fixers_per_node_step)
      end
      for i = 1, fixers_n do
        local fixer = fixers[i]
        local candidate, fixes, err = fixer.fn(node.text, dialect, node.state)
        if candidate and candidate ~= node.text then
          local change_ratio = 0
          if #node.text > 0 then
            change_ratio = math.abs(#candidate - #node.text) / #node.text
          end

          local safe_ok, safe_reason = safe_transition(node.text, candidate, { fixes = fixes or 0 }, options)
           if not safe_ok then
             stats.pruned_safety = stats.pruned_safety + 1
             push_attempt(attempts, attempt_limit, dropped, {
               name = fixer.name,
              changed = false,
              fixes = fixes or 0,
              pruned = safe_reason
             })
           else
             local state, sig = analyze_cached(candidate)
            if node.state and node.state.parse_ok and not state.parse_ok then
              stats.pruned_ast = stats.pruned_ast + 1
              push_attempt(attempts, attempt_limit, dropped, {
                name = fixer.name,
                changed = false,
                fixes = fixes or 0,
                pruned = 'ast-regression',
                parse_ok = state.parse_ok,
                compile_ok = state.compile_ok,
                parse_error = state.parse_error,
                compile_error = state.compile_error
              })
            else
              local score = score_candidate(source, candidate, state, {
                depth = depth,
                fixes = fixes or 0,
                change_ratio = change_ratio
              }, node.state)

              local prev_seen = seen_score[sig]
              if prev_seen and score <= prev_seen then
                stats.pruned_duplicate = stats.pruned_duplicate + 1
                push_attempt(attempts, attempt_limit, dropped, {
                  name = fixer.name,
                  changed = false,
                  fixes = fixes or 0,
                  duplicate = true,
                  score = score
                })
              else
                if score < (node.score - max_score_drop) and not (state.parse_ok and state.compile_ok) then
                  local parent_quality = state_quality(node.state)
                  local current_quality = state_quality(state)
                  local can_keep_degraded = false
                  if depth <= max_quality_drop_depth and parent_quality >= 2 and current_quality >= 0 then
                    if change_ratio <= max_quality_drop_ratio and (fixes or 0) > 0 then
                      can_keep_degraded = true
                    end
                  end

                  if not can_keep_degraded then
                    stats.pruned_score = stats.pruned_score + 1
                    push_attempt(attempts, attempt_limit, dropped, {
                      name = fixer.name,
                      changed = false,
                      fixes = fixes or 0,
                      pruned = 'score-floor',
                      score = score
                    })
                  else
                    any_candidate = true
                    seen_score[sig] = score
                    local item = {
                      text = candidate,
                      state = state,
                      score = score,
                      depth = depth,
                      path = append_path(node.path, fixer.name),
                      signature = sig
                    }
                    local prior = candidate_map[sig]
                    if not prior or item.score > prior.score then
                      candidate_map[sig] = item
                    end

                    push_attempt(attempts, attempt_limit, dropped, {
                      name = fixer.name,
                      changed = true,
                      fixes = fixes or 0,
                      parse_ok = state.parse_ok,
                      compile_ok = state.compile_ok,
                      parse_error = state.parse_error,
                      compile_error = state.compile_error,
                      score = score,
                      degraded = true
                    })

                    if item.score > best.score then
                      best = item
                    end
                  end
                else
                  any_candidate = true
                  seen_score[sig] = score
                  local item = {
                    text = candidate,
                    state = state,
                    score = score,
                    depth = depth,
                    path = append_path(node.path, fixer.name),
                    signature = sig
                  }
                  local prior = candidate_map[sig]
                  if not prior or item.score > prior.score then
                    candidate_map[sig] = item
                  end

                  push_attempt(attempts, attempt_limit, dropped, {
                    name = fixer.name,
                    changed = true,
                    fixes = fixes or 0,
                    parse_ok = state.parse_ok,
                    compile_ok = state.compile_ok,
                    parse_error = state.parse_error,
                    compile_error = state.compile_error,
                    score = score
                  })

                  if item.score > best.score then
                    best = item
                  end
                end
              end
            end
          end
        else
          push_attempt(attempts, attempt_limit, dropped, {
            name = fixer.name,
            changed = false,
            fixes = fixes or 0,
            error = err and tostring(err) or nil
          })
        end
      end
    end

    if not any_candidate then
      break
    end

    local next_beam = {}
    for _, item in pairs(candidate_map) do
      next_beam[#next_beam + 1] = item
    end
    if #next_beam == 0 then
      break
    end

    table.sort(next_beam, function(a, b)
      if a.score == b.score then
        return #a.text < #b.text
      end
      return a.score > b.score
    end)

    beam = {}
    for i = 1, math.min(beam_width, #next_beam) do
      beam[#beam + 1] = next_beam[i]
    end

    local solved = nil
    for _, item in ipairs(beam) do
      if item.state.parse_ok and item.state.compile_ok then
        if not solved or item.score > solved.score then
          solved = item
        end
      end
    end
    if solved then
      local best_is_solved = best.state and best.state.parse_ok and best.state.compile_ok
      if (not best_is_solved) or solved.score > best.score then
        best = solved
      end
      break
    end
  end

  local seen_n = 0
  for _ in pairs(seen_score) do
    seen_n = seen_n + 1
  end
  stats.signatures_seen = seen_n
  stats.attempts_kept = #attempts
  stats.attempts_dropped = dropped.value

  return {
    initial_state = initial_state,
    best = best,
    attempts = attempts,
    attempts_dropped = dropped.value,
    stats = stats
  }
end

return CodeFixAI
