import argparse
import json
import sys
from pathlib import Path

try:
    from .luatool_runner import run_with_file, run_with_source
except Exception:
    from luatool_runner import run_with_file, run_with_source


def _is_existing_file(s: str) -> bool:
    try:
        return Path(s).is_file()
    except OSError:
        return False


def _resolve_input(args) -> tuple[str, str, str]:
    if args.file:
        p = Path(args.file)
        return "file", str(p), p.name
    if args.code is not None:
        return "code", args.code, "code.lua"
    if args.input is None:
        raise ValueError("missing input")
    if args.input == ["-"]:
        return "code", sys.stdin.read(), "stdin.lua"
    text = " ".join(args.input).strip()
    if _is_existing_file(text):
        p = Path(text)
        return "file", str(p), p.name
    return "code", text, "code.lua"


def _print_lint(report: dict) -> None:
    res = report.get("result") or {}
    summary = res.get("summary") or {}
    total = summary.get("total", 0)
    err = summary.get("error", 0)
    warn = summary.get("warning", 0)
    info = summary.get("info", 0)
    ok = res.get("ok")
    print(f"ok: {ok}")
    print(f"summary: total={total} error={err} warning={warn} info={info}")
    diags = res.get("diagnostics") or []
    for d in diags:
        code = d.get("code", "lint")
        line = d.get("line", 1)
        col = d.get("col", 1)
        sev = d.get("severity", "info")
        msg = d.get("message", "")
        print(f"{sev} {code} L{line} C{col}: {msg}")


def _print_rrequire(report: dict) -> None:
    res = report.get("result") or {}
    summary = res.get("summary") or {}
    files = summary.get("files", 0)
    edges = summary.get("edges", 0)
    unresolved = summary.get("unresolved", 0)
    dynamic = summary.get("dynamic", 0)
    parse_errors = summary.get("parse_errors", 0)
    print(f"summary: files={files} edges={edges} unresolved={unresolved} dynamic={dynamic} parse_errors={parse_errors}")
    unres = res.get("unresolved") or []
    if unres:
        print("unresolved:")
        for x in unres:
            print(f"- {x}")


def _print_tracelint(report: dict, log_text: str | None) -> None:
    res = report.get("result") or {}
    ok = res.get("ok")
    phase = res.get("phase", "runtime")
    timeout = res.get("timeout", False)
    err = res.get("error")
    dur = res.get("duration_ms", 0)
    print(f"ok: {ok} phase: {phase} timeout: {timeout} duration_ms: {dur}")
    if err:
        print(f"error: {err}")
    out = res.get("output") or {}
    items = out.get("items") or []
    omitted = out.get("omitted", 0)
    print(f"output: items={len(items)} omitted={omitted}")
    events = res.get("events") or []
    if events:
        print(f"events: {len(events)}")
        for e in events[:12]:
            code = e.get("code", "sandbox-event")
            level = e.get("level", "info")
            cnt = e.get("count", 0)
            msg = e.get("message", "")
            print(f"- {level} {code} x{cnt}: {msg}")
    deps = (res.get("dependencies") or {}).get("proxies") or {}
    roots = deps.get("roots") or []
    reads = deps.get("reads") or []
    if roots or reads:
        print(f"proxy deps: roots={len(roots)} reads={len(reads)}")
    if log_text and log_text.strip():
        print("log:")
        print(log_text.rstrip())
    elif items:
        print("log:")
        for it in items[:120]:
            seq = it.get("seq", 0)
            kind = it.get("kind", "print")
            msg = it.get("message", "")
            print(f"[{seq:04d}] {kind}: {msg}")


def _run_mode(mode: str, args, *, lint_trace: str | None = None) -> int:
    try:
        kind, value, name_hint = _resolve_input(args)
    except Exception as e:
        print(str(e), file=sys.stderr)
        return 2
    if kind == "file":
        result = run_with_file(
            mode,
            value,
            lint_trace=lint_trace,
            timeout_s=args.timeout,
            keep=args.keep,
        )
    else:
        result = run_with_source(
            mode,
            value,
            name_hint=name_hint,
            lint_trace=lint_trace,
            timeout_s=args.timeout,
            keep=args.keep,
        )
    if not result.get("ok"):
        stderr = result.get("stderr") or ""
        if stderr.strip():
            print(stderr.rstrip(), file=sys.stderr)
        else:
            print("failed", file=sys.stderr)
        return 1
    out = result.get("output_code") or ""
    if getattr(args, "out", None):
        Path(args.out).write_text(out, encoding="utf-8", errors="replace")
        return 0
    if mode in {"lint", "rrequire"}:
        reports = result.get("reports") or {}
        if mode == "lint":
            rep = reports.get("lint")
            if isinstance(rep, dict):
                if getattr(args, "json", False):
                    print(json.dumps(rep, ensure_ascii=False, indent=2))
                else:
                    _print_lint(rep)
        else:
            rep = reports.get("rrequire")
            if isinstance(rep, dict):
                if getattr(args, "json", False):
                    print(json.dumps(rep, ensure_ascii=False, indent=2))
                else:
                    _print_rrequire(rep)
        return 0
    if mode == "tracelint":
        reports = result.get("reports") or {}
        rep = reports.get("tracelint")
        if isinstance(rep, dict):
            if getattr(args, "json", False):
                print(json.dumps(rep, ensure_ascii=False, indent=2))
            else:
                artifacts = result.get("artifacts") or {}
                log_text = artifacts.get("tracelint_log")
                _print_tracelint(rep, log_text if isinstance(log_text, str) else None)
        return 0
    sys.stdout.write(out)
    if not out.endswith("\n"):
        sys.stdout.write("\n")
    return 0


def repl() -> int:
    print("type !help for commands, !exit to quit")
    mode_alias = {
        "dep": "rrequire",
        "num": "nmbun",
    }
    while True:
        try:
            line = input("> ").strip()
        except EOFError:
            return 0
        if not line:
            continue
        if line in {"!exit", "exit", "quit", "!quit"}:
            return 0
        if line in {"!help", "help"}:
            print("!fom <code|file>")
            print("!coml <code|file>")
            print("!rename <code|file>")
            print("!codefix <code|file>")
            print("!nocode <code|file>")
            print("!deleteout <code|file>")
            print("!outcode <code|file>")
            print("!nmbun <code|file>")
            print("!num <code|file>")
            print("!rrequire <code|file>")
            print("!dep <code|file>")
            print("!lint trace=on|off <code|file>")
            print("!tracelint <code|file>")
            continue
        if not line.startswith("!"):
            print("commands must start with !")
            continue
        cmd, _, rest = line[1:].partition(" ")
        cmd = cmd.strip().lower()
        rest = rest.strip()
        mode = mode_alias.get(cmd, cmd)
        trace = None
        if mode == "lint":
            first, _, after = rest.partition(" ")
            if first.lower().startswith("trace="):
                trace = first.split("=", 1)[1].strip().lower()
                rest = after.strip()
            else:
                trace = "on"
        if not rest:
            print("missing input")
            continue
        if _is_existing_file(rest):
            r = run_with_file(mode, rest, lint_trace=trace, keep=False)
        else:
            r = run_with_source(mode, rest, name_hint="code.lua", lint_trace=trace, keep=False)
        if not r.get("ok"):
            print((r.get("stderr") or "failed").rstrip())
            continue
        if mode == "lint":
            rep = (r.get("reports") or {}).get("lint")
            if isinstance(rep, dict):
                _print_lint(rep)
            continue
        if mode == "rrequire":
            rep = (r.get("reports") or {}).get("rrequire")
            if isinstance(rep, dict):
                _print_rrequire(rep)
            continue
        if mode == "tracelint":
            rep = (r.get("reports") or {}).get("tracelint")
            if isinstance(rep, dict):
                artifacts = r.get("artifacts") or {}
                log_text = artifacts.get("tracelint_log")
                _print_tracelint(rep, log_text if isinstance(log_text, str) else None)
            continue
        out = r.get("output_code") or ""
        sys.stdout.write(out)
        if not out.endswith("\n"):
            sys.stdout.write("\n")


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(prog="discordbot", add_help=True)
    sub = parser.add_subparsers(dest="cmd", required=True)
    def add_common(p):
        p.add_argument("--file")
        p.add_argument("--code")
        p.add_argument("--out")
        p.add_argument("--timeout", type=int, default=120)
        p.add_argument("--keep", action="store_true")
        p.add_argument("input", nargs=argparse.REMAINDER)
    for name in ["fom", "coml", "rename", "codefix", "nocode", "deleteout", "outcode", "nmbun", "num", "rrequire", "tracelint"]:
        p = sub.add_parser(name)
        add_common(p)
        if name == "num":
            p.set_defaults(_mode="nmbun")
            continue
        if name == "rrequire":
            p.add_argument("--json", action="store_true")
        if name == "tracelint":
            p.add_argument("--json", action="store_true")
        p.set_defaults(_mode=name)
    p = sub.add_parser("lint")
    add_common(p)
    p.add_argument("--trace", choices=["on", "off"], default="on")
    p.add_argument("--json", action="store_true")
    p.set_defaults(_mode="lint")
    p = sub.add_parser("deps")
    add_common(p)
    p.add_argument("--json", action="store_true")
    p.set_defaults(_mode="rrequire")
    p = sub.add_parser("repl")
    p.set_defaults(_repl=True)
    ns = parser.parse_args(argv)
    if getattr(ns, "_repl", False):
        raise SystemExit(repl())
    mode = ns._mode
    if mode == "lint":
        raise SystemExit(_run_mode("lint", ns, lint_trace=ns.trace))
    raise SystemExit(_run_mode(mode, ns))


if __name__ == "__main__":
    main()
