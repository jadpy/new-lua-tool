# Python Wrapper (Discord Optional)

This folder provides a Python interface for the Lua tool in the repo root.

## No Discord (CLI)

Run from repo root:

```powershell
python -m discordbot fom --file test.lua
python -m discordbot coml --file test.lua
python -m discordbot rename --file test.lua
python -m discordbot codefix --file test.lua
python -m discordbot nocode --file test.lua
python -m discordbot deleteout --file test.lua
python -m discordbot outcode --file test.lua
python -m discordbot num --file test.lua
python -m discordbot lint --trace on --file test.lua
python -m discordbot lint --trace off --file test.lua
python -m discordbot tracelint --file test.lua
python -m discordbot deps --file test.lua
```

Notes:

- Default behavior cleans up generated `output/` artifacts. Use `--keep` to preserve them.
- Use `--out <path>` to write the transformed code to a file instead of printing.

Code input:

```powershell
python -m discordbot fom --code "print('hi')"
python -m discordbot lint --trace off --code "local x=1"
```

REPL (Discord-like commands):

```powershell
python -m discordbot repl
```

Commands:

- `!fom <code|file>`
- `!coml <code|file>`
- `!rename <code|file>`
- `!codefix <code|file>`
- `!nocode <code|file>`
- `!deleteout <code|file>`
- `!outcode <code|file>`
- `!num <code|file>` (alias of `nmbun`)
- `!rrequire <code|file>`
- `!lint trace=on|off <code|file>`
- `!tracelint <code|file>`

## Discord Bot (Optional)

Install:

```powershell
pip install -r discordbot/requirements-discord.txt
```

Set token:

```powershell
$env:DISCORD_TOKEN="YOUR_TOKEN"
```

Or create `discordbot/.env`:

```text
DISCORD_TOKEN=YOUR_TOKEN
```

Discord settings:

- In the Discord Developer Portal, enable the privileged "Message Content Intent" for the bot (required for `!` prefix commands).

Run:

```powershell
python -m discordbot.discord_bot
```

Discord commands (prefix `!`):

- `!fom <code>` or attach `.lua`/`.luau`/`.txt`
- `!coml <code>` or attach `.lua`/`.luau`/`.txt`
- `!rename <code>` or attach `.lua`/`.luau`/`.txt`
- `!codefix <code>` or attach `.lua`/`.luau`/`.txt`
- `!nocode <code>` or attach `.lua`/`.luau`/`.txt`
- `!deleteout <code>` or attach `.lua`/`.luau`/`.txt`
- `!outcode <code>` or attach `.lua`/`.luau`/`.txt`
- `!num <code>` or attach `.lua`/`.luau`/`.txt` (alias: `!nmbun`)
- `!lint trace=on|off <code>` or attach `.lua`/`.luau`/`.txt`
- `!tracelint <code>` or attach `.lua`/`.luau`/`.txt`
- `!dep <code>` or attach `.lua`/`.luau`/`.txt` (alias: `!rrequire`)
