import asyncio
import io
import os
import re

from pathlib import Path

try:
    from dotenv import load_dotenv
except Exception:
    load_dotenv = None

if load_dotenv:
    load_dotenv()
try:
    from .luatool_runner import run_with_source
except Exception:
    from luatool_runner import run_with_source


def _extract_code(text: str) -> str | None:
    m = re.search(r"```(?:lua|luau)?\s*(.*?)```", text, flags=re.IGNORECASE | re.DOTALL)
    if m:
        return m.group(1)
    t = (text or "").strip()
    return t or None


def _is_trace_token(s: str) -> bool:
    return (s or "").lower().startswith("trace=")

def _load_env_file(path: Path) -> dict:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return {}
    out = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#"):
            continue
        if line.lower().startswith("export "):
            line = line[7:].strip()
        k, sep, v = line.partition("=")
        if not sep:
            continue
        key = k.strip()
        val = v.strip()
        if (val.startswith('"') and val.endswith('"')) or (val.startswith("'") and val.endswith("'")):
            val = val[1:-1]
        if key:
            out[key] = val
    return out


def _get_discord_token() -> str | None:
    tok = os.environ.get("DISCORD_TOKEN")
    if tok is None or not tok.strip():
        vals = _load_env_file(Path(__file__).resolve().parent / ".env")
        tok = vals.get("DISCORD_TOKEN")
    if tok is None:
        return None
    tok = tok.strip()
    if (tok.startswith('"') and tok.endswith('"')) or (tok.startswith("'") and tok.endswith("'")):
        tok = tok[1:-1].strip()
    if tok.lower().startswith("bot "):
        tok = tok[4:].strip()
    if not tok:
        return None
    return tok


async def main() -> None:
    try:
        import discord
        from discord.ext import commands
    except Exception as e:
        raise SystemExit(str(e))
    token = _get_discord_token()
    if not token:
        raise SystemExit("DISCORD_TOKEN is required")
    intents = discord.Intents.default()
    intents.message_content = True
    bot = commands.Bot(command_prefix="!", intents=intents)

    async def _send_code(ctx, text: str, filename: str) -> None:
        if "```" not in text and len(text) <= 1800:
            await ctx.reply(f"```lua\n{text}\n```")
            return
        data = text.encode("utf-8", errors="replace")
        await ctx.reply(file=discord.File(fp=io.BytesIO(data), filename=filename))

    async def _send_json(ctx, obj: dict, filename: str) -> None:
        data = (json_dumps(obj) + "\n").encode("utf-8", errors="replace")
        await ctx.reply(file=discord.File(fp=io.BytesIO(data), filename=filename))

    async def _send_text_file(ctx, text: str, filename: str) -> None:
        data = (text or "").encode("utf-8", errors="replace")
        await ctx.reply(file=discord.File(fp=io.BytesIO(data), filename=filename))

    def json_dumps(obj: dict) -> str:
        import json
        return json.dumps(obj, ensure_ascii=False, indent=2)

    async def _run(mode: str, source: str, name_hint: str, trace: str | None) -> dict:
        return await asyncio.to_thread(
            run_with_source,
            mode,
            source,
            name_hint=name_hint,
            lint_trace=trace,
            timeout_s=180,
            keep=False,
        )

    async def _cmd_fom(ctx, *, arg: str = "") -> None:
        source = None
        name_hint = "code.lua"
        if ctx.message.attachments:
            a = ctx.message.attachments[0]
            name_hint = a.filename or name_hint
            b = await a.read()
            source = b.decode("utf-8", errors="replace")
        else:
            source = _extract_code(arg)
        if not source:
            await ctx.reply("usage: !fom <code> or attach .lua/.luau/.txt")
            return
        r = await _run("fom", source, name_hint, None)
        if not r.get("ok"):
            await ctx.reply((r.get("stderr") or "failed").strip()[:1800])
            return
        out = r.get("output_code") or ""
        await _send_code(ctx, out, f"{PathSafe(name_hint).stem}.fom.lua")
    bot.command(name="fom")(_cmd_fom)

    async def _cmd_coml(ctx, *, arg: str = "") -> None:
        source = None
        name_hint = "code.lua"
        if ctx.message.attachments:
            a = ctx.message.attachments[0]
            name_hint = a.filename or name_hint
            b = await a.read()
            source = b.decode("utf-8", errors="replace")
        else:
            source = _extract_code(arg)
        if not source:
            await ctx.reply("usage: !coml <code> or attach .lua/.luau/.txt")
            return
        r = await _run("coml", source, name_hint, None)
        if not r.get("ok"):
            await ctx.reply((r.get("stderr") or "failed").strip()[:1800])
            return
        out = r.get("output_code") or ""
        await _send_code(ctx, out, f"{PathSafe(name_hint).stem}.coml.lua")
    bot.command(name="coml")(_cmd_coml)

    async def _cmd_rename(ctx, *, arg: str = "") -> None:
        source = None
        name_hint = "code.lua"
        if ctx.message.attachments:
            a = ctx.message.attachments[0]
            name_hint = a.filename or name_hint
            b = await a.read()
            source = b.decode("utf-8", errors="replace")
        else:
            source = _extract_code(arg)
        if not source:
            await ctx.reply("usage: !rename <code> or attach .lua/.luau/.txt")
            return
        r = await _run("rename", source, name_hint, None)
        if not r.get("ok"):
            await ctx.reply((r.get("stderr") or "failed").strip()[:1800])
            return
        out = r.get("output_code") or ""
        await _send_code(ctx, out, f"{PathSafe(name_hint).stem}.rename.lua")
    bot.command(name="rename")(_cmd_rename)

    async def _cmd_codefix(ctx, *, arg: str = "") -> None:
        source = None
        name_hint = "code.lua"
        if ctx.message.attachments:
            a = ctx.message.attachments[0]
            name_hint = a.filename or name_hint
            b = await a.read()
            source = b.decode("utf-8", errors="replace")
        else:
            source = _extract_code(arg)
        if not source:
            await ctx.reply("usage: !codefix <code> or attach .lua/.luau/.txt")
            return
        r = await _run("codefix", source, name_hint, None)
        if not r.get("ok"):
            await ctx.reply((r.get("stderr") or "failed").strip()[:1800])
            return
        out = r.get("output_code") or ""
        await _send_code(ctx, out, f"{PathSafe(name_hint).stem}.codefix.lua")
        rep = (r.get("reports") or {}).get("codefix")
        if isinstance(rep, dict):
            await _send_json(ctx, rep, f"{PathSafe(name_hint).name}.codefix.json")
    bot.command(name="codefix")(_cmd_codefix)

    async def _cmd_nocode(ctx, *, arg: str = "") -> None:
        source = None
        name_hint = "code.lua"
        if ctx.message.attachments:
            a = ctx.message.attachments[0]
            name_hint = a.filename or name_hint
            b = await a.read()
            source = b.decode("utf-8", errors="replace")
        else:
            source = _extract_code(arg)
        if not source:
            await ctx.reply("usage: !nocode <code> or attach .lua/.luau/.txt")
            return
        r = await _run("nocode", source, name_hint, None)
        if not r.get("ok"):
            await ctx.reply((r.get("stderr") or "failed").strip()[:1800])
            return
        out = r.get("output_code") or ""
        await _send_code(ctx, out, f"{PathSafe(name_hint).stem}.nocode.lua")
    bot.command(name="nocode")(_cmd_nocode)

    async def _cmd_deleteout(ctx, *, arg: str = "") -> None:
        source = None
        name_hint = "code.lua"
        if ctx.message.attachments:
            a = ctx.message.attachments[0]
            name_hint = a.filename or name_hint
            b = await a.read()
            source = b.decode("utf-8", errors="replace")
        else:
            source = _extract_code(arg)
        if not source:
            await ctx.reply("usage: !deleteout <code> or attach .lua/.luau/.txt")
            return
        r = await _run("deleteout", source, name_hint, None)
        if not r.get("ok"):
            await ctx.reply((r.get("stderr") or "failed").strip()[:1800])
            return
        out = r.get("output_code") or ""
        await _send_code(ctx, out, f"{PathSafe(name_hint).stem}.deleteout.lua")
    bot.command(name="deleteout")(_cmd_deleteout)

    async def _cmd_outcode(ctx, *, arg: str = "") -> None:
        source = None
        name_hint = "code.lua"
        if ctx.message.attachments:
            a = ctx.message.attachments[0]
            name_hint = a.filename or name_hint
            b = await a.read()
            source = b.decode("utf-8", errors="replace")
        else:
            source = _extract_code(arg)
        if not source:
            await ctx.reply("usage: !outcode <code> or attach .lua/.luau/.txt")
            return
        r = await _run("outcode", source, name_hint, None)
        if not r.get("ok"):
            await ctx.reply((r.get("stderr") or "failed").strip()[:1800])
            return
        out = r.get("output_code") or ""
        await _send_code(ctx, out, f"{PathSafe(name_hint).stem}.outcode.lua")
    bot.command(name="outcode")(_cmd_outcode)

    async def _cmd_num(ctx, *, arg: str = "") -> None:
        source = None
        name_hint = "code.lua"
        if ctx.message.attachments:
            a = ctx.message.attachments[0]
            name_hint = a.filename or name_hint
            b = await a.read()
            source = b.decode("utf-8", errors="replace")
        else:
            source = _extract_code(arg)
        if not source:
            await ctx.reply("usage: !num <code> or attach .lua/.luau/.txt")
            return
        r = await _run("nmbun", source, name_hint, None)
        if not r.get("ok"):
            await ctx.reply((r.get("stderr") or "failed").strip()[:1800])
            return
        out = r.get("output_code") or ""
        await _send_code(ctx, out, f"{PathSafe(name_hint).stem}.num.lua")
    bot.command(name="num", aliases=["nmbun"])(_cmd_num)

    async def _cmd_lint(ctx, *, arg: str = "") -> None:
        trace = "on"
        rest = (arg or "").strip()
        if rest:
            first, _, after = rest.partition(" ")
            if _is_trace_token(first):
                trace = first.split("=", 1)[1].strip().lower() or "on"
                rest = after.strip()
        source = None
        name_hint = "code.lua"
        if ctx.message.attachments:
            a = ctx.message.attachments[0]
            name_hint = a.filename or name_hint
            b = await a.read()
            source = b.decode("utf-8", errors="replace")
        else:
            source = _extract_code(rest)
        if not source:
            await ctx.reply("usage: !lint trace=on|off <code> or attach .lua/.luau/.txt")
            return
        r = await _run("lint", source, name_hint, trace)
        if not r.get("ok"):
            await ctx.reply((r.get("stderr") or "failed").strip()[:1800])
            return
        rep = (r.get("reports") or {}).get("lint")
        if isinstance(rep, dict):
            res = rep.get("result") or {}
            summary = res.get("summary") or {}
            total = summary.get("total", 0)
            err = summary.get("error", 0)
            warn = summary.get("warning", 0)
            info = summary.get("info", 0)
            ok = res.get("ok")
            await ctx.reply(f"ok: {ok} summary: total={total} error={err} warning={warn} info={info}")
            await _send_json(ctx, rep, f"{PathSafe(name_hint).name}.lint.json")
    bot.command(name="lint")(_cmd_lint)

    async def _cmd_tracelint(ctx, *, arg: str = "") -> None:
        source = None
        name_hint = "code.lua"
        if ctx.message.attachments:
            a = ctx.message.attachments[0]
            name_hint = a.filename or name_hint
            b = await a.read()
            source = b.decode("utf-8", errors="replace")
        else:
            source = _extract_code(arg)
        if not source:
            await ctx.reply("usage: !tracelint <code> or attach .lua/.luau/.txt")
            return
        r = await _run("tracelint", source, name_hint, None)
        if not r.get("ok"):
            await ctx.reply((r.get("stderr") or "failed").strip()[:1800])
            return
        rep = (r.get("reports") or {}).get("tracelint")
        if isinstance(rep, dict):
            res = rep.get("result") or {}
            ok = res.get("ok")
            phase = res.get("phase", "runtime")
            timeout = res.get("timeout", False)
            dur = res.get("duration_ms", 0)
            err = res.get("error")
            out = res.get("output") or {}
            items = out.get("items") or []
            omitted = out.get("omitted", 0)
            msg = f"ok: {ok} phase: {phase} timeout: {timeout} duration_ms: {dur} output_items: {len(items)} omitted: {omitted}"
            if err:
                msg = msg + f"\nerror: {err}"
            await ctx.reply(msg[:1800])
            await _send_json(ctx, rep, f"{PathSafe(name_hint).name}.tracelint.json")
        artifacts = r.get("artifacts") or {}
        log_text = artifacts.get("tracelint_log")
        if isinstance(log_text, str) and log_text.strip():
            await _send_text_file(ctx, log_text, f"{PathSafe(name_hint).name}.tracelint.log")
    bot.command(name="tracelint", aliases=["trace"])(_cmd_tracelint)

    async def _cmd_deobf(ctx, *, arg: str = "") -> None:
        trace = "off"
        rest = (arg or "").strip()
        if rest:
            first, _, after = rest.partition(" ")
            if _is_trace_token(first):
                trace = first.split("=", 1)[1].strip().lower() or "off"
                rest = after.strip()
        source = None
        name_hint = "code.lua"
        if ctx.message.attachments:
            a = ctx.message.attachments[0]
            name_hint = a.filename or name_hint
            b = await a.read()
            source = b.decode("utf-8", errors="replace")
        else:
            source = _extract_code(rest)
        if not source:
            await ctx.reply("usage: !deobf trace=on|off <code> or attach .lua/.luau/.txt")
            return
        r = await _run("deobf", source, name_hint, trace)
        if not r.get("ok"):
            await ctx.reply((r.get("stderr") or "failed").strip()[:1800])
            return
        out = r.get("output_code") or ""
        await _send_text_file(ctx, out, f"{PathSafe(name_hint).stem}.deobf.lua")
    bot.command(name="deobf")(_cmd_deobf)

    async def _cmd_dep(ctx, *, arg: str = "") -> None:
        source = None
        name_hint = "code.lua"
        if ctx.message.attachments:
            a = ctx.message.attachments[0]
            name_hint = a.filename or name_hint
            b = await a.read()
            source = b.decode("utf-8", errors="replace")
        else:
            source = _extract_code(arg)
        if not source:
            await ctx.reply("usage: !dep <code> or attach .lua/.luau/.txt")
            return
        r = await _run("rrequire", source, name_hint, None)
        if not r.get("ok"):
            await ctx.reply((r.get("stderr") or "failed").strip()[:1800])
            return
        rep = (r.get("reports") or {}).get("rrequire")
        if isinstance(rep, dict):
            res = rep.get("result") or {}
            summary = res.get("summary") or {}
            files = summary.get("files", 0)
            edges = summary.get("edges", 0)
            unresolved = summary.get("unresolved", 0)
            dynamic = summary.get("dynamic", 0)
            parse_errors = summary.get("parse_errors", 0)
            await ctx.reply(f"summary: files={files} edges={edges} unresolved={unresolved} dynamic={dynamic} parse_errors={parse_errors}")
            await _send_json(ctx, rep, f"{PathSafe(name_hint).name}.rrequire.json")
    bot.command(name="dep", aliases=["rrequire"])(_cmd_dep)

    async def _cmd_info2(ctx, *, arg: str = "") -> None:
        try:
            info_file = Path(__file__).resolve().parent.parent / "info.txt"
            if not info_file.exists():
                await ctx.reply("info.txt not found")
                return
            text = info_file.read_text(encoding="utf-8", errors="replace")
            await _send_text_file(ctx, text, "info.txt")
        except Exception as e:
            await ctx.reply(f"error: {str(e)[:500]}")
    bot.command(name="info2", aliases=["luainfo2"])(_cmd_info2)

    class PathSafe:
        def __init__(self, name: str):
            import pathlib
            self._p = pathlib.Path(name or "code.lua").name
            if not self._p:
                self._p = "code.lua"
            ext = (pathlib.Path(self._p).suffix or "").lower()
            if ext not in {".lua", ".luau", ".txt"}:
                if ext:
                    self._p = pathlib.Path(self._p).stem + ".lua"
                else:
                    self._p = self._p + ".lua"
        @property
        def name(self) -> str:
            return self._p
        @property
        def stem(self) -> str:
            import pathlib
            return pathlib.Path(self._p).stem or "code"

    try:
        await bot.start(token)
    except discord.LoginFailure as e:
        raise SystemExit("Discord token is invalid. Reset the Bot token in the Developer Portal and update DISCORD_TOKEN.") from e
    finally:
        try:
            await bot.close()
        except Exception:
            pass


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
