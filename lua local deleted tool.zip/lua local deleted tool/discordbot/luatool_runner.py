import json
import re
import subprocess
import uuid
import glob
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
_ALLOWED_EXTS = {".lua", ".luau", ".txt"}


def _sanitize_filename(name: str) -> str:
    base = Path(name or "").name.strip()
    if not base:
        base = "code.lua"
    p = Path(base)
    ext = (p.suffix or "").lower()
    if ext not in _ALLOWED_EXTS:
        if ext:
            base = p.stem + ".lua"
        else:
            base = base + ".lua"
    base = re.sub(r"[^A-Za-z0-9._-]+", "_", base)
    if base in {".", ".."}:
        base = "code.lua"
    if len(base) > 80:
        stem = Path(base).stem[:60]
        base = stem + ".lua"
    return base


def _make_temp_input(source: str, name_hint: str) -> Path:
    safe = _sanitize_filename(name_hint)
    stem = Path(safe).stem
    ext = Path(safe).suffix or ".lua"
    tmp_name = f".tmp_{stem}_{uuid.uuid4().hex}{ext}"
    path = ROOT / tmp_name
    path.write_text(source or "", encoding="utf-8", errors="replace")
    return path


def _read_text(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None


def _read_json(path: Path) -> dict | None:
    text = _read_text(path)
    if text is None:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def run_with_source(
    mode: str,
    source: str,
    *,
    name_hint: str = "code.lua",
    lint_trace: str | None = None,
    timeout_s: int = 120,
    keep: bool = False,
) -> dict:
    tmp_input = _make_temp_input(source, name_hint)
    output_dir = ROOT / "output"
    if mode == "deobf":
        out_code_path = output_dir / (tmp_input.name + ".deobf.unlocked.folded.lua")
        deobf_report_path = output_dir / (tmp_input.name + ".deobf.json")
    else:
        out_code_path = output_dir / tmp_input.name
        deobf_report_path = None
    
    safety_path = output_dir / (tmp_input.name + ".safety.json")
    lint_path = output_dir / (tmp_input.name + ".lint.json")
    rrequire_path = output_dir / (tmp_input.name + ".rrequire.json")
    codefix_path = output_dir / (tmp_input.name + ".codefix.json")
    tracelint_path = output_dir / (tmp_input.name + ".tracelint.json")
    tracelint_log_path = output_dir / (tmp_input.name + ".tracelint.log")
    args = ["lua54", "main.lua", mode]
    if mode == "lint" and lint_trace:
        v = lint_trace.strip().lower()
        if v in {"on", "true", "1"}:
            args.append("-on")
        elif v in {"off", "false", "0"}:
            args.append("-off")
    if mode == "deobf" and lint_trace:
        v = lint_trace.strip().lower()
        if v in {"on", "true", "1"}:
            args.append("-trace=on")
        elif v in {"off", "false", "0"}:
            args.append("-trace=off")
    args.append(tmp_input.name)
    try:
        proc = subprocess.run(
            args,
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=timeout_s,
        )
    except subprocess.TimeoutExpired:
        if not keep:
            try:
                tmp_input.unlink()
            except OSError:
                pass
        return {
            "ok": False,
            "mode": mode,
            "timeout": True,
            "returncode": None,
            "stdout": "",
            "stderr": f"timeout after {timeout_s}s",
            "output_code": None,
            "reports": {},
            "tmp_input": str(tmp_input),
        }
    reports = {}
    artifacts = {}
    safety = _read_json(safety_path)
    if isinstance(safety, dict):
        reports["safety"] = safety
    lint = _read_json(lint_path)
    if isinstance(lint, dict):
        reports["lint"] = lint
    rrequire = _read_json(rrequire_path)
    if isinstance(rrequire, dict):
        reports["rrequire"] = rrequire
    codefix = _read_json(codefix_path)
    if isinstance(codefix, dict):
        reports["codefix"] = codefix
    tracelint = _read_json(tracelint_path)
    if isinstance(tracelint, dict):
        reports["tracelint"] = tracelint
    if deobf_report_path:
        deobf = _read_json(deobf_report_path)
        if isinstance(deobf, dict):
            reports["deobf"] = deobf
    tracelint_log = _read_text(tracelint_log_path)
    if isinstance(tracelint_log, str):
        artifacts["tracelint_log"] = tracelint_log
    output_code = _read_text(out_code_path)
    result = {
        "ok": proc.returncode == 0 and output_code is not None,
        "mode": mode,
        "timeout": False,
        "returncode": proc.returncode,
        "stdout": proc.stdout or "",
        "stderr": proc.stderr or "",
        "output_code": output_code,
        "reports": reports,
        "artifacts": artifacts,
        "tmp_input": str(tmp_input),
    }
    if not keep:
        import glob
        try:
            pattern = str(output_dir / f"{tmp_input.name}*")
            for p_str in glob.glob(pattern):
                try:
                    Path(p_str).unlink()
                except OSError:
                    pass
        except Exception:
            pass
        try:
            tmp_input.unlink()
        except OSError:
            pass
    return result


def run_with_file(
    mode: str,
    file_path: str,
    *,
    lint_trace: str | None = None,
    timeout_s: int = 120,
    keep: bool = False,
) -> dict:
    input_path = Path(file_path)
    output_dir = ROOT / "output"
    filename = input_path.name
    if mode == "deobf":
        out_code_path = output_dir / (filename + ".deobf.unlocked.folded.lua")
        deobf_report_path = output_dir / (filename + ".deobf.json")
    else:
        out_code_path = output_dir / filename
        deobf_report_path = None
    
    safety_path = output_dir / (filename + ".safety.json")
    lint_path = output_dir / (filename + ".lint.json")
    rrequire_path = output_dir / (filename + ".rrequire.json")
    codefix_path = output_dir / (filename + ".codefix.json")
    tracelint_path = output_dir / (filename + ".tracelint.json")
    tracelint_log_path = output_dir / (filename + ".tracelint.log")
    args = ["lua54", "main.lua", mode]
    if mode == "lint" and lint_trace:
        v = lint_trace.strip().lower()
        if v in {"on", "true", "1"}:
            args.append("-on")
        elif v in {"off", "false", "0"}:
            args.append("-off")
    if mode == "deobf" and lint_trace:
        v = lint_trace.strip().lower()
        if v in {"on", "true", "1"}:
            args.append("-trace=on")
        elif v in {"off", "false", "0"}:
            args.append("-trace=off")
    args.append(str(input_path))
    try:
        proc = subprocess.run(
            args,
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=timeout_s,
        )
    except subprocess.TimeoutExpired:
        return {
            "ok": False,
            "mode": mode,
            "timeout": True,
            "returncode": None,
            "stdout": "",
            "stderr": f"timeout after {timeout_s}s",
            "output_code": None,
            "reports": {},
            "tmp_input": str(input_path),
        }
    reports = {}
    artifacts = {}
    safety = _read_json(safety_path)
    if isinstance(safety, dict):
        reports["safety"] = safety
    lint = _read_json(lint_path)
    if isinstance(lint, dict):
        reports["lint"] = lint
    rrequire = _read_json(rrequire_path)
    if isinstance(rrequire, dict):
        reports["rrequire"] = rrequire
    codefix = _read_json(codefix_path)
    if isinstance(codefix, dict):
        reports["codefix"] = codefix
    tracelint = _read_json(tracelint_path)
    if isinstance(tracelint, dict):
        reports["tracelint"] = tracelint
    if deobf_report_path:
        deobf = _read_json(deobf_report_path)
        if isinstance(deobf, dict):
            reports["deobf"] = deobf
    tracelint_log = _read_text(tracelint_log_path)
    if isinstance(tracelint_log, str):
        artifacts["tracelint_log"] = tracelint_log
    output_code = _read_text(out_code_path)
    result = {
        "ok": proc.returncode == 0 and output_code is not None,
        "mode": mode,
        "timeout": False,
        "returncode": proc.returncode,
        "stdout": proc.stdout or "",
        "stderr": proc.stderr or "",
        "output_code": output_code,
        "reports": reports,
        "artifacts": artifacts,
        "tmp_input": str(input_path),
    }
    if not keep:
        import glob
        try:
            pattern = str(output_dir / f"{filename}*")
            for p_str in glob.glob(pattern):
                try:
                    Path(p_str).unlink()
                except OSError:
                    pass
        except Exception:
            pass
    return result
