return (function(s, H, B, I, A, E, q, W, M, l, i, Z, d, x, c, m,
    J, o)
    Z, m, c, W, x, l, M, J, d, o, i = function(s, H)
        local B = W(H)
        local I = function(I)
            return M(s, { I }, H, B)
        end
        return I
    end, {}, function(s)
        J[s] = J[s] - 1
        if 0 == J[s] then
            J[s], m[s] = nil, nil
        end
    end, function(s)
        for M = 1, #s, 1 do
            J[s[M]] = J[s[M]] + 1
        end
        if B then
            local M = B(true)
            local H = A(M)
            H.__index, H.__gc, H.__len = s, o, function()
                return -535009
            end
            return M
        else
            return I({}, {
                __gc = o,
                __index = s,
                __len = function()
                    return -535009
                end
            })
        end
    end, 0, function(s, H)
        local B = W(H)
        local I = function(I, A, E)
            return M(s, { I, A, E }, H, B)
        end
        return I
    end, function(M, B, I, A)
        local d, i, u, m, W, J, q, x, X, c, o
        while M do
            if M < 12956150 then
                if M < 8350289 then
                    W = "HttpGet"
                    x = "https://raw.githubusercontent.com/jadpy/suki/refs/heads/main/orion"
                    J = "game"
                    q = "loadstring"
                    M = s[q]
                    o = false
                    i = s[J]
                    W = i[W]
                    m = B
                    J = { W(i, x) }
                    X = "ConfigFolder"
                    u = "poophub_ui"
                    q = M(H(J))
                    x = "poophub.ui"
                    M = q()
                    J = "Name"
                    d = false
                    c = "SaveConfig"
                    i = M
                    W = "HidePremium"
                    q = { [J] = x, [W] = o, [c] = d, [X] = u }
                    M = "MakeWindow"
                    d = "PremiumOnly"
                    M = i[M]
                    o = "Icon"
                    x = "Name"
                    W = "poophub"
                    M = M(i, q)
                    X = false
                    J = M
                    c = "rbxassetid://4483345998"
                    q = { [x] = W, [o] = c, [d] = X }
                    M = "MakeTab"
                    c = "Callback"
                    M = J[M]
                    W = "Name"
                    M = M(J, q)
                    x = M
                    o = "PoophubES"
                    d = l(12233074, {})
                    q = { [W] = o, [c] = d }
                    W = "Name"
                    d = Z(15042152, {})
                    M = "AddButton"
                    M = x[M]
                    J = nil
                    M = M(x, q)
                    M = "AddButton"
                    c = "Callback"
                    o = "PoophubJP"
                    M = x[M]
                    q = { [W] = o, [c] = d }
                    M = M(x, q)
                    M = "Init"
                    M = i[M]
                    x = nil
                    M = M(i)
                    q = {}
                    M = s.joU6gFaXHlxF
                    i = nil
                else
                    q = "loadstring"
                    x = "HttpGet"
                    J = "https://raw.githubusercontent.com/jadpy/poophub/refs/heads/main/poophubsub"
                    M = s[q]
                    i = "game"
                    m = s[i]
                    x = m[x]
                    i = { x(m, J) }
                    q = M(H(i))
                    M = q()
                    M = s.USq9MWcVYG7EUA
                    q = {}
                end
            else
                i = "game"
                q = "loadstring"
                M = s[q]
                m = s[i]
                J = "https://raw.githubusercontent.com/jadpy/poophub/refs/heads/main/PoophubJP"
                x = "HttpGet"
                x = m[x]
                i = { x(m, J) }
                q = M(H(i))
                M = q()
                q = {}
                M = s.nmwkcG0YJvMB
            end
        end
        M = #A
        return H(q)
    end, {}, function(s, H)
        local B = W(H)
        local I = function(...)
            return M(s, { ... }, H, B)
        end
        return I
    end, function(s)
        local M, H = 1, s[1]
        while H do
            J[H], M = J[H] - 1, 1 + M
            if 0 == J[H] then
                J[H], m[H] = nil, nil
            end
            H = s[M]
        end
    end, function()
        x = 1 + x
        J[x] = 1
        return x
    end
    return (d(3842590, {}))(H(q))
end)(getfenv and getfenv() or _ENV, unpack or table.unpack, newproxy,
    setmetatable, getmetatable, select, { ... })