-- binary decoded strings
-- Generated at: 2026-02-13T05:57:05Z
-- Entries: 1

return {
  {
    origin = "base64",
    codec = "std",
    encoded = "ConfigFolder",
    bytes = 9,
    hex = "0A 89 DF 8A 01 68 95 D7 AB",
    decoded = "\n\137\223\138\001h\149\215\171",
  },
}