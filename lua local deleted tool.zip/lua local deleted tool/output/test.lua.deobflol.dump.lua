-- Runtime capture dump (trace)
-- Generated at: 2026-02-13T05:57:05Z
-- This file stores captured runtime chunks as strings for analysis.

local dump = {
  runtime_chunks = {},
  runtime_chunks_dropped = 0,
  text_captures = {},
  text_captures_dropped = 0,
}


dump.runtime_chunks_dropped = 0
dump.text_captures_dropped = 0

return dump