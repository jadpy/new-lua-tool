#!/usr/bin/env lua

local Lexer = require('src.lexer')
local Parser = require('src.parser')
local Analyzer = require('src.analyzer')
local Transformer = require('src.transformer')
local CodeGen = require('src.codegen')
local TransformerLine = require('src.transformer_line')
local Formatter = require('src.formatter')
local Compressor = require('src.compressor')
local Nmbun = require('src.nmbun')
local Renamer = require('src.renamer')
local DeleteOut = require('src.deleteout')
local NoCode = require('src.nocode')
local CodeFix = require('src.codefix')
local Deobf = require('src.deobf.runner')
local Linter = require('src.linter')
local RRequire = require('src.rrequire')
local Safety = require('src.safety')
local TraceLint = require('src.tracelint')
local Json = require('src.json')
local Preset = require('src.preset')
local Dialect = require('src.dialect')

function read_file(filepath)
  local file = io.open(filepath, 'rb')
  if not file then
    error('Cannot open file: ' .. filepath)
  end
  local content = file:read('*a')
  file:close()
  return content
end

function write_file(filepath, content)
  local file = io.open(filepath, 'wb')
  if not file then
    error('Cannot write file: ' .. filepath)
  end
  file:write(content)
  file:close()
end

function ensure_dir(dirpath)
  os.execute('if not exist "' .. dirpath .. '" mkdir "' .. dirpath .. '"')
end

function process_file(input_filepath, mode, engine, options)
  options = options or {}
  local dialect = Dialect.resolve(options.dialect)
  local source = read_file(input_filepath)
  local pre_analysis = nil
  if mode ~= 'deobf' then
    pre_analysis = Safety.analyze_source(source, { dialect = dialect.name })
  end
  local function finalize(output_code, analyzer, meta)
    local guarded_output, safety_report = Safety.guard(mode, source, output_code, pre_analysis, { dialect = dialect.name })
    local final_meta = meta or {}
    final_meta.extra_reports = final_meta.extra_reports or {}
    final_meta.extra_reports[#final_meta.extra_reports + 1] = {
      suffix = '.safety.json',
      data = safety_report
    }
    return guarded_output, analyzer or { all_locals = {} }, final_meta
  end

  if mode == 'fom' then
    local output_code = Formatter.format(source, { dialect = dialect.name })
    local analyzer = { all_locals = {} }
    return finalize(output_code, analyzer)
  elseif mode == 'coml' then
    local output_code = Compressor.compress(source, { dialect = dialect.name })
    local analyzer = { all_locals = {} }
    return finalize(output_code, analyzer)
  elseif mode == 'nmbun' then
    local output_code, analyzer = Nmbun.run(source, { dialect = dialect.name })
    return finalize(output_code, analyzer)
  elseif mode == 'rename' then
    local output_code, analyzer = Renamer.rename(source, { dialect = dialect.name })
    return finalize(output_code, analyzer)
  elseif mode == 'deleteout' then
    local output_code = DeleteOut.strip(source, { dialect = dialect.name })
    local analyzer = { all_locals = {} }
    return finalize(output_code, analyzer)
  elseif mode == 'nocode' then
    local output_code, analyzer = NoCode.clean(source, { dialect = dialect.name })
    return finalize(output_code, analyzer)
  elseif mode == 'codefix' then
    local output_code, analyzer, meta = CodeFix.run(source, {
      dialect = dialect.name,
      reasoning = options.codefix_reasoning,
      memory = options.codefix_memory,
      lua_specialized = options.codefix_lua_specialized,
      ai_max_depth = options.codefix_depth,
      ai_beam_width = options.codefix_beam,
      ai_attempt_limit = options.codefix_attempt
    })
    return finalize(output_code, analyzer, meta)
  elseif mode == 'deobf' then
    local output_code, analyzer, meta = Deobf.run(source, {
      dialect = dialect.name,
      trace = options.deobf_trace == true,
      unlock_rewrite_table_literals = options.deobf_unlock_table == true,
      readable_output = options.deobf_readable ~= false
    })
    local final_meta = meta or {}
    final_meta.extra_reports = final_meta.extra_reports or {}
    local before_state = final_meta.report_data and final_meta.report_data.before or {}
    local after_state = final_meta.report_data and final_meta.report_data.after or {}
    final_meta.extra_reports[#final_meta.extra_reports + 1] = {
      suffix = '.safety.json',
      data = {
        type = 'safety-report',
        mode = 'deobf',
        dialect = dialect.name,
        generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        before = before_state,
        after = after_state,
        fallback_applied = false,
        fallback_reason = nil
      }
    }
    return output_code, analyzer or { all_locals = {} }, final_meta
  elseif mode == 'lint' then
    local result = Linter.run(source, {
      dialect = dialect.name,
      dynamic = options.lint_dynamic ~= false
    })
    local analyzer = { all_locals = {} }
    return finalize(source, analyzer, {
      report_data = {
        type = 'lint-report',
        file = input_filepath,
        generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        result = result
      },
      report_suffix = '.lint.json',
      lint_summary = result.summary
    })
  elseif mode == 'rrequire' then
    local result = RRequire.analyze(input_filepath, { dialect = dialect.name })
    local analyzer = { all_locals = {} }
    return finalize(source, analyzer, {
      report_data = {
        type = 'rrequire-report',
        file = input_filepath,
        generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        result = result
      },
      report_suffix = '.rrequire.json',
      rrequire_summary = result.summary
    })
  elseif mode == 'tracelint' then
    local result, log_text = TraceLint.run(source, {
      dialect = dialect.name
    })
    local analyzer = { all_locals = {} }
    return finalize(source, analyzer, {
      report_data = {
        type = 'tracelint-report',
        file = input_filepath,
        generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        result = result
      },
      report_suffix = '.tracelint.json',
      extra_outputs = {
        {
          suffix = '.tracelint.log',
          content = log_text or ''
        }
      }
    })
  elseif mode == 'preset' then
    local preset_file = 'preset.json'
    if options and options.preset_file and options.preset_file ~= '' then
      preset_file = options.preset_file
    end
    local output_code, analyzer, meta = Preset.run(input_filepath, preset_file, engine, {
      dialect = dialect.name,
      lint_dynamic = options.lint_dynamic ~= false
    })
    return finalize(output_code, analyzer, meta)
  end
  local lexer = Lexer.new(source, { dialect = dialect.name })
  local tokens = lexer:tokenize()

  if engine == 'line' then
    local transformer = TransformerLine.new(source, tokens, { mode = mode, dialect = dialect.name })
    local output_code = transformer:apply()
    local analyzer = { all_locals = {} }
    return finalize(output_code, analyzer)
  end

  local parser = Parser.new(tokens, { dialect = dialect.name })
  local ast = parser:parse()

  local analyzer = Analyzer.new()
  analyzer:analyze(ast)

  local transformer = Transformer.new({ mode = mode })
  local transformed_ast = transformer:transform(ast)

  local codegen = CodeGen.new(source)
  local output_code = codegen:generate(transformed_ast)

  return finalize(output_code, analyzer)
end

function show_usage()
  print('Usage:')
  print('  lua54 main.lua [--engine=line|ast] [--lint-dynamic=on|off] <mode> [scope] <inputfile> [presetfile]')
  print()
  print('Modes:')
  print('  functionlocal        - Remove `local` from function declarations (`local function` or `local name = function`)')
  print('  localkw [scope]      - Remove only "local" keyword (preserve scope)')
  print('  localte <scope>      - Remove "local" from boolean assignments')
  print('  localc <scope>       - Remove "local" from string assignments')
  print('  localcyt [scope]     - Remove "local" for string assignments (alias of localc; default: both scopes)')
  print('  localnum [scope]     - Remove "local" from number assignments (default: both scopes)')
  print('  localtabke [scope]   - Remove "local" from table assignments (default: both scopes)')
  print('  outcode              - Remove commented-out code blocks/lines')
  print('  deleteout            - Remove all comments (-- and --[[ ]]) with safer token boundaries')
  print('  nocode               - Remove unused local code with conservative side-effect safety checks')
  print('  codefix              - Auto-detect and auto-fix common syntax breakage with validation report')
  print('  deobf                - Execute in hardened sandbox and extract in-memory Lua chunks')
  print('  fom                  - Format code (Luau/Lua 5.1 aware, AST-based indentation)')
  print('  coml                 - Compress to one line with constant folding, dead code removal, and safety checks')
  print('  nmbun                - Fold numeric/string/boolean expressions and output simplified result')
  print('  rename               - Randomly rename local variables/params with collision-safe short names')
  print('  lint                 - Static + dynamic analysis with JSON report output')
  print('  rrequire             - Analyze require dependency graph with JSON report output')
  print('  tracelint            - Execute code in hardened Roblox-style sandbox and output runtime trace + logs')
  print('  preset               - Run multi-step pipeline from pretty JSON preset file')
  print()
  print('Scope options (for localkw):')
  print('  function             - Remove "local" from function scope only')
  print('  global               - Remove "local" from global scope only')
  print('  (default: both)      - Remove "local" from both scopes')
  print()
  print('Scope options (for localte/localc/localcyt/localnum):')
  print('  function             - Remove "local" from function assignments')
  print('  global               - Remove "local" from global assignments')
  print()
  print('Lint dynamic options:')
  print('  --lint-dynamic=on    - run sandboxed runtime lint checks (default)')
  print('  --lint-dynamic=off   - static lint only')
  print('  lint -on/-off        - per-command override for lint dynamic checks')
  print()
  print('Codefix AI options:')
  print('  --cf-reasoning=basic|high|max')
  print('  --cf-memory=tiny|low|balanced|high')
  print('  --cf-lua=on|off      - Lua/Luau specialized inference')
  print('  --cf-depth=N         - override AI search depth')
  print('  --cf-beam=N          - override AI beam width')
  print('  --cf-attempt=N       - override AI attempt cap')
  print()
  print('Deobf options:')
  print('  -trace=on|off        - include detailed sandbox/runtime traces in deobf report')
  print('  -unlock-table=on|off - rewrite primary string table literals to decoded strings (readability)')
  print('  -readable=on|off     - also emit a readability-focused formatted output')
  print()
  print('Examples:')
  print('  lua main.lua coml test.lua')
  print('  lua main.lua lint test.lua')
  print('  lua main.lua --lint-dynamic=off lint test.lua')
  print('  lua main.lua functionlocal test.lua')
  print('  lua main.lua functionlocal function test.lua')
  print('  lua main.lua functionlocal global test.lua')
  print('  lua main.lua localkw test.lua')
  print('  lua main.lua localkw function test.lua')
  print('  lua main.lua localte global test.lua')
  print('  lua main.lua localc function test.lua')
  print('  lua main.lua localcyt test.lua')
  print('  lua main.lua localnum test.lua')
  print('  lua main.lua deleteout test.lua')
  print('  lua main.lua nocode test.lua')
  print('  lua main.lua codefix test.lua')
  print('  lua main.lua codefix --cf-reasoning=max --cf-memory=low test.lua')
  print('  lua main.lua codefix --cf-depth=6 --cf-beam=10 test.lua')
  print('  lua main.lua deobf -trace=off test.lua')
  print('  lua main.lua deobf -trace=on test.lua')
  print('  lua main.lua nmbun test.lua')
  print('  lua main.lua rename test.lua')
  print('  lua main.lua lint test.lua')
  print('  lua main.lua lint -off test.lua')
  print('  lua main.lua lint -on test.lua')
  print('  lua main.lua rrequire test.lua')
  print('  lua main.lua tracelint test.lua')
  print('  lua main.lua preset test.lua')
  print('  lua main.lua preset test.lua preset.json')
end

function main()
  local raw_args = arg
  local args = {}
  local engine = 'line'
  local dialect = 'auto'
  local lint_dynamic = true
  local codefix_reasoning = 'high'
  local codefix_memory = 'low'
  local codefix_lua_specialized = true
  local codefix_depth = nil
  local codefix_beam = nil
  local codefix_attempt = nil
  local deobf_trace = false
  local deobf_unlock_table = false
  local deobf_readable = true
  local idx = 1

  while idx <= #raw_args do
    local opt = raw_args[idx]
    if opt and opt:match('^%-%-engine=') then
      engine = opt:match('^%-%-engine=(.+)')
      idx = idx + 1
    elseif opt and opt:match('^%-%-dialect=') then
      idx = idx + 1
    elseif opt and opt:match('^%-%-lint%-dynamic=') then
      local v = (opt:match('^%-%-lint%-dynamic=(.+)') or ''):lower()
      lint_dynamic = (v == 'on' or v == 'true' or v == '1' or v == '')
      idx = idx + 1
    else
      break
    end
  end

  for i = idx, #raw_args do table.insert(args, raw_args[i]) end

  if #args < 1 then
    show_usage()
    return
  end

  local mode_name = args[1]
  local scope = nil
  local input_file = nil
  local preset_file = nil
  
  if mode_name == 'functionlocal' then
    if #args == 1 then
      show_usage()
      return
    end

    if #args >= 3 then
      local potential_scope = args[2]
      if potential_scope == 'function' or potential_scope == 'global' then
        scope = potential_scope
        input_file = args[3]
      else
        input_file = args[2]
      end
    else
      input_file = args[2]
    end
  elseif mode_name == 'localkw' then
    if #args == 1 then
      show_usage()
      return
    end
    
    if #args >= 3 then
      local potential_scope = args[2]
      if potential_scope == 'function' or potential_scope == 'global' then
        scope = potential_scope
        input_file = args[3]
      else
        input_file = args[2]
      end
    else
      input_file = args[2]
    end
  elseif mode_name == 'localcyt' then
    if #args == 1 then
      show_usage()
      return
    end

    if #args >= 3 then
      local potential_scope = args[2]
      if potential_scope == 'function' or potential_scope == 'global' then
        scope = potential_scope
        input_file = args[3]
      else
        input_file = args[2]
      end
    else
      input_file = args[2]
    end
  elseif mode_name == 'localnum' then
    if #args == 1 then
      show_usage()
      return
    end

    if #args >= 3 then
      local potential_scope = args[2]
      if potential_scope == 'function' or potential_scope == 'global' then
        scope = potential_scope
        input_file = args[3]
      else
        input_file = args[2]
      end
    else
      input_file = args[2]
    end
  elseif mode_name == 'localtur' then
    if #args == 1 then
      show_usage()
      return
    end

    if #args >= 3 then
      local potential_scope = args[2]
      if potential_scope == 'function' or potential_scope == 'global' then
        scope = potential_scope
        input_file = args[3]
      else
        input_file = args[2]
      end
    else
      input_file = args[2]
    end
  elseif mode_name == 'localte' then
    if #args < 3 then
      show_usage()
      return
    end
    scope = args[2]
    if scope ~= 'function' and scope ~= 'global' then
      show_usage()
      return
    end
    input_file = args[3]
  elseif mode_name == 'localc' then
    if #args < 3 then
      show_usage()
      return
    end
    scope = args[2]
    if scope ~= 'function' and scope ~= 'global' then
      show_usage()
      return
    end
    input_file = args[3]
  elseif mode_name == 'localtabke' then
    if #args == 1 then
      show_usage()
      return
    end
    
    if #args >= 3 then
      local potential_scope = args[2]
      if potential_scope == 'function' or potential_scope == 'global' then
        scope = potential_scope
        input_file = args[3]
      else
        input_file = args[2]
      end
    else
      input_file = args[2]
    end
  elseif mode_name == 'outcode' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'deleteout' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'nocode' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'codefix' then
    if #args == 1 then show_usage(); return end
    local i = 2
    while i <= #args do
      local tok = args[i]
      if tok:match('^%-%-cf%-reasoning=') then
        codefix_reasoning = (tok:match('^%-%-cf%-reasoning=(.+)') or codefix_reasoning):lower()
      elseif tok:match('^%-%-cf%-memory=') then
        codefix_memory = (tok:match('^%-%-cf%-memory=(.+)') or codefix_memory):lower()
      elseif tok:match('^%-%-cf%-depth=') then
        codefix_depth = tonumber(tok:match('^%-%-cf%-depth=(.+)'))
      elseif tok:match('^%-%-cf%-beam=') then
        codefix_beam = tonumber(tok:match('^%-%-cf%-beam=(.+)'))
      elseif tok:match('^%-%-cf%-attempt=') then
        codefix_attempt = tonumber(tok:match('^%-%-cf%-attempt=(.+)'))
      elseif tok == '--cf-lua=on' then
        codefix_lua_specialized = true
      elseif tok == '--cf-lua=off' then
        codefix_lua_specialized = false
      elseif tok == '-basic' then
        codefix_reasoning = 'basic'
      elseif tok == '-high' then
        codefix_reasoning = 'high'
      elseif tok == '-max' then
        codefix_reasoning = 'max'
      elseif tok == '-tiny' then
        codefix_memory = 'tiny'
      elseif tok == '-lowmem' then
        codefix_memory = 'low'
      elseif tok == '-balanced' then
        codefix_memory = 'balanced'
      elseif tok == '-highmem' then
        codefix_memory = 'high'
      elseif tok:sub(1, 1) == '-' then
        show_usage()
        return
      else
        input_file = tok
        break
      end
      i = i + 1
    end
  elseif mode_name == 'deobf' then
    if #args == 1 then show_usage(); return end
    local i = 2
    while i <= #args do
      local tok = args[i]
      if tok == '-trace=on' or tok == '--trace=on' then
        deobf_trace = true
      elseif tok == '-trace=off' or tok == '--trace=off' then
        deobf_trace = false
      elseif tok == '-unlock-table=on' or tok == '--unlock-table=on' then
        deobf_unlock_table = true
      elseif tok == '-unlock-table=off' or tok == '--unlock-table=off' then
        deobf_unlock_table = false
      elseif tok == '-readable=on' or tok == '--readable=on' then
        deobf_readable = true
      elseif tok == '-readable=off' or tok == '--readable=off' then
        deobf_readable = false
      elseif tok:sub(1, 1) == '-' then
        show_usage()
        return
      else
        input_file = tok
        break
      end
      i = i + 1
    end
  elseif mode_name == 'fom' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'coml' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'nmbun' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'rename' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'lint' then
    if #args == 1 then show_usage(); return end
    local lint_opt = args[2]
    if lint_opt == '-off' or lint_opt == 'off' then
      lint_dynamic = false
      input_file = args[3]
    elseif lint_opt == '-on' or lint_opt == 'on' then
      lint_dynamic = true
      input_file = args[3]
    else
      input_file = args[2]
    end
  elseif mode_name == 'rrequire' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'tracelint' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'preset' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
    preset_file = args[3]
  else
    show_usage()
    return
  end
  if not input_file then
    show_usage()
    return
  end
  
  local f = io.open(input_file, 'r')
  if not f then
    print('Error: File not found: ' .. input_file)
    return
  end
  f:close()
  
  local mode = 'remove_function_local'
  
  if mode_name == 'functionlocal' then
    if scope == 'function' then
      mode = 'remove_function_local_function'
    elseif scope == 'global' then
      mode = 'remove_function_local_global'
    else
      mode = 'remove_function_local_all'
    end
  elseif mode_name == 'localcyt' then
    if scope == 'function' then
      mode = 'remove_local_string_function'
    elseif scope == 'global' then
      mode = 'remove_local_string_global'
    else
      mode = 'remove_local_string_all'
    end
  elseif mode_name == 'localnum' then
    if scope == 'function' then
      mode = 'remove_local_number_function'
    elseif scope == 'global' then
      mode = 'remove_local_number_global'
    else
      mode = 'remove_local_number_all'
    end
  elseif mode_name == 'localtur' then
    if scope == 'function' then
      mode = 'remove_local_boolean_function'
    elseif scope == 'global' then
      mode = 'remove_local_boolean_global'
    else
      mode = 'remove_local_boolean_all'
    end
  elseif mode_name == 'localkw' then
    if scope == 'function' then
      mode = 'remove_local_keyword_function'
    elseif scope == 'global' then
      mode = 'remove_local_keyword_global'
    else
      mode = 'remove_local_keyword_all'
    end
  elseif mode_name == 'localte' then
    if scope == 'function' then
      mode = 'remove_local_boolean_function'
    elseif scope == 'global' then
      mode = 'remove_local_boolean_global'
    end
  elseif mode_name == 'localc' then
    if scope == 'function' then
      mode = 'remove_local_string_function'
    elseif scope == 'global' then
      mode = 'remove_local_string_global'
    end
  elseif mode_name == 'localtabke' then
    if scope == 'function' then
      mode = 'remove_local_table_function'
    elseif scope == 'global' then
      mode = 'remove_local_table_global'
    else
      mode = 'remove_local_table_all'
    end
  elseif mode_name == 'outcode' then
    mode = 'outcode'
  elseif mode_name == 'deleteout' then
    mode = 'deleteout'
  elseif mode_name == 'nocode' then
    mode = 'nocode'
  elseif mode_name == 'codefix' then
    mode = 'codefix'
  elseif mode_name == 'deobf' then
    mode = 'deobf'
  elseif mode_name == 'fom' then
    mode = 'fom'
  elseif mode_name == 'coml' then
    mode = 'coml'
  elseif mode_name == 'nmbun' then
    mode = 'nmbun'
  elseif mode_name == 'rename' then
    mode = 'rename'
  elseif mode_name == 'lint' then
    mode = 'lint'
  elseif mode_name == 'rrequire' then
    mode = 'rrequire'
  elseif mode_name == 'tracelint' then
    mode = 'tracelint'
  elseif mode_name == 'preset' then
    mode = 'preset'
  end
  
  io.stderr:write('loading ' .. input_file .. '\n')
  io.stderr:write('mode: ' .. mode .. '\n')
  if scope then
    io.stderr:write('scope:  ' .. scope .. '\n')
  end
  if mode == 'lint' then
    io.stderr:write('lint_dynamic: ' .. tostring(lint_dynamic) .. '\n')
  elseif mode == 'codefix' then
    io.stderr:write('codefix_reasoning: ' .. tostring(codefix_reasoning) .. '\n')
    io.stderr:write('codefix_memory: ' .. tostring(codefix_memory) .. '\n')
    io.stderr:write('codefix_lua: ' .. tostring(codefix_lua_specialized) .. '\n')
  elseif mode == 'deobf' then
    io.stderr:write('deobf_trace: ' .. tostring(deobf_trace) .. '\n')
    io.stderr:write('deobf_unlock_table: ' .. tostring(deobf_unlock_table) .. '\n')
    io.stderr:write('deobf_readable: ' .. tostring(deobf_readable) .. '\n')
  end
  if preset_file then
    io.stderr:write('preset: ' .. preset_file .. '\n')
  end
  io.stderr:write('\n')

  local output_code, analyzer, meta
  output_code, analyzer, meta = process_file(input_file, mode, engine, {
    preset_file = preset_file,
    dialect = dialect,
    lint_dynamic = lint_dynamic,
    codefix_reasoning = codefix_reasoning,
    codefix_memory = codefix_memory,
    codefix_lua_specialized = codefix_lua_specialized,
    codefix_depth = codefix_depth,
    codefix_beam = codefix_beam,
    codefix_attempt = codefix_attempt,
    deobf_trace = deobf_trace,
    deobf_unlock_table = deobf_unlock_table,
    deobf_readable = deobf_readable
  })
  
  ensure_dir('output')
  
  local filename = input_file:match('([^/\\]+)$')
  local output_name = filename
  if meta and type(meta.output_filename) == 'string' and meta.output_filename ~= '' then
    output_name = meta.output_filename
  elseif meta and type(meta.output_suffix) == 'string' and meta.output_suffix ~= '' then
    output_name = filename .. meta.output_suffix
  end
  local output_filepath = 'output/' .. output_name

  if output_code and mode ~= 'rename' and mode ~= 'deleteout' and mode ~= 'nocode' and mode ~= 'codefix' and mode ~= 'deobf' and mode ~= 'lint' and mode ~= 'rrequire' and mode ~= 'preset' then
    output_code = output_code:gsub('\n+$', '')
  end
  write_file(output_filepath, output_code)

  io.stderr:write('complete: ' .. output_filepath .. '\n\n')
  if meta and (meta.report_data or meta.report_text) then
    local report_path = 'output/' .. filename .. (meta.report_suffix or '.report.json')
    local report_body = meta.report_text
    if meta.report_data then
      report_body = Json.encode(meta.report_data, true)
    end
    write_file(report_path, report_body)
    io.stderr:write('report: ' .. report_path .. '\n')
    if meta.lint_summary then
      io.stderr:write(string.format(
        'lint summary: total=%d error=%d warning=%d info=%d\n',
        meta.lint_summary.total or 0,
        meta.lint_summary.error or 0,
        meta.lint_summary.warning or 0,
        meta.lint_summary.info or 0
      ))
    end
    if meta.rrequire_summary then
      io.stderr:write(string.format(
        'rrequire summary: files=%d edges=%d unresolved=%d dynamic=%d parse_errors=%d\n',
        meta.rrequire_summary.files or 0,
        meta.rrequire_summary.edges or 0,
        meta.rrequire_summary.unresolved or 0,
        meta.rrequire_summary.dynamic or 0,
        meta.rrequire_summary.parse_errors or 0
      ))
    end
    io.stderr:write('\n')
  end
  if meta and type(meta.extra_reports) == 'table' then
    for _, extra in ipairs(meta.extra_reports) do
      if type(extra) == 'table' and extra.data then
        local suffix = extra.suffix or '.extra.json'
        local extra_path = 'output/' .. filename .. suffix
        write_file(extra_path, Json.encode(extra.data, true))
      end
    end
  end
  if meta and type(meta.extra_outputs) == 'table' then
    for _, extra in ipairs(meta.extra_outputs) do
      if type(extra) == 'table' and type(extra.content) == 'string' then
        local suffix = type(extra.suffix) == 'string' and extra.suffix or '.extra.lua'
        local extra_path = 'output/' .. filename .. suffix
        write_file(extra_path, extra.content)
      end
    end
  end
  local total = 0
  local func_count = 0
  local global_count = 0
  for _, entry in ipairs(analyzer.all_locals) do
    total = total + 1
    if entry.is_in_function then
      func_count = func_count + 1
    else
      global_count = global_count + 1
    end
  end
  io.stderr:write('total local variables: ' .. total .. '\n')
  io.stderr:write('in functions: ' .. func_count .. '\n')
  io.stderr:write('global: ' .. global_count .. '\n')
end

main()
